# Jarvis Android - Part 1

Jarvis Core foreground-service starter:
- Active
- Sleep
- Off
- Persistent notification controls

This is the first foundation only. AI, wake word, notification reading and accessibility automation are intentionally not included yet.
