package com.jarvis.android

import android.Manifest
import android.content.Intent
import android.os.Build
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private val Void = Color(0xFF070B12)
private val Panel = Color(0xFF101825)
private val Raised = Color(0xFF172433)
private val Cyan = Color(0xFF59DDF5)
private val Mint = Color(0xFF75F0C3)
private val Muted = Color(0xFF9AABBC)
private val JarvisColors = darkColorScheme(
    primary = Cyan,
    onPrimary = Color(0xFF071118),
    secondary = Mint,
    background = Void,
    onBackground = Color(0xFFEAF4FC),
    surface = Panel,
    onSurface = Color(0xFFEAF4FC),
    surfaceVariant = Raised,
    onSurfaceVariant = Muted
)

class MainActivity : ComponentActivity() {
    private lateinit var secureStore: SecureStore
    private lateinit var engine: JarvisEngine

    companion object {
        const val EXTRA_WAKE_QUERY = "com.jarvis.android.EXTRA_WAKE_QUERY"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        secureStore = SecureStore(applicationContext)
        engine = JarvisEngine(applicationContext, secureStore)
        window.statusBarColor = android.graphics.Color.rgb(7, 11, 18)
        window.navigationBarColor = android.graphics.Color.rgb(7, 11, 18)
        setContent {
            MaterialTheme(colorScheme = JarvisColors) {
                JarvisHome(
                    store = secureStore,
                    engine = engine,
                    initialQuery = intent?.getStringExtra(EXTRA_WAKE_QUERY)
                )
            }
        }
    }
}

private enum class Page { CHAT, INTERNET, MEMORY, SETTINGS }

@Composable
private fun JarvisHome(store: SecureStore, engine: JarvisEngine, initialQuery: String? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val uriHandler = LocalUriHandler.current
    var settings by remember { mutableStateOf(store.settings()) }
    var isUnlocked by remember { mutableStateOf(!store.hasAppPin()) }
    var messages by remember { mutableStateOf(store.chat().map { message ->
        if (message.role == "assistant") {
            val cleaned = cleanAssistantOutput(message.content)
            message.copy(content = cleaned.ifBlank { "(Purana response clean nahi tha; use hide kar diya.)" })
        } else message
    }) }
    var page by remember { mutableStateOf(Page.CHAT) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var partialAnswer by remember { mutableStateOf("") }
    var autoSendVoice by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    var routeStatus by remember { mutableStateOf("Ready · local-first") }
    var latestSources by remember { mutableStateOf(emptyList<SearchHit>()) }
    var imageDataUri by remember { mutableStateOf<String?>(null) }
    var imageLabel by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var searchHits by remember { mutableStateOf(emptyList<SearchHit>()) }
    var searchBusy by remember { mutableStateOf(false) }
    var testStatus by remember { mutableStateOf("") }
    var ownerVoiceConfigured by remember { mutableStateOf(store.hasOwnerVoiceProfile()) }
    var askConfirm by remember { mutableStateOf("") }
    var showBackupPassword by remember { mutableStateOf(false) }
    var backupPassword by remember { mutableStateOf("") }
    var backupFlow by remember { mutableStateOf("") }
    var importUri by remember { mutableStateOf<Uri?>(null) }

    val voice = remember(context) { VoiceOutput(context) }
    DisposableEffect(voice) { onDispose { voice.shutdown() } }
    LaunchedEffect(settings) { voice.update(settings) }
    LaunchedEffect(messages) { store.saveChat(messages.takeLast(60)) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            imageLabel = uri.lastPathSegment ?: "Image attached"
            scope.launch {
                routeStatus = "Preparing image…"
                val encoded = withContext(Dispatchers.IO) { runCatching { ImageUtils.toJpegDataUri(context, uri) } }
                encoded.onSuccess {
                    imageDataUri = it
                    routeStatus = "Image ready · ask a question"
                }.onFailure {
                    imageDataUri = null; imageLabel = null
                    routeStatus = "Image error: ${it.message ?: "unsupported image"}"
                }
            }
        }
    }

    val backupCreate = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) {
            val password = backupPassword.toCharArray()
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching { BackupCrypto.writeEncrypted(context.contentResolver, uri, store.exportPayload(), password) }
                }
                password.fill('\u0000')
                routeStatus = result.fold({ "Encrypted backup saved." }, { "Backup failed: ${it.message}" })
            }
            backupPassword = ""
        }
    }
    val backupOpen = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            importUri = uri
            backupFlow = "import"
            backupPassword = ""
            showBackupPassword = true
        }
    }

    val recognizer = remember(context) {
        if (SpeechRecognizer.isRecognitionAvailable(context)) runCatching { SpeechRecognizer.createSpeechRecognizer(context) }.getOrNull() else null
    }
    val currentSpeechResult by rememberUpdatedState<(String) -> Unit>({ text ->
        draft = text
        autoSendVoice = true
        listening = false
        routeStatus = "Voice recognized · sending to Jarvis…"
    })
    val currentSpeechStatus by rememberUpdatedState<(String) -> Unit>({ text -> routeStatus = text; listening = false })
    DisposableEffect(recognizer) {
        if (recognizer != null) {
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening = true; routeStatus = "Listening…" }
                override fun onBeginningOfSpeech() { listening = true }
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() { listening = false }
                override fun onError(error: Int) {
                    currentSpeechStatus("Voice input ended (code $error). Try again or check your phone's speech service.")
                }
                override fun onResults(results: Bundle?) {
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!spoken.isNullOrBlank()) currentSpeechResult(spoken) else currentSpeechStatus("No speech recognised. Try again.")
                }
                override fun onPartialResults(partialResults: Bundle?) = Unit
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
        }
        onDispose { runCatching { recognizer?.cancel(); recognizer?.destroy() } }
    }

    val startListening: () -> Unit = {
        if (recognizer == null) routeStatus = "Speech recognition is unavailable on this phone."
        else {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, settings.voiceLanguage)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, settings.voiceLanguage)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Jarvis")
            }
            runCatching { recognizer.startListening(intent); listening = true; routeStatus = "Starting microphone…" }
                .onFailure { listening = false; routeStatus = "Mic error: ${it.message}" }
        }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListening() else routeStatus = "Microphone permission denied. Voice input remains off."
    }

    var wakeWordEnabled by remember {
        mutableStateOf(context.getSharedPreferences(JarvisWakeWordService.PREFS, android.content.Context.MODE_PRIVATE)
            .getBoolean(JarvisWakeWordService.KEY_ENABLED, false))
    }

    LaunchedEffect(page, wakeWordEnabled) {
        if (page == Page.SETTINGS) {
            while (true) {
                ownerVoiceConfigured = store.hasOwnerVoiceProfile()
                delay(1_000L)
            }
        } else {
            ownerVoiceConfigured = store.hasOwnerVoiceProfile()
        }
    }

    fun startWakeServiceIfAllowed() {
        val micGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val notificationGranted = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (!micGranted || !notificationGranted) {
            routeStatus = "Hey Jarvis needs microphone and notification permissions. Try Start again and allow both."
            return
        }
        runCatching {
            context.startForegroundService(Intent(context, JarvisWakeWordService::class.java).setAction(JarvisWakeWordService.ACTION_START))
        }.onSuccess {
            context.getSharedPreferences(JarvisWakeWordService.PREFS, android.content.Context.MODE_PRIVATE)
                .edit().putBoolean(JarvisWakeWordService.KEY_ENABLED, true).apply()
            wakeWordEnabled = true
            routeStatus = "Starting offline Hey Jarvis listener…"
        }.onFailure { routeStatus = "Wake-word service could not start: ${it.message ?: "unknown error"}" }
    }

    val wakePermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        startWakeServiceIfAllowed()
    }
    val startWakeWord: () -> Unit = {
        val required = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = required.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startWakeServiceIfAllowed() else wakePermissionLauncher.launch(missing.toTypedArray())
    }
    val stopWakeWord: () -> Unit = {
        context.stopService(Intent(context, JarvisWakeWordService::class.java))
        context.getSharedPreferences(JarvisWakeWordService.PREFS, android.content.Context.MODE_PRIVATE)
            .edit().putBoolean(JarvisWakeWordService.KEY_ENABLED, false).apply()
        routeStatus = "Hey Jarvis listener stopped."
    }
    LaunchedEffect(initialQuery, isUnlocked) {
        if (isUnlocked && !initialQuery.isNullOrBlank()) {
            draft = initialQuery
            autoSendVoice = true
            routeStatus = "Voice question received · preparing Jarvis…"
        }
    }

    fun sendMessage(raw: String) {
        val text = raw.trim()
        val attached = imageDataUri
        if ((text.isBlank() && attached == null) || busy) return
        val actualQuestion = text.ifBlank { "Please describe this image and help me understand it." }
        val shownText = if (attached != null) "$actualQuestion\n[Image attached]" else actualQuestion
        val previous = messages
        val userMessage = ChatMessage(role = "user", content = shownText)
        messages = (messages + userMessage).takeLast(60)
        draft = ""
        imageDataUri = null
        imageLabel = null
        busy = true
        partialAnswer = ""
        autoSendVoice = false
        latestSources = emptyList()
        routeStatus = "Thinking…"
        scope.launch {
            val reply = runCatching {
                engine.ask(actualQuestion, previous, settings, attached, onPartial = { partial ->
                    withContext(Dispatchers.Main.immediate) { partialAnswer = cleanAssistantOutput(partial) }
                })
            }
            reply.onSuccess { answer ->
                messages = (messages + ChatMessage(role = "assistant", content = answer.text)).takeLast(60)
                routeStatus = "${answer.route} · ${if (answer.needsSetup) "setup needed" else "done"}"
                latestSources = answer.sources
                if (settings.speakReplies && !answer.needsSetup) voice.speak(answer.text)
                partialAnswer = ""
            }.onFailure { error ->
                messages = (messages + ChatMessage(role = "assistant", content = "Request error: ${error.message ?: "unknown error"}. Check Settings and retry.")).takeLast(60)
                routeStatus = "Request failed"
                partialAnswer = ""
            }
            busy = false
        }
    }

    LaunchedEffect(autoSendVoice, draft, busy) {
        if (autoSendVoice && !busy && draft.isNotBlank()) {
            val recognizedText = draft
            autoSendVoice = false
            sendMessage(recognizedText)
        }
    }

    Scaffold(
        containerColor = Void,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (isUnlocked) NavigationBar(containerColor = Color(0xFF0A111B), contentColor = Muted, windowInsets = WindowInsets.navigationBars) {
                NavigationBarItem(selected = page == Page.CHAT, onClick = { page = Page.CHAT }, icon = { Icon(Icons.Outlined.SmartToy, null) }, label = { Text("Chat") })
                NavigationBarItem(selected = page == Page.INTERNET, onClick = { page = Page.INTERNET }, icon = { Icon(Icons.Outlined.Search, null) }, label = { Text("Internet") })
                NavigationBarItem(selected = page == Page.MEMORY, onClick = { page = Page.MEMORY }, icon = { Icon(Icons.Outlined.Lock, null) }, label = { Text("Memory") })
                NavigationBarItem(selected = page == Page.SETTINGS, onClick = { page = Page.SETTINGS }, icon = { Icon(Icons.Outlined.Settings, null) }, label = { Text("Settings") })
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A1520), Void, Color(0xFF070B12))))
                .padding(innerPadding).statusBarsPadding()
        ) {
            if (!isUnlocked) {
                PinLockPanel(onSubmit = { pin ->
                    val ok = store.verifyAppPin(pin)
                    if (ok) { isUnlocked = true; routeStatus = "Unlocked · welcome back" }
                    ok
                })
            } else {
            HeaderBar(routeStatus = routeStatus, settings = settings, onSettings = { page = Page.SETTINGS })
            when (page) {
                Page.CHAT -> {
                    val listState = rememberLazyListState()
                    LaunchedEffect(messages.size, busy) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (messages.isEmpty()) item { WelcomePanel(settings.routerMode) }
                        items(messages, key = { it.id }) { message -> MessageBubble(message) }
                        if (busy) item {
                            if (partialAnswer.isBlank()) ThinkingBubble()
                            else MessageBubble(ChatMessage(role = "assistant", content = partialAnswer))
                        }
                        if (latestSources.isNotEmpty() && !busy) item {
                            SourcesPanel(latestSources, onOpen = { url -> runCatching { uriHandler.openUri(url) } })
                        }
                    }
                    if (imageLabel != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.Image, null, tint = Mint, modifier = Modifier.size(18.dp))
                            Text(" Image attached", color = Mint, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { imageDataUri = null; imageLabel = null }) { Text("Remove") }
                        }
                    }
                    QuickActions(onCommand = { draft = it })
                    Composer(
                        value = draft,
                        onValueChange = { draft = it },
                        onSend = { sendMessage(draft) },
                        onMic = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListening()
                            else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        onImage = { imagePicker.launch("image/*") },
                        busy = busy,
                        listening = listening,
                        hasImage = imageDataUri != null
                    )
                }
                Page.INTERNET -> InternetPage(
                    query = searchQuery,
                    onQuery = { searchQuery = it },
                    busy = searchBusy,
                    hits = searchHits,
                    onSearch = {
                        val q = searchQuery.trim()
                        if (q.isNotBlank() && !searchBusy) {
                            searchBusy = true; searchHits = emptyList(); routeStatus = "Searching web…"
                            scope.launch {
                                val result = withContext(Dispatchers.IO) { runCatching { engine.searchWeb(q) } }
                                result.onSuccess { searchHits = it; routeStatus = "Web search · ${it.size} result(s)" }
                                    .onFailure { routeStatus = "Search failed: ${it.message ?: "check connection"}" }
                                searchBusy = false
                            }
                        }
                    },
                    onOpen = { url -> runCatching { uriHandler.openUri(url) } }
                )
                Page.MEMORY -> MemoryPage(
                    memories = store.memories(),
                    onAdd = { fact -> store.addMemory(fact); routeStatus = "Memory saved encrypted on this phone" },
                    onRemove = { fact -> store.removeMemory(fact); routeStatus = "Memory removed" },
                    onClear = { askConfirm = "memory" },
                    chatCount = messages.size,
                    onClearChat = { askConfirm = "chat" }
                )
                Page.SETTINGS -> SettingsPage(
                    settings = settings,
                    onChange = { settings = it },
                    onSave = { store.saveSettings(settings); routeStatus = "Settings saved encrypted on this phone"; voice.update(settings) },
                    onTestLocal = {
                        testStatus = if (settings.useBundledModel) "Preparing built-in Qwen3 model. First load can take a few minutes…" else "Testing local endpoint…"
                        scope.launch {
                            if (settings.useBundledModel) {
                                engine.testBuiltInLocalModel().fold(
                                    { testStatus = it },
                                    { testStatus = "Built-in model failed: ${it.message ?: "unknown error"}" }
                                )
                            } else {
                                engine.testEndpoint(settings.localEndpoint, settings.localModel, "").fold(
                                    { testStatus = "Local connected: ${it.take(120)}" },
                                    { testStatus = "Local failed: ${it.message}" }
                                )
                            }
                        }
                    },
                    onTestOnline = {
                        testStatus = "Testing online endpoint…"
                        scope.launch { engine.testEndpoint(settings.onlineEndpoint, settings.onlineModel, settings.apiKey).fold(
                            { testStatus = "Online connected: ${it.take(120)}" }, { testStatus = "Online failed: ${it.message}" }
                        ) }
                    },
                    testStatus = testStatus,
                    onBackup = { backupFlow = "export"; backupPassword = ""; showBackupPassword = true },
                    onRestore = { backupOpen.launch(arrayOf("application/octet-stream", "application/x-zip-compressed", "*/*")) },
                    onClearChat = { askConfirm = "chat" },
                    onClearMemory = { askConfirm = "memory" },
                    hasAppPin = store.hasAppPin(),
                    onSetPin = { pin -> store.setAppPin(pin); routeStatus = "App lock PIN saved" },
                    onRemovePin = { askConfirm = "removePin" },
                    onLockNow = { isUnlocked = false },
                    wakeWordEnabled = wakeWordEnabled,
                    ownerVoiceConfigured = ownerVoiceConfigured,
                    onStartOwnerVoiceSetup = {
                        if (!wakeWordEnabled) {
                            routeStatus = "Pehle Hey Jarvis listener start karo, phir Owner Voice Setup chalao."
                        } else {
                            runCatching {
                                ContextCompat.startForegroundService(
                                    context,
                                    Intent(context, JarvisWakeWordService::class.java).setAction(JarvisWakeWordService.ACTION_ENROLL_OWNER_VOICE)
                                )
                            }.onSuccess {
                                routeStatus = "Owner Voice Setup started. Same phrase 3 baar bolo, har baar pause ke saath."
                            }.onFailure { routeStatus = "Owner Voice Setup start nahi hua: ${it.message ?: "unknown error"}" }
                        }
                    },
                    onClearOwnerVoice = {
                        store.clearOwnerVoiceProfile()
                        ownerVoiceConfigured = false
                        routeStatus = "Owner voice profile delete kar diya."
                    },
                    onStartWakeWord = { startWakeWord() },
                    onStopWakeWord = {
                        stopWakeWord()
                        wakeWordEnabled = false
                    },
                    onOpenAccessibility = {
                        runCatching {
                            context.startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }.onFailure { routeStatus = "Accessibility Settings nahi khul paayi." }
                    }
                )
            }
            }
        }
    }

    if (askConfirm.isNotBlank()) {
        val isMemory = askConfirm == "memory"
        val isRemovePin = askConfirm == "removePin"
        AlertDialog(
            onDismissRequest = { askConfirm = "" },
            containerColor = Panel,
            title = { Text(when { isMemory -> "Clear saved memory?"; isRemovePin -> "Remove app lock?"; else -> "Clear chat history?" }) },
            text = { Text(when { isMemory -> "This removes saved facts from this phone. Chat history stays."; isRemovePin -> "Anyone with access to the phone can open Jarvis without the extra PIN. Device encryption remains on."; else -> "This deletes the locally saved chat history. It cannot be undone unless you have a backup." }) },
            confirmButton = {
                TextButton(onClick = {
                    when {
                        isMemory -> store.clearMemories()
                        isRemovePin -> store.removeAppPin()
                        else -> {
                            store.clearChat()
                            messages = emptyList()
                            scope.launch { runCatching { engine.resetBuiltInConversation() } }
                        }
                    }
                    askConfirm = ""; routeStatus = when { isMemory -> "Saved memory cleared"; isRemovePin -> "App lock removed"; else -> "Chat history cleared" }
                }) { Text(if (isRemovePin) "Remove PIN" else "Clear", color = Color(0xFFFF8D8D)) }
            },
            dismissButton = { TextButton(onClick = { askConfirm = "" }) { Text("Cancel") } }
        )
    }

    if (showBackupPassword) {
        AlertDialog(
            onDismissRequest = { showBackupPassword = false; backupPassword = ""; importUri = null },
            containerColor = Panel,
            title = { Text(if (backupFlow == "export") "Create encrypted backup" else "Restore encrypted backup") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (backupFlow == "export") "Choose a strong backup password. Keep it safe—without it the backup cannot be opened." else "Enter the password used when this backup was created.", color = Muted)
                    OutlinedTextField(
                        value = backupPassword,
                        onValueChange = { backupPassword = it },
                        label = { Text("Backup password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        colors = fieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (backupPassword.length < 8) { routeStatus = "Backup password must be at least 8 characters." }
                    else if (backupFlow == "export") {
                        showBackupPassword = false
                        backupCreate.launch("jarvis-backup.jrb")
                    } else {
                        val uri = importUri
                        if (uri != null) {
                            val password = backupPassword.toCharArray()
                            scope.launch {
                                val result = withContext(Dispatchers.IO) { runCatching { BackupCrypto.readEncrypted(context.contentResolver, uri, password) } }
                                password.fill('\u0000')
                                result.onSuccess { payload ->
                                    val imported = runCatching { store.importPayload(payload) }
                                    imported.onSuccess {
                                        settings = store.settings(); messages = store.chat()
                                        routeStatus = "Encrypted backup restored. Settings, chat and memory imported."
                                    }.onFailure { routeStatus = "Restore failed: ${it.message}" }
                                }.onFailure { routeStatus = "Restore failed: wrong password or invalid file." }
                                backupPassword = ""; importUri = null
                            }
                            showBackupPassword = false
                        } else routeStatus = "Choose a backup file first."
                    }
                }) { Text(if (backupFlow == "export") "Create file" else "Restore") }
            },
            dismissButton = { TextButton(onClick = { showBackupPassword = false; backupPassword = ""; importUri = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun HeaderBar(routeStatus: String, settings: JarvisSettings, onSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 18.dp, end = 14.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(44.dp).clip(RoundedCornerShape(15.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF143346), Color(0xFF0D6C73))))
                .border(1.dp, Cyan.copy(alpha = 0.55f), RoundedCornerShape(15.dp)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Outlined.GraphicEq, contentDescription = null, tint = Cyan, modifier = Modifier.size(27.dp)) }
        Spacer(Modifier.width(11.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("JARVIS", fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp, color = Color(0xFFF3FAFF))
            Text("LOCAL-FIRST · PRIVATE BY DEFAULT", fontSize = 9.sp, letterSpacing = 0.6.sp, color = Mint)
            Text(routeStatus, fontSize = 10.sp, color = Muted, maxLines = 1)
        }
        OutlinedButton(
            onClick = onSettings,
            shape = RoundedCornerShape(14.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(8.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)
        ) { Icon(Icons.Outlined.Settings, contentDescription = "Settings", modifier = Modifier.size(21.dp)) }
    }
    Divider(color = Cyan.copy(alpha = 0.12f), thickness = 1.dp)
}

@Composable
private fun WelcomePanel(mode: RouterMode) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 30.dp, bottom = 15.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(118.dp)) {
            Box(Modifier.fillMaxSize().clip(CircleShape).background(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.22f), Color.Transparent))))
            Box(Modifier.size(84.dp).clip(CircleShape).background(Color(0xFF0D2735)).border(1.dp, Cyan.copy(alpha = 0.65f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.GraphicEq, null, tint = Cyan, modifier = Modifier.size(47.dp))
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("I’m Jarvis.", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Text("Local AI first. Online help only when configured and useful.", color = Muted, textAlign = TextAlign.Center, fontSize = 13.sp)
        Spacer(Modifier.height(17.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1B26)),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp).border(1.dp, Cyan.copy(alpha = 0.18f), RoundedCornerShape(18.dp))
        ) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Lock, null, tint = Mint, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(8.dp)); Text("Private by default", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
                Text("Chat, settings and saved memories are encrypted on this device. Online requests use the provider you configure.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                Text("Routing: ${mode.name.replace('_', ' ')}", color = Cyan, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Try:  “open instagram”  ·  “remember: I study in Class 9”  ·  “set timer for 5 minutes”", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, lineHeight = 17.sp)
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val user = message.role == "user"
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        if (!user) {
            Box(Modifier.size(29.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF0F3844)), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.SmartToy, null, tint = Cyan, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(8.dp))
        }
        Surface(
            modifier = Modifier.fillMaxWidth(if (user) 0.88f else 0.94f),
            shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = if (user) 18.dp else 5.dp, bottomEnd = if (user) 5.dp else 18.dp),
            color = if (user) Color(0xFF113547) else Panel,
            tonalElevation = 1.dp
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 11.dp)) {
                Text(if (user) "YOU" else "JARVIS", fontSize = 9.sp, letterSpacing = 1.1.sp, color = if (user) Mint else Cyan, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(message.content, color = Color(0xFFEAF4FC), fontSize = 14.sp, lineHeight = 21.sp)
            }
        }
    }
}

@Composable
private fun ThinkingBubble() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
        Icon(Icons.Outlined.GraphicEq, null, tint = Mint, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(9.dp))
        Text("Jarvis is thinking…", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SourcesPanel(hits: List<SearchHit>, onOpen: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("WEB SOURCES", color = Mint, fontSize = 10.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.Bold)
        hits.forEachIndexed { index, hit ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1924)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().clickable { onOpen(hit.url) }
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text("${index + 1}. ${hit.title}", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    if (hit.snippet.isNotBlank()) Text(hit.snippet, color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                    Text(hit.url, color = Color(0xFF7B9AAE), fontSize = 10.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun QuickActions(onCommand: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        QuickActionChip("Instagram", "open instagram", Modifier.weight(1f), onCommand)
        QuickActionChip("WhatsApp", "open whatsapp", Modifier.weight(1f), onCommand)
        QuickActionChip("YouTube", "open youtube", Modifier.weight(1f), onCommand)
    }
}

@Composable
private fun QuickActionChip(label: String, command: String, modifier: Modifier, onClick: (String) -> Unit) {
    Surface(
        modifier = modifier.clickable { onClick(command) },
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF0D202B),
        border = androidx.compose.foundation.BorderStroke(1.dp, Cyan.copy(alpha = 0.13f))
    ) {
        Text(label, modifier = Modifier.padding(horizontal = 8.dp, vertical = 9.dp), textAlign = TextAlign.Center, fontSize = 11.sp, color = Color(0xFFDDEAF2), maxLines = 1)
    }
}

@Composable
private fun Composer(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
    onMic: () -> Unit,
    onImage: () -> Unit,
    busy: Boolean,
    listening: Boolean,
    hasImage: Boolean
) {
    Column(
        modifier = Modifier.fillMaxWidth().background(Color(0xFF090F17)).navigationBarsPadding().imePadding()
            .padding(horizontal = 12.dp, vertical = 9.dp)
    ) {
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedButton(
                onClick = onImage,
                shape = RoundedCornerShape(15.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                modifier = Modifier.size(43.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)
            ) { Icon(Icons.Outlined.Image, "Attach image", modifier = Modifier.size(19.dp)) }
            OutlinedButton(
                onClick = onMic,
                shape = RoundedCornerShape(15.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                modifier = Modifier.size(43.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = if (listening) Mint else Cyan)
            ) { Icon(Icons.Outlined.Mic, if (listening) "Listening" else "Voice input", modifier = Modifier.size(20.dp)) }
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask Jarvis…", color = Muted, fontSize = 13.sp) },
                shape = RoundedCornerShape(16.dp),
                maxLines = 4,
                colors = fieldColors(),
                textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp)
            )
            Button(
                onClick = onSend,
                enabled = !busy && (value.isNotBlank() || hasImage),
                shape = RoundedCornerShape(15.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                modifier = Modifier.size(45.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Void, disabledContainerColor = Raised)
            ) { Icon(Icons.Outlined.Send, "Send message", modifier = Modifier.size(18.dp)) }
        }
        Text("Microphone starts only when you tap it. Voice recognition may use your phone's speech service.", modifier = Modifier.padding(start = 4.dp, top = 5.dp), color = Color(0xFF758A9B), fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun InternetPage(
    query: String,
    onQuery: (String) -> Unit,
    busy: Boolean,
    hits: List<SearchHit>,
    onSearch: () -> Unit,
    onOpen: (String) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        PageTitle("Internet search", "Search runs only when you ask or automatic routing detects a current-facts query.")
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query,
                onValueChange = onQuery,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Search the web…") },
                singleLine = true,
                shape = RoundedCornerShape(15.dp),
                colors = fieldColors()
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = onSearch, enabled = query.isNotBlank() && !busy, shape = RoundedCornerShape(14.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(13.dp)) {
                Icon(Icons.Outlined.Search, "Search", modifier = Modifier.size(20.dp))
            }
        }
        if (busy) Text("Searching…", color = Cyan, fontSize = 12.sp)
        if (hits.isEmpty() && !busy) EmptyPanel("No results yet", "Type a question and tap Search. You need an internet connection for this feature.")
        LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 20.dp)) {
            items(hits, key = { it.url }) { hit ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpen(hit.url) },
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(17.dp)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(hit.title, color = Cyan, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        if (hit.snippet.isNotBlank()) Text(hit.snippet, color = Color(0xFFD5E1EB), fontSize = 12.sp, lineHeight = 18.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(hit.url, modifier = Modifier.weight(1f), color = Muted, fontSize = 10.sp, maxLines = 1)
                            Icon(Icons.Outlined.OpenInNew, null, tint = Mint, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MemoryPage(
    memories: List<String>,
    onAdd: (String) -> Unit,
    onRemove: (String) -> Unit,
    onClear: () -> Unit,
    chatCount: Int,
    onClearChat: () -> Unit
) {
    var newFact by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        PageTitle("Encrypted memory", "Only saved facts become long-term memory. Everything stays local until you send it in an online request.")
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = newFact, onValueChange = { newFact = it }, modifier = Modifier.weight(1f), label = { Text("Add a fact") }, singleLine = true, colors = fieldColors(), shape = RoundedCornerShape(14.dp))
            Button(onClick = { if (newFact.isNotBlank()) { onAdd(newFact.trim()); newFact = "" } }, enabled = newFact.isNotBlank(), shape = RoundedCornerShape(14.dp)) { Text("Save") }
        }
        Spacer(Modifier.height(15.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("SAVED FACTS · ${memories.size}", modifier = Modifier.weight(1f), color = Mint, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.sp)
            TextButton(onClick = onClear, enabled = memories.isNotEmpty()) { Text("Clear all", color = Color(0xFFFF9A9A)) }
        }
        if (memories.isEmpty()) EmptyPanel("No saved memories", "In chat, say ‘remember: …’ or add a fact above.")
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 12.dp)) {
            items(memories, key = { it }) { fact ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Lock, null, tint = Mint, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(9.dp))
                        Text(fact, modifier = Modifier.weight(1f), fontSize = 13.sp, lineHeight = 18.sp)
                        TextButton(onClick = { onRemove(fact) }) { Text("Remove", color = Color(0xFFFF9A9A), fontSize = 11.sp) }
                    }
                }
            }
        }
        Divider(color = Cyan.copy(alpha = 0.12f))
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Chat history", fontWeight = FontWeight.SemiBold)
                Text("$chatCount saved messages · encrypted", color = Muted, fontSize = 11.sp)
            }
            OutlinedButton(onClick = onClearChat, shape = RoundedCornerShape(12.dp)) { Icon(Icons.Outlined.DeleteOutline, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Clear") }
        }
    }
}

@Composable
private fun SettingsPage(
    settings: JarvisSettings,
    onChange: (JarvisSettings) -> Unit,
    onSave: () -> Unit,
    onTestLocal: () -> Unit,
    onTestOnline: () -> Unit,
    testStatus: String,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onClearChat: () -> Unit,
    onClearMemory: () -> Unit,
    hasAppPin: Boolean,
    onSetPin: (String) -> Unit,
    onRemovePin: () -> Unit,
    onLockNow: () -> Unit,
    wakeWordEnabled: Boolean,
    ownerVoiceConfigured: Boolean,
    onStartOwnerVoiceSetup: () -> Unit,
    onClearOwnerVoice: () -> Unit,
    onStartWakeWord: () -> Unit,
    onStopWakeWord: () -> Unit,
    onOpenAccessibility: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        PageTitle("Settings & security", "Choose your local model and optional online provider. Secrets are encrypted on this device and not embedded in the source ZIP.")
        SettingsSection("AI ROUTER") {
            Text("Preferred routing mode", color = Muted, fontSize = 12.sp)
            RouterChoice("AUTO · local first, online for current/complex tasks, fallback if needed", RouterMode.AUTO, settings.routerMode) { onChange(settings.copy(routerMode = it)) }
            RouterChoice("LOCAL ONLY · no online AI or automatic web search", RouterMode.LOCAL_ONLY, settings.routerMode) { onChange(settings.copy(routerMode = it)) }
            RouterChoice("ONLINE FIRST · use configured online model, fall back to local", RouterMode.ONLINE_FIRST, settings.routerMode) { onChange(settings.copy(routerMode = it)) }
            SettingSwitch("Automatic web search for current information", settings.autoWebSearch) { onChange(settings.copy(autoWebSearch = it)) }
        }
        SettingsSection("LOCAL MODEL") {
            SettingSwitch("Use built-in Qwen3 0.6B model (offline)", settings.useBundledModel) {
                onChange(settings.copy(useBundledModel = it))
            }
            if (settings.useBundledModel) {
                Text("Qwen3-0.6B Q4_K_M is bundled in this APK. First use copies about 0.48 GB into private app storage; keep around 1.5 GB free for setup and temporary files. No Termux/server is needed for local text chat.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
            } else {
                Field("Local endpoint", settings.localEndpoint, { onChange(settings.copy(localEndpoint = it)) }, hint = "http://127.0.0.1:8080/v1/chat/completions")
                Field("Local model name", settings.localModel, { onChange(settings.copy(localModel = it)) }, hint = "Model alias served by llama-server")
                Text("External OpenAI-compatible local server mode. Start your server separately, then test the endpoint.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
            }
            OutlinedButton(onClick = onTestLocal, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
                Icon(Icons.Outlined.CheckCircle, null, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(7.dp))
                Text(if (settings.useBundledModel) "Load / test built-in model" else "Test local connection")
            }
        }
        SettingsSection("OPTIONAL ONLINE PROVIDER") {
            Field("HTTPS endpoint / base URL", settings.onlineEndpoint, { onChange(settings.copy(onlineEndpoint = it)) }, hint = "https://provider.example/v1")
            Field("Online model name", settings.onlineModel, { onChange(settings.copy(onlineModel = it)) }, hint = "Provider's exact model id")
            OutlinedTextField(
                value = settings.apiKey,
                onValueChange = { onChange(settings.copy(apiKey = it)) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("API key (kept encrypted on device)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                colors = fieldColors(), shape = RoundedCornerShape(14.dp)
            )
            Text("Use only a provider endpoint that supports the OpenAI-compatible chat-completions format. Online requests may consume that provider's quota or cost money.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
            OutlinedButton(onClick = onTestOnline, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) { Icon(Icons.Outlined.CheckCircle, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(7.dp)); Text("Test online connection") }
        }
        SettingsSection("HEY JARVIS · BACKGROUND WAKE WORD") {
            Text("Optional, offline wake-word detection uses the phone microphone continuously while enabled. Voice stays on-device and is not saved or sent to a cloud service by this listener. It uses extra battery; stop it whenever you do not need hands-free commands.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
            if (wakeWordEnabled) {
                Text("Listener status: starting or active", color = Mint, fontSize = 12.sp)
                OutlinedButton(onClick = onStopWakeWord, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) { Text("Stop Hey Jarvis listener") }
            } else {
                Button(onClick = onStartWakeWord, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
                    Icon(Icons.Outlined.Mic, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(7.dp)); Text("Start Hey Jarvis listener")
                }
            }
            Text("Say ‘Hey Jarvis, open YouTube’ or say ‘Hey Jarvis’ first and give the command within about 10 seconds. A question that needs the AI answer opens through a notification tap.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
        SettingsSection("OWNER VOICE PROFILE · EXPERIMENTAL") {
            if (ownerVoiceConfigured) {
                Text("Owner voice profile stored encrypted on this phone. The hands-free listener uses a local speaker-vector similarity check before acting.", color = Mint, fontSize = 12.sp, lineHeight = 17.sp)
                OutlinedButton(onClick = onStartOwnerVoiceSetup, enabled = wakeWordEnabled, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
                    Icon(Icons.Outlined.Mic, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(7.dp)); Text("Replace owner voice profile")
                }
                OutlinedButton(onClick = onClearOwnerVoice, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
                    Icon(Icons.Outlined.DeleteOutline, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(7.dp)); Text("Delete owner voice profile")
                }
            } else {
                Text("No owner voice profile is enrolled. Start Hey Jarvis first, then tap setup. In a quiet room, say ‘Main Jarvis ka owner hoon’ three times with a 3-second pause between each sample.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                Button(onClick = onStartOwnerVoiceSetup, enabled = wakeWordEnabled, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
                    Icon(Icons.Outlined.Mic, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(7.dp)); Text("Set up my voice (3 samples)")
                }
                if (!wakeWordEnabled) Text("First enable the Hey Jarvis listener above and allow microphone/notification permissions.", color = Color(0xFFFFCBA0), fontSize = 11.sp, lineHeight = 16.sp)
            }
            Text("Important: this is an experimental convenience filter, not secure identity verification. Similarity threshold needs real phone testing; recordings or imitation may fool it, and it may reject your real voice. Audio samples are not stored, only a local encrypted vector. It cannot unlock Android's device lock. Use PIN/pattern/biometrics for real phone unlock.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
        SettingsSection("PHONE CONTROL PERMISSIONS") {
            Text("Open installed apps and search songs without Accessibility. Enable this optional Android service for Back/Home/scroll, media controls, screen lock, and best-effort message drafting. Android lets it inspect visible screen text only after you turn it on manually. For a message, Jarvis may type the recipient/search and draft, but you must verify who is selected and what text is shown before saying ‘confirm send’. App screen layouts can change, so automation may stop and ask you to tap manually.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
            OutlinedButton(onClick = onOpenAccessibility, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
                Icon(Icons.Outlined.OpenInNew, null, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(7.dp))
                Text("Open Accessibility Settings")
            }
            Text("Microphone permission is requested when you tap the mic or start Hey Jarvis. Owner voice matching is an experimental convenience filter for hands-free commands only, not a secure identity check. Voice commands cannot bypass Android's secure phone lock. Use your usual phone PIN/pattern/biometric to unlock the device.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
        SettingsSection("NATURAL VOICE") {
            SettingSwitch("Speak replies aloud", settings.speakReplies) { onChange(settings.copy(speakReplies = it)) }
            Field("Voice language tag", settings.voiceLanguage, { onChange(settings.copy(voiceLanguage = it)) }, hint = "hi-IN, en-IN, en-US")
            Text("Speech rate · ${"%.2f".format(Locale.US, settings.speechRate)}", color = Muted, fontSize = 12.sp)
            Slider(value = settings.speechRate, onValueChange = { onChange(settings.copy(speechRate = it)) }, valueRange = 0.75f..1.2f)
            Text("Pitch · ${"%.2f".format(Locale.US, settings.speechPitch)}", color = Muted, fontSize = 12.sp)
            Slider(value = settings.speechPitch, onValueChange = { onChange(settings.copy(speechPitch = it)) }, valueRange = 0.8f..1.2f)
            Text("Uses the best matching locally available Android TTS voice. Install a high-quality Hindi/English voice in your phone's Text-to-speech settings for a more natural sound. Tap-to-talk works when you press the mic. Hands-free ‘Hey Jarvis’ works only after you start the optional listener in Settings and allow its permissions.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
        if (testStatus.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0D202B)), shape = RoundedCornerShape(13.dp)) {
                Text(testStatus, modifier = Modifier.padding(12.dp), color = if (testStatus.contains("connected", true)) Mint else Color(0xFFFFCBA0), fontSize = 12.sp)
            }
        }
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Outlined.CheckCircle, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(7.dp)); Text("Save settings") }
        SettingsSection("APP LOCK") {
            var newPin by remember { mutableStateOf("") }
            var confirmPin by remember { mutableStateOf("") }
            var pinStatus by remember { mutableStateOf("") }
            if (hasAppPin) {
                Text("App lock is enabled. Your PIN is stored as a salted PBKDF2 hash; it is not saved as readable text.", color = Mint, fontSize = 12.sp, lineHeight = 17.sp)
                OutlinedButton(onClick = onLockNow, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) { Icon(Icons.Outlined.Lock, null); Spacer(Modifier.width(7.dp)); Text("Lock Jarvis now") }
                OutlinedButton(onClick = onRemovePin, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) { Text("Remove app PIN", color = Color(0xFFFF9A9A)) }
            } else {
                Text("Set an optional 6–12 digit PIN to lock Jarvis when you reopen it. Keep your device lock enabled too.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                OutlinedTextField(value = newPin, onValueChange = { newPin = it.filter(Char::isDigit).take(12) }, label = { Text("New PIN") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), colors = fieldColors(), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = confirmPin, onValueChange = { confirmPin = it.filter(Char::isDigit).take(12) }, label = { Text("Confirm PIN") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), colors = fieldColors(), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    if (newPin.length !in 6..12) pinStatus = "PIN must contain 6–12 digits."
                    else if (newPin != confirmPin) pinStatus = "PINs do not match."
                    else {
                        runCatching { onSetPin(newPin) }.onSuccess { pinStatus = "PIN saved. Lock Jarvis now to test it." }.onFailure { pinStatus = it.message ?: "Could not save PIN." }
                    }
                }, enabled = newPin.length >= 6 && confirmPin.length >= 6, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) { Text("Set app PIN") }
                if (pinStatus.isNotBlank()) Text(pinStatus, color = if (pinStatus.contains("saved", true)) Mint else Color(0xFFFFCBA0), fontSize = 11.sp)
            }
        }
        SettingsSection("BACKUP & DATA") {
            Text("Export or restore settings, chat history and saved memories in a password-encrypted .jrb file.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
            OutlinedButton(onClick = onBackup, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) { Icon(Icons.Outlined.Backup, null); Spacer(Modifier.width(8.dp)); Text("Create encrypted backup") }
            OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) { Icon(Icons.Outlined.Refresh, null); Spacer(Modifier.width(8.dp)); Text("Restore encrypted backup") }
            OutlinedButton(onClick = onClearChat, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) { Icon(Icons.Outlined.DeleteOutline, null); Spacer(Modifier.width(8.dp)); Text("Clear chat history") }
            OutlinedButton(onClick = onClearMemory, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) { Icon(Icons.Outlined.Lock, null); Spacer(Modifier.width(8.dp)); Text("Clear saved memory") }
        }
        SettingsSection("PRIVACY NOTES") {
            Text("• No account or analytics service is required.\n• The chat and saved memory are kept in encrypted app storage.\n• When online mode or web search runs, the relevant query/context is sent to the configured provider or search site.\n• Never put an API key in GitHub or a public ZIP.\n• Sensitive external actions are not silently completed; verify calls, messages and payments yourself.", color = Muted, fontSize = 11.sp, lineHeight = 17.sp)
        }
        Spacer(Modifier.height(22.dp))
    }
}

@Composable
private fun PinLockPanel(onSubmit: (String) -> Boolean) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(90.dp).clip(CircleShape).background(Color(0xFF0D2735)).border(1.dp, Cyan.copy(alpha = 0.7f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.Lock, null, tint = Cyan, modifier = Modifier.size(42.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text("Jarvis is locked", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Enter your app PIN to continue.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = { pin = it.filter(Char::isDigit).take(12); error = "" },
            label = { Text("6–12 digit PIN") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            colors = fieldColors(),
            shape = RoundedCornerShape(15.dp),
            modifier = Modifier.fillMaxWidth()
        )
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9A9A), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(14.dp))
        Button(onClick = { if (!onSubmit(pin)) error = "Incorrect PIN. Try again." }, enabled = pin.isNotBlank(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("Unlock Jarvis") }
    }
}

@Composable
private fun PageTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel.copy(alpha = 0.96f)),
        shape = RoundedCornerShape(19.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, Cyan.copy(alpha = 0.12f), RoundedCornerShape(19.dp))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Mint, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun Field(label: String, value: String, onValue: (String) -> Unit, hint: String = "") {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        placeholder = { if (hint.isNotBlank()) Text(hint, color = Muted) },
        singleLine = true,
        colors = fieldColors(),
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun RouterChoice(label: String, choice: RouterMode, current: RouterMode, onSelect: (RouterMode) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onSelect(choice) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = current == choice, onClick = { onSelect(choice) })
        Text(label, fontSize = 12.sp, color = if (current == choice) Color(0xFFEAF4FC) else Muted, lineHeight = 16.sp)
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 12.sp, lineHeight = 16.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun EmptyPanel(title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, textAlign = TextAlign.Center, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color(0xFFEAF4FC),
    unfocusedTextColor = Color(0xFFEAF4FC),
    focusedBorderColor = Cyan,
    unfocusedBorderColor = Color(0xFF304658),
    focusedLabelColor = Cyan,
    unfocusedLabelColor = Muted,
    cursorColor = Cyan,
    focusedContainerColor = Color(0xFF0A121C),
    unfocusedContainerColor = Color(0xFF0A121C),
    focusedPlaceholderColor = Muted,
    unfocusedPlaceholderColor = Muted
)
