# Device test checklist

## Build/install
- [ ] Run the GitHub Actions workflow and confirm `assembleDebug` succeeds.
- [ ] Install the generated debug APK on the target Android phone.
- [ ] Open the app and rotate the screen / switch apps without losing chat.

## Local AI
- [ ] Start `llama-server` with a local model and matching alias.
- [ ] In Settings, tap **Test local connection**.
- [ ] Set router to AUTO and send a normal prompt; verify route shows `local`.
- [ ] Stop the local server and confirm the app reports a connection problem or falls back online only when configured.

## Online routing and web
- [ ] Configure a provider endpoint/model/key, then test it.
- [ ] Ask a current-facts question and verify the app performs web search when enabled.
- [ ] Confirm response source URLs open and that API errors don't delete the user message.
- [ ] Set LOCAL ONLY and verify online AI/web search are not attempted.

## Voice and images
- [ ] Grant microphone permission and test Hindi/Hinglish and English input. Confirm recognised speech is automatically submitted without pressing Send.
- [ ] Ask a local-model question and confirm partial answer text appears before generation completes.
- [ ] Send an answer that may contain `<think>` markers; verify they are neither displayed nor spoken.
- [ ] Test generic installed-app commands: `open Spotify`, `Instagram open karo`, `Chrome kholo`, and an additional installed app not listed in the fixed aliases.
- [ ] Start the Hey Jarvis listener from Settings; verify runtime microphone + notification prompts, persistent notification, and Stop control.
- [ ] Say `Hey Jarvis, open YouTube`; then try `Hey Jarvis` followed by `Instagram open karo` within 10 seconds.
- [ ] Test app-launch phrasing: `Hey Jarvis, open Instagram`, `Spotify open karo`, `YouTube kholo`, `Chrome khol do`, `Settings open karo`, and one other installed launchable app.
- [ ] Test song phrasing: `Hey Jarvis, YouTube kholo aur Tu Hai Kahan song play karo`, `play Tu Hai Kahan on YouTube`, `Tu Hai Kahan gaana bajao`, and `Spotify par Tu Hai Kahan play karo`.
- [ ] Verify the song title/platform chosen is correct; song requests open results, and only with Accessibility enabled Jarvis attempts one matching result tap. Confirm no claim of playback if the tap fails.
- [ ] Stop the listener, force-close/reopen Jarvis, and confirm the microphone is not silently started unless the user explicitly starts it again.
- [ ] With Hey Jarvis active, start Owner Voice Setup and say the same short phrase three times, pausing around 3 seconds between samples; verify the profile is saved and no command is accidentally executed during enrollment.
- [ ] Verify the hands-free listener checks a matching speaker vector before an action after enrollment; test with a second speaker and with a noisy/short command. Expect possible false rejection because the threshold is experimental.
- [ ] Delete the owner profile and verify the feature stops gating commands. Never treat it as secure authentication or device unlock.
- [ ] Enable Jarvis screen controls through Android Accessibility Settings; test Back/Home/scroll and media play/pause, then disable it and verify the app reports that it is needed for those actions only.
- [ ] Test TTS on a locally installed voice; tune rate/pitch from Settings.
- [ ] Confirm model responses remain usable after switching the default to Qwen3-0.6B and measure real first-token latency, token speed, RAM use, and temperature on the target device.
- [ ] Attach a small photo/screenshot and test only with a vision-capable model.
- [ ] Deny microphone permission and confirm text chat still works.

## Memory, lock, backup
- [ ] Save and remove a memory fact; check that it is included in prompts.
- [ ] Set a 6-digit PIN, lock Jarvis, verify correct/incorrect PIN behavior.
- [ ] Export a backup with a strong password and restore it with the correct password.
- [ ] Confirm a wrong backup password does not alter existing data.
- [ ] Clear chat/memory and verify each action affects only its selected data.

## Safety
- [ ] Try a `call` command and confirm it opens the dialler instead of placing the call automatically.
- [ ] Verify the app does not silently send messages or payments.
- [ ] Run at least one offline test with mobile data/Wi-Fi disabled.

## Command routing and message-agent checks (requires a real Android device)

- Say `Hey Jarvis, Instagram kholo`; confirm the installed Instagram app opens.
- With Jarvis Accessibility enabled and Instagram visible, say `Hey Jarvis, Faizan ko hi bhej do`.
- Confirm the agent does not tap a recipient automatically; select the intended recipient on screen. Confirm the body is drafted but not sent.
- Verify the displayed recipient and message. Say `Hey Jarvis, confirm send` only after checking both; observe the app's actual send result. Do not assume that a tap guarantees delivery.
- Say `Hey Jarvis, cancel draft`; confirm the pending Jarvis message task is cleared.
- Say `Hey Jarvis, phone lock karo`; verify the screen locks only while Jarvis Accessibility is enabled. Unlock via the phone's normal PIN/pattern/biometric.
- Verify phone unlock always requires Android's ordinary PIN, pattern or biometric; no voice command should bypass the device lock.
- Check owner voice profile only as a convenience filter for hands-free commands: replay/liveness resistance is not implemented, so do not consider it secure authentication.
