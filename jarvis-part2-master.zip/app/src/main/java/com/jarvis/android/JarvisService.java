package com.jarvis.android;

import android.app.*;
import android.content.*;
import android.os.*;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.ArrayList;
import java.util.Locale;
import androidx.core.app.NotificationCompat;

public class JarvisService extends Service {
    public static final String ACTION_ON = "com.jarvis.android.action.ON";
    public static final String ACTION_SLEEP = "com.jarvis.android.action.SLEEP";
    public static final String ACTION_OFF = "com.jarvis.android.action.OFF";

    private static final int NOTIFICATION_ID = 1;
    private static final String CHANNEL_ID = "jarvis_core";
    private SpeechRecognizer recognizer;
    private boolean listening = false;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification("JARVIS ACTIVE"));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_ON : intent.getAction();
        if (ACTION_SLEEP.equals(action)) {
            stopListening();
            updateNotification("JARVIS SLEEPING");
        } else if (ACTION_OFF.equals(action)) {
            stopListening();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        } else {
            updateNotification("JARVIS ACTIVE");
            startListening();
        }
        return START_STICKY;
    }

    private void startListening() {
        if (listening || !SpeechRecognizer.isRecognitionAvailable(this)) return;
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) return;

        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle params) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float rmsdB) {}
            public void onBufferReceived(byte[] buffer) {}
            public void onEndOfSpeech() { restartListening(); }
            public void onError(int error) { restartListening(); }
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null) {
                    for (String text : matches) {
                        String lower = text.toLowerCase(Locale.ROOT).trim();
                        if (lower.contains("hey jarvis") || lower.contains("hey, jarvis")) {
                            updateNotification("JARVIS • LISTENING");
                            break;
                        }
                    }
                }
                restartListening();
            }
            public void onPartialResults(Bundle partialResults) {}
            public void onEvent(int eventType, Bundle params) {}
        });
        listening = true;
        listenOnce();
    }

    private void listenOnce() {
        if (!listening || recognizer == null) return;
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        recognizer.startListening(intent);
    }

    private void restartListening() {
        if (!listening) return;
        new Handler(Looper.getMainLooper()).postDelayed(this::listenOnce, 250);
    }

    private void stopListening() {
        listening = false;
        if (recognizer != null) {
            recognizer.cancel();
            recognizer.destroy();
            recognizer = null;
        }
    }

    private void updateNotification(String status) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, buildNotification(status));
    }

    private Notification buildNotification(String status) {
        PendingIntent on = actionPendingIntent(ACTION_ON, 10);
        PendingIntent sleep = actionPendingIntent(ACTION_SLEEP, 11);
        PendingIntent off = actionPendingIntent(ACTION_OFF, 12);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis")
            .setContentText(status)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(new NotificationCompat.Action(0, "ON", on))
            .addAction(new NotificationCompat.Action(0, "SLEEP", sleep))
            .addAction(new NotificationCompat.Action(0, "OFF", off))
            .build();
    }

    private PendingIntent actionPendingIntent(String action, int requestCode) {
        Intent intent = new Intent(this, JarvisService.class).setAction(action);
        return PendingIntent.getService(this, requestCode, intent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Jarvis Core", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Jarvis background service status");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        stopListening();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
