import { Project, ServiceItem } from '../types';

import heroImg from '../assets/images/hero_creative_studio_1791610225425.jpg';
import emberOliveImg from '../assets/images/ember_olive_concept_1791610240150.jpg';
import videoShowreelImg from '../assets/images/video_editing_showreel_1791610252924.jpg';
import posterExhibitImg from '../assets/images/poster_design_exhibit_1791610264487.jpg';
import thumbnailTechImg from '../assets/images/thumbnail_tech_creative_1791610274872.jpg';

export { heroImg };

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'ember-and-olive',
    title: 'EMBER & OLIVE',
    category: 'Websites',
    classification: 'Practice Concept',
    tagline: 'Wood-Fired Gastronomy & Artisanal Dining Digital Experience',
    description: 'A conceptual dark-themed restaurant landing page emphasizing artisanal firecraft, seasonal ingredient menus, and streamlined reservation flow.',
    longDescription: 'EMBER & OLIVE is an exploratory website design concept built to demonstrate high-end hospitality digital presence. Created as a showcase of typography, dark aesthetic photography art-direction, and touch-optimized dining reservation interactions. Note: This is an independent practice concept, not a commissioned client restaurant.',
    image: emberOliveImg,
    gallery: [emberOliveImg],
    tools: ['Figma', 'React', 'Tailwind CSS', 'TypeScript'],
    goals: [
      'Craft an immersive dark culinary atmosphere with amber & emerald accents',
      'Design an intuitive mobile-friendly table booking flow for dinners',
      'Highlight tasting courses with high-contrast food photography and clean pricing',
      'Optimize layout performance for fast mobile loading on Android and iOS devices'
    ],
    deliverables: [
      'Responsive Landing Page & Interactive Preview',
      'Component Architecture for Menu Items & Filters',
      'Reservation Modal with Time Slot Selection',
      'Mobile-First Layout Specifications'
    ],
    liveDemoUrl: '#interactive-preview',
    featured: true,
    date: '2026',
    interactiveMockupType: 'restaurant'
  },
  {
    id: 'apex-motion-showreel',
    title: 'APEX Motion Showcase',
    category: 'Video Editing',
    classification: 'Practice Concept',
    tagline: 'High-Retention Short-Form & Cinematic Color Grading Reel',
    description: 'Dynamic pacing, custom anamorphic lens flare accents, and rhythmic sound design crafted for modern social reels and brand video teasers.',
    longDescription: 'A self-initiated motion editing exploration focusing on punchy cuts, rhythmic beat-matching, and cinema-grade color passes using DaVinci Resolve. Built to experiment with narrative retention in under 60 seconds.',
    image: videoShowreelImg,
    gallery: [videoShowreelImg],
    tools: ['DaVinci Resolve', 'Premiere Pro', 'After Effects', 'Audition'],
    goals: [
      'Achieve high viewer retention through rhythmic sound transitions and zoom cuts',
      'Implement an electric cyan and emerald cinematic color grade',
      'Format for 9:16 vertical Reels and 16:9 desktop showcases',
      'Structure clean B-roll layering with animated subtitles'
    ],
    deliverables: [
      '4K 60fps Master Color-Graded Edit',
      'Optimized 9:16 TikTok / Instagram Reel Cut',
      'Sound Design Stem Pack with Foley & Risers',
      'Motion Subtitle Preset Templates'
    ],
    featured: true,
    date: '2026',
    interactiveMockupType: 'video'
  },
  {
    id: 'architectural-structure-poster',
    title: 'Architectural Form + Structure',
    category: 'Posters',
    classification: 'Practice Concept',
    tagline: 'Swiss Minimalist Graphic Poster & Exhibition Wireframe Series',
    description: 'A study in brutalist typographic hierarchy, isometric architectural drafting lines, and high-contrast graphite paper textures.',
    longDescription: 'Created as an independent design exercise exploring international typographic style (Swiss grid) fused with brutalist architecture. Utilizes structured margins, wireframe geometry, and balanced negative space suitable for both fine-art prints and digital campaign banners.',
    image: posterExhibitImg,
    gallery: [posterExhibitImg],
    tools: ['Photoshop', 'Illustrator', 'Figma'],
    goals: [
      'Establish a strict 12-column grid system with Swiss typography principles',
      'Integrate subtle wireframe isometric blueprints with deep graphite contrast',
      'Test high-resolution 300 DPI print-ready layout margins',
      'Create digital companion display variants'
    ],
    deliverables: [
      'Print-Ready 300 DPI Vector PDF & TIFF files',
      'A1 / A2 / A3 Standard Exhibition Poster Formats',
      'Digital Wallpaper & Social Promo Adaptations',
      'Design Spec Sheet with Typography Measurements'
    ],
    featured: true,
    date: '2026',
    interactiveMockupType: 'design'
  },
  {
    id: 'tech-unveiled-thumbnail',
    title: 'Tech Unveiled 4K Series',
    category: 'Thumbnails',
    classification: 'Practice Concept',
    tagline: 'High-Click-Through YouTube Thumbnail Composition & Hook Art',
    description: 'Clean visual focal points, dramatic cyan studio rim lighting, and instant readability engineered specifically for smartphone YouTube feeds.',
    longDescription: 'A focused thumbnail design study solving the common problem of visual clutter in tech content. Engineered with high subject separation, 3-word typographic hook hierarchy, and color contrast that remains legible even at small mobile screen sizes.',
    image: thumbnailTechImg,
    gallery: [thumbnailTechImg],
    tools: ['Photoshop', 'Lightroom', 'Figma'],
    goals: [
      'Maximize click-through potential with an unmistakable visual subject anchor',
      'Employ high-contrast cyan backlight to cleanly separate subject from background',
      'Ensure 100% text readability at 120px mobile thumbnail rendering size',
      'Maintain brand consistency across video series installments'
    ],
    deliverables: [
      '1920x1080 High-DPI PNG Master Files',
      'Layered PSD with Editable Headline Hook Text',
      'A/B Testing Variant Set with Alternate Color Accents',
      'Mobile Feed Contrast Verification Report'
    ],
    featured: true,
    date: '2026',
    interactiveMockupType: 'design'
  },
  {
    id: 'overall-brand-identity-hub',
    title: 'OVERALL Creative Space',
    category: 'Websites',
    classification: 'Practice Concept',
    tagline: 'Dark Glassmorphic Digital Portfolio Architecture',
    description: 'The bespoke digital studio platform built to showcase multidisciplinary digital craftsmanship with touch-first Android responsiveness.',
    longDescription: 'The core digital platform for OVERALL Creative Studio. Designed from the ground up by Dilshad to feature clean typography, obsidian surface glassmorphism, zero layout shift, and instant mobile touch navigation.',
    image: heroImg,
    gallery: [heroImg],
    tools: ['React', 'TypeScript', 'Tailwind CSS', 'Vite'],
    goals: [
      'Deliver a cohesive futuristic dark theme with #090D12 and cyan/emerald accents',
      'Maintain strict mobile touch usability with full thumb-zone navigation',
      'Eliminate artificial AI tropes like fake testimonials or ungrounded statistics',
      'Provide local project management capability for easy updates from Android'
    ],
    deliverables: [
      'Complete React SPA with TypeScript Architecture',
      'Responsive Navigation Bar and Touch-Friendly Bottom Bar',
      'Interactive Project Detail Modals & Live Previews',
      'Client Enquiry Routing via WhatsApp & Email'
    ],
    featured: false,
    date: '2026',
    interactiveMockupType: 'design'
  },
  {
    id: 'cyberpunk-launch-banner-set',
    title: 'Neon Horizon Campaign Banners',
    category: 'Banners',
    classification: 'Practice Concept',
    tagline: 'Multi-Format Social Launch & Digital Display Banners',
    description: 'Cohesive promotional banner assets designed for digital music release across Twitter/X, Spotify canvas, and web display ads.',
    longDescription: 'An experimental banner kit exploring dark cyberpunk aesthetics, synthesized waveform visuals, and rapid visual hierarchy across horizontal and square display dimensions.',
    image: posterExhibitImg,
    gallery: [posterExhibitImg],
    tools: ['Photoshop', 'Illustrator', 'Figma'],
    goals: [
      'Maintain instant recognition across 16:9, 1:1, and 4:5 social dimensions',
      'Balance dark graphite backdrops with luminous cyan and emerald accents',
      'Establish unified typography and release date hierarchy'
    ],
    deliverables: [
      'Twitter/X Header Banner (1500x500)',
      'Instagram Story & Feed Display Creatives',
      'Web Banner Ad Formats (Leaderboard, Medium Rectangle)',
      'Vector Asset Library'
    ],
    featured: false,
    date: '2026',
    interactiveMockupType: 'design'
  }
];

export const SERVICES_LIST: ServiceItem[] = [
  {
    id: 'website-design',
    title: 'Website Design & Landing Pages',
    category: 'Websites',
    tagline: 'Fast, sleek, mobile-optimized digital storefronts and personal brands',
    description: 'Transforming your concept into a responsive, modern web experience with clean dark or custom aesthetics, clear hierarchy, and smooth interactions that work seamlessly on phones and desktops.',
    whatIsIncluded: [
      'Custom UI/UX layout tailored to your project goals',
      'Mobile-first responsive design tested on Android and iOS',
      'Clean typography and purposeful visual hierarchy',
      'Interactive components (menus, cards, modals, contact forms)',
      'Deployment-ready code or design handoff specifications'
    ],
    deliverables: [
      'Complete responsive frontend code (React / Tailwind) or Figma design files',
      'Optimized lightweight asset package',
      'Interactive live preview walkthrough'
    ],
    typicalTurnaround: '5–10 business days depending on scope',
    icon: 'Layout'
  },
  {
    id: 'video-editing',
    title: 'Short-Form Video Editing',
    category: 'Video Editing',
    tagline: 'High-retention reels, TikToks, and YouTube Shorts that hook viewers',
    description: 'Fast-paced editing tailored for modern social feeds. Includes tight pacing, dynamic zooms, clean transitions, sound effects, and styled subtitles designed to maintain viewer attention.',
    whatIsIncluded: [
      'Raw footage curation and narrative pacing',
      'Cinematic color grading and lighting touch-ups',
      'Rhythmic sound design with risers, swooshes, and subtle impacts',
      'Accurate, stylized on-screen subtitles and motion graphics',
      'Optimized vertical (9:16) rendering for Instagram, TikTok, and Shorts'
    ],
    deliverables: [
      'High-bitrate MP4 masters ready for upload',
      'Project archive files and motion subtitle presets',
      'Revision rounds to dial in the exact pacing'
    ],
    typicalTurnaround: '2–4 business days per short-form video',
    icon: 'Film'
  },
  {
    id: 'poster-banner-design',
    title: 'Poster & Banner Design',
    category: 'Posters',
    tagline: 'Striking visuals for events, releases, merchandise, and digital campaigns',
    description: 'Bold visual statements crafted with intentional typography, geometric balance, and high-contrast color theory. Suitable for physical print or high-resolution digital promotion.',
    whatIsIncluded: [
      'Concept exploration with 2 distinct layout directions',
      'Strict grid typography and custom graphic composition',
      'High-resolution print preparation with CMYK / bleed settings (for print)',
      'RGB digital exports for social media headers and digital flyers'
    ],
    deliverables: [
      'Print-ready vector PDF & TIFF files (300 DPI)',
      'Web-optimized PNG / JPG formats in multiple ratios',
      'Layered source file (Photoshop / Illustrator)'
    ],
    typicalTurnaround: '3–5 business days',
    icon: 'Palette'
  },
  {
    id: 'thumbnails-social',
    title: 'YouTube Thumbnails & Social Creatives',
    category: 'Thumbnails',
    tagline: 'High-contrast visual hooks engineered to win attention in crowded feeds',
    description: 'Thumbnails are the single most important factor for video click-through. We design high-impact visuals with clear subject separation, expressive lighting, and readable typography at any scale.',
    whatIsIncluded: [
      'Subject cutouts, edge rim lighting, and facial expression enhancement',
      'Bold headline hooks with high contrast and zero visual clutter',
      'Color grading tuned for dark and light YouTube UI themes',
      'A/B testing variant options to test alternate hooks or colors'
    ],
    deliverables: [
      'Full HD 1920x1080 master thumbnails',
      'Alternate color or hook headline variations',
      'Editable layered Photoshop / Figma template'
    ],
    typicalTurnaround: '1–2 business days',
    icon: 'Sparkles'
  }
];
