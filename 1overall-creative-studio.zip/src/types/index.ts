export type ProjectCategory = 
  | 'All'
  | 'Websites'
  | 'Video Editing'
  | 'Posters'
  | 'Thumbnails'
  | 'Banners';

export type ProjectClassification = 'Practice Concept' | 'Commissioned Work';

export interface Project {
  id: string;
  title: string;
  category: Exclude<ProjectCategory, 'All'>;
  classification: ProjectClassification;
  tagline: string;
  description: string;
  longDescription: string;
  image: string;
  gallery?: string[];
  tools: string[];
  goals: string[];
  deliverables: string[];
  liveDemoUrl?: string;
  featured?: boolean;
  date: string;
  interactiveMockupType?: 'restaurant' | 'video' | 'design';
}

export interface ServiceItem {
  id: string;
  title: string;
  category: Exclude<ProjectCategory, 'All'>;
  tagline: string;
  description: string;
  whatIsIncluded: string[];
  deliverables: string[];
  typicalTurnaround: string;
  icon: string;
}

export interface Enquiry {
  id: string;
  name: string;
  contactMethod: 'WhatsApp' | 'Email' | 'Telegram' | 'Phone';
  contactValue: string;
  serviceType: string;
  description: string;
  budgetRange: string;
  createdAt: string;
  status: 'New' | 'Replied' | 'Archived';
}
