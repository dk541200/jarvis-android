/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { PortfolioSection } from './components/PortfolioSection';
import { ProjectDetailModal } from './components/ProjectDetailModal';
import { ServicesSection } from './components/ServicesSection';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { MobileBottomNav } from './components/MobileBottomNav';
import { StudioManagerModal } from './components/StudioManagerModal';
import { INITIAL_PROJECTS, SERVICES_LIST } from './data/portfolioData';
import { Project, Enquiry } from './types';

const STORAGE_KEY_PROJECTS = 'overall_studio_projects_v1';
const STORAGE_KEY_ENQUIRIES = 'overall_studio_enquiries_v1';

export default function App() {
  // Projects state with LocalStorage persistence
  const [projects, setProjects] = useState<Project[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PROJECTS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // Fallback
    }
    return INITIAL_PROJECTS;
  });

  // Client Enquiries state with LocalStorage persistence
  const [enquiries, setEnquiries] = useState<Enquiry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ENQUIRIES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch {
      // Fallback
    }
    return [];
  });

  // Active UI modal & selection states
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isStudioManagerOpen, setIsStudioManagerOpen] = useState(false);
  const [selectedServiceForEnquiry, setSelectedServiceForEnquiry] = useState<string | undefined>();
  const [activeSection, setActiveSection] = useState<string>('home');

  // Sync projects to storage
  const handleSaveProjects = (newProjects: Project[]) => {
    setProjects(newProjects);
    try {
      localStorage.setItem(STORAGE_KEY_PROJECTS, JSON.stringify(newProjects));
    } catch (err) {
      console.warn('Could not save projects to local storage', err);
    }
  };

  // Reset to initial projects
  const handleResetProjects = () => {
    setProjects(INITIAL_PROJECTS);
    try {
      localStorage.setItem(STORAGE_KEY_PROJECTS, JSON.stringify(INITIAL_PROJECTS));
    } catch (err) {
      console.warn('Could not reset projects in local storage', err);
    }
  };

  // Update enquiries in storage
  const handleUpdateEnquiries = (newEnquiries: Enquiry[]) => {
    setEnquiries(newEnquiries);
    try {
      localStorage.setItem(STORAGE_KEY_ENQUIRIES, JSON.stringify(newEnquiries));
    } catch (err) {
      console.warn('Could not save enquiries to local storage', err);
    }
  };

  // Handle new enquiry submission
  const handleEnquirySubmitted = (newEnquiry: Enquiry) => {
    const updated = [newEnquiry, ...enquiries];
    handleUpdateEnquiries(updated);
  };

  // Scroll to helper
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Handle Quote Request from Services
  const handleRequestQuote = (serviceCategory: string) => {
    setSelectedServiceForEnquiry(serviceCategory);
    scrollTo('contact');
  };

  // Intersection observer to track active section
  useEffect(() => {
    const sections = ['home', 'portfolio', 'services', 'about', 'contact'];
    const handleScroll = () => {
      const scrollPos = window.scrollY + 200;
      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#090D12] text-slate-100 flex flex-col selection:bg-[#00D9FF]/20 selection:text-[#00D9FF]">
      {/* Top Navigation */}
      <Navbar
        activeSection={activeSection}
        onOpenStudioManager={() => setIsStudioManagerOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        <Hero
          onExploreWork={() => scrollTo('portfolio')}
          onStartProject={() => scrollTo('contact')}
        />

        <PortfolioSection
          projects={projects}
          onSelectProject={(proj) => setSelectedProject(proj)}
        />

        <ServicesSection
          services={SERVICES_LIST}
          onRequestQuote={handleRequestQuote}
        />

        <AboutSection />

        <ContactSection
          selectedServicePreload={selectedServiceForEnquiry}
          onEnquirySubmitted={handleEnquirySubmitted}
        />
      </main>

      {/* Footer */}
      <Footer onOpenStudioManager={() => setIsStudioManagerOpen(true)} />

      {/* Mobile Ergonomic Bottom Bar */}
      <MobileBottomNav
        activeSection={activeSection}
        onOpenStudioManager={() => setIsStudioManagerOpen(true)}
      />

      {/* Project Detail Modal with Ember & Olive interactive preview */}
      <ProjectDetailModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        onSelectServiceForEnquiry={(category) => {
          setSelectedServiceForEnquiry(category);
          scrollTo('contact');
        }}
      />

      {/* Owner Studio Manager Modal for Dilshad */}
      <StudioManagerModal
        isOpen={isStudioManagerOpen}
        onClose={() => setIsStudioManagerOpen(false)}
        projects={projects}
        onSaveProjects={handleSaveProjects}
        enquiries={enquiries}
        onUpdateEnquiries={handleUpdateEnquiries}
        onResetProjects={handleResetProjects}
      />
    </div>
  );
}
