import React from 'react';
import { ArrowUp, ArrowUpRight, MessageSquare, Mail } from 'lucide-react';

interface FooterProps {
  onOpenStudioManager: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenStudioManager }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-white/[0.08] bg-[#070A0E] text-slate-400 py-12 sm:py-16 pb-24 md:pb-16 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          {/* Brand Info (5 cols) */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-2.5">
              <span className="w-7 h-7 rounded-lg bg-gradient-to-tr from-[#00D9FF] to-[#42E6A4] flex items-center justify-center text-slate-950 font-black text-xs">
                O
              </span>
              <span className="font-bold text-white text-base tracking-tight">
                OVERALL Creative Studio
              </span>
            </div>
            <p className="text-slate-400 leading-relaxed max-w-sm">
              Independent digital portfolio platform showcasing bespoke website designs,
              short-form video pacing, and creative graphic compositions.
            </p>
            <div className="text-slate-300 font-medium">
              Created by <span className="text-white font-semibold">Dilshad</span>
            </div>
          </div>

          {/* Quick Nav (3 cols) */}
          <div className="md:col-span-3 space-y-3">
            <span className="text-white font-semibold uppercase tracking-wider block">
              Navigation
            </span>
            <ul className="space-y-2">
              <li>
                <button
                  type="button"
                  onClick={() => scrollTo('home')}
                  className="hover:text-white transition-colors"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => scrollTo('portfolio')}
                  className="hover:text-white transition-colors"
                >
                  Featured Portfolio
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => scrollTo('services')}
                  className="hover:text-white transition-colors"
                >
                  Digital Services
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => scrollTo('about')}
                  className="hover:text-white transition-colors"
                >
                  About the Studio
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => scrollTo('contact')}
                  className="hover:text-white transition-colors"
                >
                  Project Enquiry
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Direct & Studio Access (4 cols) */}
          <div className="md:col-span-4 space-y-3">
            <span className="text-white font-semibold uppercase tracking-wider block">
              Direct Contact
            </span>
            <div className="space-y-2">
              <a
                href="https://wa.me/?text=Hello%20Dilshad,%20I%20would%20like%20to%20discuss%20a%20creative%20project%20with%20OVERALL%20Studio."
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-slate-300 hover:text-[#25D366] transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5 text-[#25D366]" />
                <span>WhatsApp Mobile Direct</span>
                <ArrowUpRight className="w-3 h-3 text-slate-500" />
              </a>
              <a
                href="mailto:dilshad.overallstudio@gmail.com?subject=Project%20Enquiry%20OVERALL%20Studio"
                className="flex items-center gap-2 text-slate-300 hover:text-[#00D9FF] transition-colors"
              >
                <Mail className="w-3.5 h-3.5 text-[#00D9FF]" />
                <span>dilshad.overallstudio@gmail.com</span>
                <ArrowUpRight className="w-3 h-3 text-slate-500" />
              </a>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={onOpenStudioManager}
                className="text-xs text-[#42E6A4] hover:underline flex items-center gap-1.5 font-medium"
              >
                <span>Studio Manager Panel (Dilshad)</span>
                <ArrowUpRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500">
          <div>
            © {new Date().getFullYear()} OVERALL Creative Studio. All sample projects are portfolio practice concepts.
          </div>

          <button
            type="button"
            onClick={scrollToTop}
            className="flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
};
