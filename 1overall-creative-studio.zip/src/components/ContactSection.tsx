import React, { useState, useEffect } from 'react';
import { Send, MessageSquare, Mail, Phone, CheckCircle2, AlertCircle, Sparkles, ExternalLink, RefreshCw } from 'lucide-react';
import { Enquiry } from '../types';

interface ContactSectionProps {
  selectedServicePreload?: string;
  onEnquirySubmitted: (enquiry: Enquiry) => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  selectedServicePreload,
  onEnquirySubmitted,
}) => {
  const [name, setName] = useState('');
  const [contactMethod, setContactMethod] = useState<'WhatsApp' | 'Email' | 'Telegram' | 'Phone'>('WhatsApp');
  const [contactValue, setContactValue] = useState('');
  const [serviceType, setServiceType] = useState('Website Design & Landing Pages');
  const [description, setDescription] = useState('');
  const [budgetRange, setBudgetRange] = useState('Flexible / To Discuss');

  // Submission & Validation States
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState<Enquiry | null>(null);

  useEffect(() => {
    if (selectedServicePreload) {
      if (selectedServicePreload.includes('Website') || selectedServicePreload === 'Websites') {
        setServiceType('Website Design & Landing Pages');
      } else if (selectedServicePreload.includes('Video') || selectedServicePreload === 'Video Editing') {
        setServiceType('Short-Form Video Editing');
      } else if (selectedServicePreload.includes('Poster') || selectedServicePreload === 'Posters' || selectedServicePreload === 'Banners') {
        setServiceType('Poster & Banner Design');
      } else if (selectedServicePreload.includes('Thumbnail') || selectedServicePreload === 'Thumbnails') {
        setServiceType('YouTube Thumbnails & Social Creatives');
      }
    }
  }, [selectedServicePreload]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!name.trim()) newErrors.name = 'Please provide your name or brand name.';
    if (!contactValue.trim()) {
      newErrors.contactValue = `Please enter your ${contactMethod.toLowerCase()} contact address or number.`;
    } else if (contactMethod === 'Email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactValue)) {
      newErrors.contactValue = 'Please enter a valid email address.';
    }
    if (!description.trim() || description.trim().length < 10) {
      newErrors.description = 'Please describe your project or idea in at least 10 characters.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);

    setTimeout(() => {
      const newEnquiry: Enquiry = {
        id: `enq_${Date.now()}`,
        name: name.trim(),
        contactMethod,
        contactValue: contactValue.trim(),
        serviceType,
        description: description.trim(),
        budgetRange,
        createdAt: new Date().toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
        status: 'New',
      };

      onEnquirySubmitted(newEnquiry);
      setIsSubmitting(false);
      setSubmitSuccess(newEnquiry);
    }, 600);
  };

  const getWhatsAppDirectLink = () => {
    const text = encodeURIComponent(
      `Hello Dilshad, I'm reaching out regarding OVERALL Creative Studio!\n\n` +
      `*Name:* ${name || 'Prospective Client'}\n` +
      `*Service:* ${serviceType}\n` +
      `*Budget:* ${budgetRange}\n` +
      `*Details:* ${description || 'I would like to discuss a project with you.'}`
    );
    return `https://wa.me/?text=${text}`;
  };

  const getMailtoLink = () => {
    const subject = encodeURIComponent(`Project Enquiry: ${serviceType} – ${name || 'Prospective Client'}`);
    const body = encodeURIComponent(
      `Hi Dilshad,\n\nI'm interested in starting a project with OVERALL Creative Studio.\n\n` +
      `Name: ${name}\n` +
      `Preferred Contact: ${contactMethod} (${contactValue})\n` +
      `Service Needed: ${serviceType}\n` +
      `Budget Range: ${budgetRange}\n\n` +
      `Project Scope:\n${description}\n\nLooking forward to hearing from you!`
    );
    return `mailto:dilshad.overallstudio@gmail.com?subject=${subject}&body=${body}`;
  };

  const handleResetForm = () => {
    setName('');
    setContactValue('');
    setDescription('');
    setSubmitSuccess(null);
  };

  return (
    <section id="contact" className="py-16 sm:py-24 relative border-t border-white/5 bg-[#090D12]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="max-w-3xl space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#00D9FF] uppercase tracking-wider">
            <span>Project Enquiry</span>
            <span aria-hidden="true">·</span>
            <span>Let's Discuss Your Vision</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
            Start a Conversation
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
            Whether you need a full landing page, video editing for your next reel, or bold graphic posters,
            share your goals below. Submissions are saved securely to the studio inbox and can be directly
            routed to WhatsApp or Email.
          </p>
        </div>

        {/* Split: Contact Form + Direct Quick Connect */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Form Container (7 cols) */}
          <div className="lg:col-span-7 bg-[#0E1520] border border-white/[0.08] rounded-2xl sm:rounded-3xl p-6 sm:p-8 shadow-xl">
            {submitSuccess ? (
              <div className="space-y-6 text-center py-6">
                <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-[#42E6A4] flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/10">
                  <CheckCircle2 className="w-8 h-8" />
                </div>

                <div className="space-y-2">
                  <h3 className="text-xl sm:text-2xl font-bold text-white">
                    Enquiry Logged Successfully!
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                    Thank you, <strong className="text-white">{submitSuccess.name}</strong>. Your enquiry for{' '}
                    <span className="text-[#00D9FF] font-medium">{submitSuccess.serviceType}</span> has been saved
                    to Dilshad's studio inbox on this device.
                  </p>
                </div>

                {/* Instant Transmission Buttons */}
                <div className="p-4 rounded-xl bg-white/[0.03] border border-white/5 space-y-3 text-left">
                  <span className="text-xs font-semibold text-white block">
                    Fast-Track Your Message Directly:
                  </span>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <a
                      href={getWhatsAppDirectLink()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 py-2.5 px-4 rounded-lg bg-[#25D366] hover:bg-[#20bd5a] text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
                    >
                      <MessageSquare className="w-4 h-4" />
                      Send to WhatsApp
                    </a>
                    <a
                      href={getMailtoLink()}
                      className="flex-1 py-2.5 px-4 rounded-lg bg-[#00D9FF] hover:bg-[#00c4e6] text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
                    >
                      <Mail className="w-4 h-4" />
                      Open in Email App
                    </a>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleResetForm}
                  className="text-xs text-slate-400 hover:text-white transition-colors flex items-center gap-1.5 mx-auto"
                >
                  <RefreshCw className="w-3.5 h-3.5" /> Submit Another Enquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Name */}
                <div>
                  <label htmlFor="contact-name" className="block text-xs font-medium text-slate-300 mb-1.5">
                    Your Name / Brand <span className="text-[#00D9FF]">*</span>
                  </label>
                  <input
                    id="contact-name"
                    type="text"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (errors.name) setErrors((prev) => ({ ...prev, name: '' }));
                    }}
                    placeholder="e.g. Alex Rivera or Horizon Audio"
                    className="w-full bg-[#121A26] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#00D9FF] transition-colors"
                  />
                  {errors.name && (
                    <p className="text-xs text-rose-400 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" /> {errors.name}
                    </p>
                  )}
                </div>

                {/* Preferred Contact Method & Value */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      Preferred Channel <span className="text-[#00D9FF]">*</span>
                    </label>
                    <select
                      value={contactMethod}
                      onChange={(e) => setContactMethod(e.target.value as any)}
                      className="w-full bg-[#121A26] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#00D9FF] transition-colors"
                    >
                      <option value="WhatsApp">WhatsApp</option>
                      <option value="Email">Email</option>
                      <option value="Telegram">Telegram</option>
                      <option value="Phone">Phone Call</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="contact-value" className="block text-xs font-medium text-slate-300 mb-1.5">
                      {contactMethod} Handle / Address <span className="text-[#00D9FF]">*</span>
                    </label>
                    <input
                      id="contact-value"
                      type="text"
                      value={contactValue}
                      onChange={(e) => {
                        setContactValue(e.target.value);
                        if (errors.contactValue) setErrors((prev) => ({ ...prev, contactValue: '' }));
                      }}
                      placeholder={
                        contactMethod === 'Email'
                          ? 'alex@example.com'
                          : contactMethod === 'WhatsApp'
                          ? '+1 555-0199 or WhatsApp ID'
                          : '@username or number'
                      }
                      className="w-full bg-[#121A26] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#00D9FF] transition-colors"
                    />
                    {errors.contactValue && (
                      <p className="text-xs text-rose-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" /> {errors.contactValue}
                      </p>
                    )}
                  </div>
                </div>

                {/* Service Type & Budget */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      Service Type <span className="text-[#00D9FF]">*</span>
                    </label>
                    <select
                      value={serviceType}
                      onChange={(e) => setServiceType(e.target.value)}
                      className="w-full bg-[#121A26] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#00D9FF] transition-colors"
                    >
                      <option value="Website Design & Landing Pages">Website Design & Landing Pages</option>
                      <option value="Short-Form Video Editing">Short-Form Video Editing</option>
                      <option value="Poster & Banner Design">Poster & Banner Design</option>
                      <option value="YouTube Thumbnails & Social Creatives">YouTube Thumbnails & Social Creatives</option>
                      <option value="Custom Creative Consultation">Custom Creative Consultation</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      Budget Range (Optional)
                    </label>
                    <select
                      value={budgetRange}
                      onChange={(e) => setBudgetRange(e.target.value)}
                      className="w-full bg-[#121A26] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#00D9FF] transition-colors"
                    >
                      <option value="Flexible / To Discuss">Flexible / To Discuss</option>
                      <option value="Under $250">Under $250 (Small Task / Single Asset)</option>
                      <option value="$250 - $500">$250 – $500 (Video Batch / Poster Series)</option>
                      <option value="$500 - $1,000">$500 – $1,000 (Landing Page / Complete Package)</option>
                      <option value="$1,000+">$1,000+ (Comprehensive Brand Project)</option>
                    </select>
                  </div>
                </div>

                {/* Project Description */}
                <div>
                  <label htmlFor="contact-desc" className="block text-xs font-medium text-slate-300 mb-1.5">
                    Project Details & Goals <span className="text-[#00D9FF]">*</span>
                  </label>
                  <textarea
                    id="contact-desc"
                    rows={4}
                    value={description}
                    onChange={(e) => {
                      setDescription(e.target.value);
                      if (errors.description) setErrors((prev) => ({ ...prev, description: '' }));
                    }}
                    placeholder="Tell me about your concept, reference links, timeline, or any specific requirements..."
                    className="w-full bg-[#121A26] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#00D9FF] transition-colors resize-y"
                  />
                  {errors.description && (
                    <p className="text-xs text-rose-400 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" /> {errors.description}
                    </p>
                  )}
                </div>

                {/* Honest Routing Disclosure */}
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  <strong>Transparency Notice:</strong> Submitting this form records your enquiry into Dilshad's
                  studio inbox in this application. You can also send it directly via WhatsApp or email below.
                </p>

                {/* Primary Submit Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-[#00D9FF] to-[#42E6A4] text-slate-950 font-bold text-sm flex items-center justify-center gap-2 hover:brightness-105 active:scale-95 transition-all shadow-lg shadow-[#00D9FF]/20 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                      <span>Recording Enquiry...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Send Project Enquiry</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>

          {/* Direct Channels & Studio Contact Info (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-[#0E1520] border border-white/[0.08] rounded-2xl sm:rounded-3xl p-6 sm:p-8 space-y-6">
              <div>
                <span className="text-xs font-semibold text-[#42E6A4] uppercase tracking-wider block">
                  Direct Inquiries
                </span>
                <h3 className="text-xl font-bold text-white mt-1">Prefer Instant Messaging?</h3>
                <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
                  If you prefer chatting directly about your project without filling a full brief,
                  use the direct studio links below:
                </p>
              </div>

              <div className="space-y-3">
                <a
                  href={getWhatsAppDirectLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-4 rounded-xl bg-white/[0.03] hover:bg-[#25D366]/10 border border-white/5 hover:border-[#25D366]/40 transition-all text-xs group"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-lg bg-[#25D366]/20 text-[#25D366]">
                      <MessageSquare className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-semibold text-white block">WhatsApp Chat</span>
                      <span className="text-slate-400">Direct mobile chat with Dilshad</span>
                    </div>
                  </div>
                  <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-[#25D366] transition-colors" />
                </a>

                <a
                  href={getMailtoLink()}
                  className="flex items-center justify-between p-4 rounded-xl bg-white/[0.03] hover:bg-[#00D9FF]/10 border border-white/5 hover:border-[#00D9FF]/40 transition-all text-xs group"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-lg bg-[#00D9FF]/20 text-[#00D9FF]">
                      <Mail className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-semibold text-white block">Direct Email</span>
                      <span className="text-slate-400">dilshad.overallstudio@gmail.com</span>
                    </div>
                  </div>
                  <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-[#00D9FF] transition-colors" />
                </a>
              </div>

              {/* Working Hours & Availability */}
              <div className="pt-4 border-t border-white/5 space-y-2 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>Studio Location:</span>
                  <span className="text-white font-medium">Remote · Global Clients</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Typical Response Time:</span>
                  <span className="text-white font-medium">Within 24 Hours</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Current Studio Status:</span>
                  <span className="text-[#42E6A4] font-medium">Accepting New Concepts</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
