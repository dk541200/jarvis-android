import React, { useState, useEffect } from 'react';
import { X, ArrowUpRight, Check, Wrench, Target, Package, Sparkles, ExternalLink } from 'lucide-react';
import { Project } from '../types';
import { EmberOliveInteractivePreview } from './EmberOliveInteractivePreview';

interface ProjectDetailModalProps {
  project: Project | null;
  onClose: () => void;
  onSelectServiceForEnquiry: (category: string) => void;
}

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  project,
  onClose,
  onSelectServiceForEnquiry,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'interactive'>('overview');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  useEffect(() => {
    // If it's Ember & Olive, default to interactive demo or overview
    setActiveTab('overview');
  }, [project]);

  if (!project) return null;

  const isRestaurantConcept = project.id === 'ember-and-olive';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-project-title"
      className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200"
    >
      <div
        className="fixed inset-0"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal Surface */}
      <div className="relative z-10 w-full max-w-4xl bg-[#0C121A] border border-white/10 rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col my-auto">
        {/* Header Bar */}
        <div className="px-5 sm:px-8 py-4 sm:py-5 border-b border-white/10 flex items-center justify-between gap-4 bg-[#0F1722]/90 backdrop-blur-md sticky top-0 z-20">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
              <span className="text-[#00D9FF]">{project.category}</span>
              <span aria-hidden="true">·</span>
              <span className={project.classification === 'Practice Concept' ? 'text-amber-400 font-medium' : 'text-emerald-400 font-medium'}>
                {project.classification}
              </span>
            </div>
            <h2 id="modal-project-title" className="text-lg sm:text-xl font-bold text-white truncate mt-0.5">
              {project.title}
            </h2>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {isRestaurantConcept && (
              <div className="flex p-0.5 bg-black/40 rounded-lg border border-white/10 text-xs">
                <button
                  type="button"
                  onClick={() => setActiveTab('overview')}
                  className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                    activeTab === 'overview' ? 'bg-[#00D9FF]/20 text-[#00D9FF]' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Overview
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('interactive')}
                  className={`px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1 ${
                    activeTab === 'interactive' ? 'bg-amber-500/20 text-amber-300' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  Live Prototype
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={onClose}
              className="min-w-[40px] min-h-[40px] rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-8 overflow-y-auto space-y-8 flex-1">
          {activeTab === 'interactive' && isRestaurantConcept ? (
            <div className="space-y-4">
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-xs text-amber-300 leading-relaxed">
                <strong>Interactive Concept Showcase:</strong> Below is a working preview of the EMBER & OLIVE culinary concept created by Dilshad. Test the menu tabs, filter items, and experience the table reservation simulator directly.
              </div>
              <EmberOliveInteractivePreview />
            </div>
          ) : (
            <>
              {/* Media Container with fallback */}
              <div className="rounded-xl overflow-hidden border border-white/10 bg-[#090D12] relative aspect-video max-h-96">
                <img
                  src={project.image}
                  alt={project.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3 bg-[#090D12]/90 backdrop-blur-md px-3 py-1 rounded-md border border-white/10 text-xs font-mono text-slate-300">
                  {project.classification} · {project.date}
                </div>
              </div>

              {/* Tagline & Concept Disclosure */}
              <div className="space-y-3">
                <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                  {project.tagline}
                </h3>
                <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                  {project.longDescription || project.description}
                </p>

                {project.classification === 'Practice Concept' && (
                  <div className="p-3.5 rounded-xl bg-amber-500/[0.08] border border-amber-500/20 text-xs text-amber-300/90 leading-relaxed flex items-start gap-2.5">
                    <span className="font-semibold uppercase tracking-wider text-amber-400 mt-0.5">Note:</span>
                    <span>
                      This is an independent creative portfolio exploration designed by Dilshad to showcase design and production capability. It is not an endorsed client commission.
                    </span>
                  </div>
                )}
              </div>

              {/* Interactive Prototype Banner for Ember & Olive */}
              {isRestaurantConcept && (
                <div className="p-4 rounded-xl bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/25 flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <h4 className="text-white font-semibold text-sm">Interactive Restaurant Prototype Available</h4>
                    <p className="text-xs text-slate-400 mt-0.5">Explore the live food menu, smoke flavor profiles, and simulate table bookings.</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTab('interactive')}
                    className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    Launch Interactive Demo
                  </button>
                </div>
              )}

              {/* Grid: Tools Used, Goals, Deliverables */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                {/* Tools */}
                <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#00D9FF] uppercase tracking-wider">
                    <Wrench className="w-3.5 h-3.5" />
                    <span>Tools & Tech</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {project.tools.map((tool) => (
                      <span
                        key={tool}
                        className="text-xs px-2.5 py-1 rounded-md bg-white/5 text-slate-300 font-mono"
                      >
                        {tool}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Goals */}
                <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#42E6A4] uppercase tracking-wider">
                    <Target className="w-3.5 h-3.5" />
                    <span>Project Goals</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-300">
                    {project.goals.map((goal, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-[#42E6A4] shrink-0 mt-0.5" />
                        <span>{goal}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Deliverables */}
                <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 uppercase tracking-wider">
                    <Package className="w-3.5 h-3.5 text-[#00D9FF]" />
                    <span>Deliverables</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-300">
                    {project.deliverables.map((del, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-[#00D9FF] shrink-0 mt-0.5" />
                        <span>{del}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Modal Footer CTA */}
        <div className="px-5 sm:px-8 py-4 border-t border-white/10 bg-[#0A0E15] flex flex-wrap items-center justify-between gap-4">
          <div className="text-xs text-slate-400">
            Looking for something similar for your brand?
          </div>
          <button
            type="button"
            onClick={() => {
              onSelectServiceForEnquiry(project.category);
              onClose();
            }}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#00D9FF] to-[#42E6A4] text-slate-950 font-bold text-xs sm:text-sm flex items-center gap-2 transition-all hover:brightness-105 active:scale-95"
          >
            <span>Discuss This Service</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
