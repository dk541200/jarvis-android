import React from 'react';
import { Home, FolderGit2, Briefcase, Send, SlidersHorizontal } from 'lucide-react';

interface MobileBottomNavProps {
  activeSection: string;
  onOpenStudioManager: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeSection,
  onOpenStudioManager,
}) => {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'portfolio', label: 'Work', icon: FolderGit2 },
    { id: 'services', label: 'Services', icon: Briefcase },
    { id: 'contact', label: 'Contact', icon: Send },
  ];

  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-[#090D12]/92 backdrop-blur-xl border-t border-white/[0.08] px-2 py-1.5 transition-all"
      aria-label="Mobile Bottom Navigation"
    >
      <div className="grid grid-cols-5 items-center justify-items-center h-12 max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => scrollTo(item.id)}
              className={`min-w-[48px] min-h-[48px] flex flex-col items-center justify-center transition-colors active:scale-95 ${
                isActive ? 'text-[#00D9FF]' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className={`text-[10px] font-medium tracking-tight mt-0.5 ${isActive ? 'font-bold' : ''}`}>
                {item.label}
              </span>
            </button>
          );
        })}

        {/* 5th item: Studio Manager for Dilshad */}
        <button
          type="button"
          onClick={onOpenStudioManager}
          className="min-w-[48px] min-h-[48px] flex flex-col items-center justify-center text-slate-400 hover:text-[#42E6A4] active:scale-95 transition-colors"
          title="Studio Manager"
        >
          <SlidersHorizontal className="w-5 h-5 text-[#42E6A4]" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5 text-[#42E6A4]">
            Studio
          </span>
        </button>
      </div>
    </nav>
  );
};
