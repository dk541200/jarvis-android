import React from 'react';
import { Smartphone, Monitor, Sparkles, Code2, Film, Palette, Terminal } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-16 sm:py-24 relative border-t border-white/5 bg-[#0A0F16]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="max-w-3xl space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#00D9FF] uppercase tracking-wider">
            <span>Studio Identity</span>
            <span aria-hidden="true">·</span>
            <span>Created by Dilshad</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
            About OVERALL Creative Studio
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
            An independent creative initiative built on the belief that purposeful design,
            clean motion pacing, and honest craftsmanship make lasting digital experiences.
          </p>
        </div>

        {/* Narrative Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Main Story (8 cols) */}
          <div className="lg:col-span-7 space-y-6 text-sm sm:text-base text-slate-300 leading-relaxed font-light">
            <p>
              OVERALL Creative Studio was founded by <strong className="text-white font-semibold">Dilshad</strong> as
              a personal digital workshop. Rather than relying on boilerplate templates, the studio focuses
              on creating custom-designed websites, high-retention video edits, posters, and YouTube thumbnails
              with strong visual impact and high attention to detail.
            </p>
            <p>
              As a creator working hands-on and frequently managing projects directly from mobile and desktop
              environments, every solution is built mobile-first. That means responsive layouts that look exceptional
              on an Android screen, swift interaction latency, and clean interfaces free of bloated code or generic tropes.
            </p>
            <p>
              I believe in total transparency: all sample projects in this studio are openly labeled as self-initiated
              practice concepts. As new commissioned collaborations are completed, they will take their place here
              with genuine case studies.
            </p>

            {/* Principles */}
            <div className="pt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-white/[0.03] border border-white/5 space-y-1.5">
                <span className="font-semibold text-white block">Visual Restraint</span>
                <p className="text-slate-400">
                  Carefully tuned dark palettes, high contrast typography, and zero visual clutter.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-white/[0.03] border border-white/5 space-y-1.5">
                <span className="font-semibold text-white block">Mobile-First Practicality</span>
                <p className="text-slate-400">
                  Ergonomically tuned for touch thumbs, fast Android load times, and fluid responsive scaling.
                </p>
              </div>
            </div>
          </div>

          {/* Tools & Workflow Card (5 cols) */}
          <div className="lg:col-span-5 bg-[#0E1520] border border-white/[0.08] rounded-2xl p-6 sm:p-8 space-y-6">
            <div className="border-b border-white/5 pb-4">
              <span className="text-xs font-mono text-[#42E6A4] uppercase tracking-wider block">
                Workflow & Production Stack
              </span>
              <h3 className="text-lg font-bold text-white mt-1">Tools of the Studio</h3>
            </div>

            <div className="space-y-4 text-xs">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-white/5 text-[#00D9FF]">
                  <Code2 className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-semibold text-white block">Web Engineering</span>
                  <span className="text-slate-400">React, TypeScript, Tailwind CSS, Vite, HTML5 Semantics</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-white/5 text-[#42E6A4]">
                  <Film className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-semibold text-white block">Motion & Video</span>
                  <span className="text-slate-400">DaVinci Resolve, Premiere Pro, After Effects, Sound Design</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-white/5 text-[#00D9FF]">
                  <Palette className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-semibold text-white block">Graphic & Visual Layout</span>
                  <span className="text-slate-400">Photoshop, Illustrator, Figma, Typography Grids</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-white/5 text-[#42E6A4]">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-semibold text-white block">Mobile Deployment</span>
                  <span className="text-slate-400">Android touch audits, cross-browser responsiveness</span>
                </div>
              </div>
            </div>

            {/* Owner Credit Card Footnote */}
            <div className="pt-4 border-t border-white/5 text-xs text-slate-400 flex items-center justify-between">
              <span>Studio Founder & Designer</span>
              <span className="text-white font-medium">Dilshad</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
