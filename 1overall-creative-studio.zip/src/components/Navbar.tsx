import React, { useState } from 'react';
import { Menu, X, ArrowUpRight, SlidersHorizontal, Sparkles } from 'lucide-react';

interface NavbarProps {
  onOpenStudioManager: () => void;
  activeSection: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenStudioManager, activeSection }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'Portfolio', href: '#portfolio' },
    { label: 'Services', href: '#services' },
    { label: 'About', href: '#about' },
    { label: 'Contact', href: '#contact' },
  ];

  const scrollTo = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#090D12]/85 backdrop-blur-xl border-b border-white/[0.08] transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 sm:h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Top Bar Contract: 1 single text element) */}
        <a
          href="#home"
          onClick={(e) => {
            e.preventDefault();
            scrollTo('#home');
          }}
          className="group flex items-center gap-2.5 whitespace-nowrap shrink-0 text-white font-bold tracking-tight text-lg sm:text-xl font-sans"
        >
          <span className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#00D9FF] to-[#42E6A4] flex items-center justify-center text-slate-950 font-black text-sm shadow-lg shadow-[#00D9FF]/20 group-hover:scale-105 transition-transform">
            O
          </span>
          <span className="font-extrabold tracking-tight">OVERALL</span>
          <span className="text-xs text-slate-400 font-normal hidden lg:inline tracking-wider uppercase ml-1">
            Studio
          </span>
        </a>

        {/* Zone 2: 4-5 Clean Nav Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300">
          {navLinks.map((link) => {
            const isActive = activeSection === link.label.toLowerCase();
            return (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  scrollTo(link.href);
                }}
                className={`whitespace-nowrap shrink-0 transition-colors py-1 relative ${
                  isActive ? 'text-[#00D9FF] font-semibold' : 'text-slate-300 hover:text-white'
                }`}
              >
                {link.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-[#00D9FF] to-[#42E6A4] rounded-full" />
                )}
              </a>
            );
          })}
        </nav>

        {/* Zone 3: 1 Primary Action + Studio Manager trigger */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenStudioManager}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] rounded-lg transition-colors whitespace-nowrap shrink-0"
            title="Open Studio Manager (Portfolio & Enquiries for Dilshad)"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-[#42E6A4]" />
            <span className="hidden sm:inline">Studio Manager</span>
          </button>

          <a
            href="#contact"
            onClick={(e) => {
              e.preventDefault();
              scrollTo('#contact');
            }}
            className="px-4 py-2 text-xs sm:text-sm font-semibold text-slate-950 bg-gradient-to-r from-[#00D9FF] to-[#42E6A4] hover:opacity-95 rounded-lg transition-all duration-200 shadow-md shadow-[#00D9FF]/20 flex items-center gap-1.5 whitespace-nowrap shrink-0 active:scale-95"
          >
            <span>Start a Project</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>

          {/* Mobile Menu Button */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden min-w-[44px] min-h-[44px] flex items-center justify-center text-slate-300 hover:text-white focus:outline-none"
            aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0C121A] border-b border-white/10 px-6 py-5 space-y-4 animate-in slide-in-from-top-2 duration-200">
          <div className="flex flex-col space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  scrollTo(link.href);
                }}
                className="text-base font-medium text-slate-200 hover:text-[#00D9FF] py-2 border-b border-white/5 transition-colors"
              >
                {link.label}
              </a>
            ))}
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenStudioManager();
              }}
              className="flex items-center gap-2 text-base font-medium text-[#42E6A4] py-2 transition-colors text-left"
            >
              <SlidersHorizontal className="w-4 h-4" />
              Studio Manager (Projects & Enquiries)
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
