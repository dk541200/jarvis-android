import React from 'react';
import { ServiceItem } from '../types';
import { Layout, Film, Palette, Sparkles, ArrowRight, Check, Clock } from 'lucide-react';

interface ServicesSectionProps {
  services: ServiceItem[];
  onRequestQuote: (serviceCategory: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  services,
  onRequestQuote,
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Layout':
        return <Layout className="w-6 h-6 text-[#00D9FF]" />;
      case 'Film':
        return <Film className="w-6 h-6 text-[#42E6A4]" />;
      case 'Palette':
        return <Palette className="w-6 h-6 text-[#00D9FF]" />;
      case 'Sparkles':
      default:
        return <Sparkles className="w-6 h-6 text-[#42E6A4]" />;
    }
  };

  return (
    <section id="services" className="py-16 sm:py-24 relative border-t border-white/5 bg-[#090D12]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="max-w-3xl space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#42E6A4] uppercase tracking-wider">
            <span>Capabilities & Offerings</span>
            <span aria-hidden="true">·</span>
            <span>Transparent Creative Services</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
            Specialized Digital Services
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
            Every engagement is approached with focused craft and clear communication. Here is what is
            included in each discipline, how deliverables are structured, and typical turnaround expectations.
          </p>
        </div>

        {/* Services Grid (2x2 or 4-column) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service) => (
            <div
              key={service.id}
              className="rounded-2xl sm:rounded-3xl bg-[#0D141F] border border-white/[0.08] p-6 sm:p-8 flex flex-col justify-between space-y-6 hover:border-[#00D9FF]/30 transition-all duration-300 group shadow-lg"
            >
              <div className="space-y-4">
                {/* Top Bar with Icon and Category */}
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-white/[0.04] border border-white/10 flex items-center justify-center">
                    {getIcon(service.icon)}
                  </div>
                  <span className="text-xs font-mono text-slate-400">
                    {service.category}
                  </span>
                </div>

                {/* Title & Tagline */}
                <div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white group-hover:text-[#00D9FF] transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#42E6A4] font-medium mt-1">
                    {service.tagline}
                  </p>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {service.description}
                </p>

                {/* What's Included */}
                <div className="space-y-2.5 pt-2">
                  <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider block">
                    What is Included:
                  </span>
                  <ul className="space-y-2 text-xs text-slate-300">
                    {service.whatIsIncluded.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <Check className="w-4 h-4 text-[#42E6A4] shrink-0 mt-0.5" />
                        <span className="leading-relaxed">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Turnaround info */}
                <div className="flex items-center gap-2 text-xs text-slate-400 pt-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Timeline: {service.typicalTurnaround}</span>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-4 border-t border-white/5">
                <button
                  type="button"
                  onClick={() => onRequestQuote(service.category)}
                  className="w-full py-3 px-4 rounded-xl bg-white/[0.04] hover:bg-gradient-to-r hover:from-[#00D9FF] hover:to-[#42E6A4] hover:text-slate-950 text-white font-semibold text-xs sm:text-sm border border-white/10 hover:border-transparent flex items-center justify-center gap-2 transition-all duration-200 active:scale-95 group/btn"
                >
                  <span>Request a Quote for {service.category}</span>
                  <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
