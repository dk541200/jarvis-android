import React, { useState } from 'react';
import { Project, ProjectCategory } from '../types';
import { ArrowUpRight, Filter, Sparkles, FolderSearch } from 'lucide-react';

interface PortfolioSectionProps {
  projects: Project[];
  onSelectProject: (project: Project) => void;
}

export const PortfolioSection: React.FC<PortfolioSectionProps> = ({
  projects,
  onSelectProject,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<ProjectCategory>('All');

  const categories: ProjectCategory[] = [
    'All',
    'Websites',
    'Video Editing',
    'Posters',
    'Thumbnails',
    'Banners',
  ];

  const filteredProjects = selectedCategory === 'All'
    ? projects
    : projects.filter((p) => p.category === selectedCategory);

  return (
    <section id="portfolio" className="py-16 sm:py-24 relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#00D9FF] uppercase tracking-wider">
              <span>Selected Works</span>
              <span aria-hidden="true">·</span>
              <span>Portfolio Concepts & Showcases</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
              Featured Creations
            </h2>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              A curated collection of digital experiences, motion edits, and graphic compositions.
              Every concept is transparently tagged to distinguish self-initiated practice works
              from client commissions.
            </p>
          </div>

          <div className="text-xs text-slate-400 font-mono">
            Showing {filteredProjects.length} of {projects.length} works
          </div>
        </div>

        {/* Category Filters (Accessible Segmented Control Tabs) */}
        <div className="flex items-center overflow-x-auto pb-2 scrollbar-none gap-2">
          {categories.map((category) => {
            const isActive = selectedCategory === category;
            return (
              <button
                key={category}
                type="button"
                onClick={() => setSelectedCategory(category)}
                className={`min-h-[42px] px-4 py-2 rounded-xl text-xs sm:text-sm font-medium whitespace-nowrap transition-all duration-200 border ${
                  isActive
                    ? 'bg-gradient-to-r from-[#00D9FF] to-[#42E6A4] text-slate-950 font-bold border-transparent shadow-md shadow-[#00D9FF]/15'
                    : 'bg-white/[0.03] text-slate-300 hover:text-white border-white/[0.08] hover:bg-white/[0.07]'
                }`}
              >
                {category}
              </button>
            );
          })}
        </div>

        {/* Projects Grid or Empty State */}
        {filteredProjects.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-[#0E1520] border border-white/5 space-y-4 max-w-md mx-auto my-8">
            <FolderSearch className="w-12 h-12 text-slate-500 mx-auto" />
            <h3 className="text-lg font-semibold text-white">No projects found</h3>
            <p className="text-xs text-slate-400">
              There are currently no items under "{selectedCategory}". You can reset the filter or add new projects via the Studio Manager.
            </p>
            <button
              type="button"
              onClick={() => setSelectedCategory('All')}
              className="text-xs text-[#00D9FF] hover:underline font-medium"
            >
              Reset to All Projects
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {filteredProjects.map((project) => (
              <div
                key={project.id}
                onClick={() => onSelectProject(project)}
                className="group cursor-pointer rounded-2xl bg-[#0D141F] border border-white/[0.08] hover:border-[#00D9FF]/40 transition-all duration-300 overflow-hidden flex flex-col shadow-lg hover:shadow-2xl hover:shadow-[#00D9FF]/10 active:scale-[0.99]"
              >
                {/* Image Container with Fallback */}
                <div className="relative aspect-video overflow-hidden bg-[#090D12]">
                  <img
                    src={project.image}
                    alt={project.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  {/* Subtle Gradient Scrim */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0D141F] via-transparent to-transparent opacity-80" />

                  {/* Corner Badge: Concept Tagging (Clear Distinction) */}
                  <div className="absolute top-3 left-3 bg-[#090D12]/90 backdrop-blur-md px-2.5 py-1 rounded-md border border-white/10 text-[11px] font-mono">
                    <span className={project.classification === 'Practice Concept' ? 'text-amber-400' : 'text-emerald-400'}>
                      {project.classification}
                    </span>
                  </div>

                  {project.id === 'ember-and-olive' && (
                    <div className="absolute top-3 right-3 bg-amber-500/90 text-slate-950 font-bold px-2 py-0.5 rounded text-[10px] flex items-center gap-1 shadow">
                      <Sparkles className="w-3 h-3" /> Live Demo
                    </div>
                  )}
                </div>

                {/* Card Content */}
                <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    {/* Unboxed Metadata Line (No pills, clean separator) */}
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <span className="text-[#00D9FF] font-medium">{project.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{project.date}</span>
                    </div>

                    <h3 className="text-lg sm:text-xl font-bold text-white group-hover:text-[#00D9FF] transition-colors">
                      {project.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-slate-300 line-clamp-2 leading-relaxed">
                      {project.description}
                    </p>
                  </div>

                  {/* Tools + Action Link */}
                  <div className="pt-2 border-t border-white/5 flex items-center justify-between text-xs text-slate-400">
                    <div className="truncate max-w-[65%]">
                      {project.tools.slice(0, 3).join(' · ')}
                    </div>
                    <span className="text-[#00D9FF] font-medium group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform flex items-center gap-1">
                      Explore <ArrowUpRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
