import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Trash2,
  Edit2,
  Download,
  Upload,
  CheckCircle,
  AlertTriangle,
  FolderGit2,
  Inbox,
  ShieldCheck,
  RefreshCcw,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { Project, ProjectCategory, ProjectClassification, Enquiry } from '../types';

interface StudioManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  projects: Project[];
  onSaveProjects: (projects: Project[]) => void;
  enquiries: Enquiry[];
  onUpdateEnquiries: (enquiries: Enquiry[]) => void;
  onResetProjects: () => void;
}

export const StudioManagerModal: React.FC<StudioManagerModalProps> = ({
  isOpen,
  onClose,
  projects,
  onSaveProjects,
  enquiries,
  onUpdateEnquiries,
  onResetProjects,
}) => {
  const [activeTab, setActiveTab] = useState<'projects' | 'enquiries' | 'backend-roadmap'>('projects');

  // New / Editing project state
  const [isEditing, setIsEditing] = useState(false);
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);

  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState<Exclude<ProjectCategory, 'All'>>('Websites');
  const [formClassification, setFormClassification] = useState<ProjectClassification>('Practice Concept');
  const [formTagline, setFormTagline] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formTools, setFormTools] = useState('React, Tailwind CSS, TypeScript');
  const [formImage, setFormImage] = useState('');
  const [formGoals, setFormGoals] = useState('Responsive layout, High contrast typography');
  const [formDeliverables, setFormDeliverables] = useState('Complete code repo, Mobile specifications');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleStartAdd = () => {
    setIsEditing(true);
    setEditingProjectId(null);
    setFormTitle('');
    setFormCategory('Websites');
    setFormClassification('Practice Concept');
    setFormTagline('');
    setFormDescription('');
    setFormTools('Figma, React, Tailwind CSS');
    setFormImage('');
    setFormGoals('Mobile responsiveness, Dark mode optimization');
    setFormDeliverables('Clean design files, Source code');
  };

  const handleStartEdit = (project: Project) => {
    setIsEditing(true);
    setEditingProjectId(project.id);
    setFormTitle(project.title);
    setFormCategory(project.category);
    setFormClassification(project.classification);
    setFormTagline(project.tagline);
    setFormDescription(project.description);
    setFormTools(project.tools.join(', '));
    setFormImage(project.image);
    setFormGoals(project.goals.join(', '));
    setFormDeliverables(project.deliverables.join(', '));
  };

  const handleSaveProjectForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) return;

    const toolsArr = formTools.split(',').map((t) => t.trim()).filter(Boolean);
    const goalsArr = formGoals.split(',').map((g) => g.trim()).filter(Boolean);
    const delivArr = formDeliverables.split(',').map((d) => d.trim()).filter(Boolean);

    if (editingProjectId) {
      // Update existing
      const updated = projects.map((p) => {
        if (p.id === editingProjectId) {
          return {
            ...p,
            title: formTitle.trim(),
            category: formCategory,
            classification: formClassification,
            tagline: formTagline.trim(),
            description: formDescription.trim(),
            longDescription: formDescription.trim(),
            tools: toolsArr.length ? toolsArr : ['Figma', 'React'],
            goals: goalsArr.length ? goalsArr : ['High quality delivery'],
            deliverables: delivArr.length ? delivArr : ['Design assets'],
            image: formImage.trim() || p.image,
          };
        }
        return p;
      });
      onSaveProjects(updated);
    } else {
      // Create new
      const newProject: Project = {
        id: `proj_${Date.now()}`,
        title: formTitle.trim(),
        category: formCategory,
        classification: formClassification,
        tagline: formTagline.trim() || 'New studio creative concept',
        description: formDescription.trim() || 'Creative exploration by Dilshad.',
        longDescription: formDescription.trim() || 'Creative exploration by Dilshad.',
        tools: toolsArr.length ? toolsArr : ['Figma', 'React'],
        goals: goalsArr.length ? goalsArr : ['Explore clean aesthetics and responsive UX'],
        deliverables: delivArr.length ? delivArr : ['Final asset set'],
        image: formImage.trim() || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&q=80',
        date: new Date().getFullYear().toString(),
        featured: false,
      };
      onSaveProjects([newProject, ...projects]);
    }

    setIsEditing(false);
  };

  const handleDeleteProject = (id: string) => {
    if (confirm('Are you sure you want to remove this project?')) {
      const remaining = projects.filter((p) => p.id !== id);
      onSaveProjects(remaining);
    }
  };

  const handleUpdateEnquiryStatus = (id: string, newStatus: 'New' | 'Replied' | 'Archived') => {
    const updated = enquiries.map((enq) => (enq.id === id ? { ...enq, status: newStatus } : enq));
    onUpdateEnquiries(updated);
  };

  const handleDeleteEnquiry = (id: string) => {
    const updated = enquiries.filter((enq) => enq.id !== id);
    onUpdateEnquiries(updated);
  };

  const handleExportData = () => {
    const dataToExport = {
      exportedAt: new Date().toISOString(),
      owner: 'Dilshad',
      studio: 'OVERALL Creative Studio',
      projects,
      enquiries,
    };
    const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `overall-studio-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="studio-manager-title"
      className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200"
    >
      <div className="fixed inset-0" onClick={onClose} aria-hidden="true" />

      {/* Surface */}
      <div className="relative z-10 w-full max-w-4xl bg-[#0B1017] border border-white/10 rounded-2xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden my-auto">
        {/* Top Header */}
        <div className="px-5 sm:px-8 py-4 sm:py-5 border-b border-white/10 flex items-center justify-between gap-4 bg-[#0F1622]/95 backdrop-blur-md sticky top-0 z-20">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-[#42E6A4] uppercase tracking-wider">
              <span>Studio Workspace</span>
              <span aria-hidden="true">·</span>
              <span>Owner Panel for Dilshad</span>
            </div>
            <h2 id="studio-manager-title" className="text-lg sm:text-xl font-bold text-white mt-0.5">
              Studio & Project Manager
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="min-w-[40px] min-h-[40px] rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
            aria-label="Close studio manager"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-5 sm:px-8 pt-3 bg-[#0D131C] border-b border-white/5 flex gap-2 overflow-x-auto scrollbar-none text-xs">
          <button
            type="button"
            onClick={() => {
              setActiveTab('projects');
              setIsEditing(false);
            }}
            className={`min-h-[40px] px-4 py-2 border-b-2 font-medium flex items-center gap-2 transition-colors whitespace-nowrap ${
              activeTab === 'projects'
                ? 'border-[#00D9FF] text-[#00D9FF]'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <FolderGit2 className="w-4 h-4" />
            Projects ({projects.length})
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('enquiries');
              setIsEditing(false);
            }}
            className={`min-h-[40px] px-4 py-2 border-b-2 font-medium flex items-center gap-2 transition-colors whitespace-nowrap ${
              activeTab === 'enquiries'
                ? 'border-[#42E6A4] text-[#42E6A4]'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Inbox className="w-4 h-4" />
            Client Inquiries ({enquiries.length})
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('backend-roadmap');
              setIsEditing(false);
            }}
            className={`min-h-[40px] px-4 py-2 border-b-2 font-medium flex items-center gap-2 transition-colors whitespace-nowrap ${
              activeTab === 'backend-roadmap'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            Backend Architecture Note
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-8 overflow-y-auto space-y-6 flex-1">
          {/* Honest Architecture Disclosure Banner */}
          <div className="p-3.5 sm:p-4 rounded-xl bg-cyan-950/30 border border-[#00D9FF]/20 text-xs text-slate-300 leading-relaxed flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-[#00D9FF] shrink-0 mt-0.5" />
            <div>
              <strong className="text-white">Local-First Storage on this Device:</strong> As requested, this studio is optimized for Dilshad's Android workflow. Project additions and client enquiries are kept directly in your browser's persistent storage. You can backup your work with the Export button anytime.
            </div>
          </div>

          {/* TAB 1: PROJECTS */}
          {activeTab === 'projects' && (
            <div className="space-y-6">
              {isEditing ? (
                /* Edit / Add Project Form */
                <form onSubmit={handleSaveProjectForm} className="space-y-4 bg-white/[0.02] border border-white/5 p-5 rounded-2xl">
                  <div className="flex items-center justify-between border-b border-white/5 pb-3">
                    <h4 className="text-sm font-bold text-white">
                      {editingProjectId ? 'Edit Project Concept' : 'Add New Portfolio Concept'}
                    </h4>
                    <button
                      type="button"
                      onClick={() => setIsEditing(false)}
                      className="text-xs text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block text-slate-300 mb-1 font-medium">Project Title</label>
                      <input
                        type="text"
                        value={formTitle}
                        onChange={(e) => setFormTitle(e.target.value)}
                        placeholder="e.g. Apex Visuals"
                        required
                        className="w-full bg-[#121A26] border border-white/10 rounded-lg px-3 py-2 text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-300 mb-1 font-medium">Category</label>
                      <select
                        value={formCategory}
                        onChange={(e) => setFormCategory(e.target.value as any)}
                        className="w-full bg-[#121A26] border border-white/10 rounded-lg px-3 py-2 text-white"
                      >
                        <option value="Websites">Websites</option>
                        <option value="Video Editing">Video Editing</option>
                        <option value="Posters">Posters</option>
                        <option value="Thumbnails">Thumbnails</option>
                        <option value="Banners">Banners</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-slate-300 mb-1 font-medium">Classification</label>
                      <select
                        value={formClassification}
                        onChange={(e) => setFormClassification(e.target.value as any)}
                        className="w-full bg-[#121A26] border border-white/10 rounded-lg px-3 py-2 text-white"
                      >
                        <option value="Practice Concept">Practice Concept (Honest Label)</option>
                        <option value="Commissioned Work">Commissioned Work (Real Client)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-slate-300 mb-1 font-medium">Tagline / Subhead</label>
                      <input
                        type="text"
                        value={formTagline}
                        onChange={(e) => setFormTagline(e.target.value)}
                        placeholder="e.g. Cinematic Motion Pacing"
                        className="w-full bg-[#121A26] border border-white/10 rounded-lg px-3 py-2 text-white"
                      />
                    </div>
                  </div>

                  <div className="text-xs">
                    <label className="block text-slate-300 mb-1 font-medium">Full Description</label>
                    <textarea
                      rows={3}
                      value={formDescription}
                      onChange={(e) => setFormDescription(e.target.value)}
                      placeholder="Explain the concept, art direction, and objectives..."
                      className="w-full bg-[#121A26] border border-white/10 rounded-lg px-3 py-2 text-white"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block text-slate-300 mb-1 font-medium">Tools Used (comma separated)</label>
                      <input
                        type="text"
                        value={formTools}
                        onChange={(e) => setFormTools(e.target.value)}
                        placeholder="DaVinci Resolve, Figma, React"
                        className="w-full bg-[#121A26] border border-white/10 rounded-lg px-3 py-2 text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-300 mb-1 font-medium">Image URL (Optional)</label>
                      <input
                        type="text"
                        value={formImage}
                        onChange={(e) => setFormImage(e.target.value)}
                        placeholder="Paste image link or leave blank"
                        className="w-full bg-[#121A26] border border-white/10 rounded-lg px-3 py-2 text-white"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsEditing(false)}
                      className="px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-medium"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-lg bg-gradient-to-r from-[#00D9FF] to-[#42E6A4] text-slate-950 text-xs font-bold"
                    >
                      {editingProjectId ? 'Save Changes' : 'Create Project'}
                    </button>
                  </div>
                </form>
              ) : (
                <div className="space-y-4">
                  {/* Actions Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={handleStartAdd}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#00D9FF] to-[#42E6A4] text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow"
                    >
                      <Plus className="w-4 h-4" /> Add New Concept
                    </button>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleExportData}
                        className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-medium flex items-center gap-1.5 border border-white/5"
                        title="Export projects & enquiries to JSON backup"
                      >
                        <Download className="w-3.5 h-3.5 text-[#00D9FF]" /> Export Backup
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          if (confirm('Reset to default studio sample projects?')) {
                            onResetProjects();
                          }
                        }}
                        className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white text-xs font-medium flex items-center gap-1.5"
                        title="Restore initial projects including Ember & Olive"
                      >
                        <RefreshCcw className="w-3.5 h-3.5" /> Reset Defaults
                      </button>
                    </div>
                  </div>

                  {/* Projects List */}
                  <div className="space-y-3">
                    {projects.map((p) => (
                      <div
                        key={p.id}
                        className="p-4 rounded-xl bg-white/[0.02] border border-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={p.image}
                            alt={p.title}
                            referrerPolicy="no-referrer"
                            className="w-14 h-14 rounded-lg object-cover bg-black shrink-0 border border-white/10"
                          />
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 text-[11px] text-slate-400">
                              <span className="text-[#00D9FF] font-medium">{p.category}</span>
                              <span aria-hidden="true">·</span>
                              <span className={p.classification === 'Practice Concept' ? 'text-amber-400' : 'text-emerald-400'}>
                                {p.classification}
                              </span>
                            </div>
                            <h5 className="font-bold text-white text-sm truncate">{p.title}</h5>
                            <p className="text-xs text-slate-400 truncate max-w-md">{p.tagline}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-center">
                          <button
                            type="button"
                            onClick={() => handleStartEdit(p)}
                            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
                            title="Edit project"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteProject(p.id)}
                            className="p-2 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors"
                            title="Delete project"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: CLIENT ENQUIRIES */}
          {activeTab === 'enquiries' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Inbound messages submitted through the contact form on this device.</span>
                <button
                  type="button"
                  onClick={handleExportData}
                  className="text-[#00D9FF] hover:underline flex items-center gap-1 font-medium"
                >
                  <Download className="w-3.5 h-3.5" /> Export All as JSON
                </button>
              </div>

              {enquiries.length === 0 ? (
                <div className="p-8 text-center rounded-xl bg-white/[0.02] border border-white/5 space-y-2">
                  <Inbox className="w-10 h-10 text-slate-600 mx-auto" />
                  <h4 className="text-sm font-semibold text-white">No Enquiries Yet</h4>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto">
                    When visitors submit the project enquiry form on the website, their message details will be logged here for Dilshad.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {enquiries.map((enq) => (
                    <div
                      key={enq.id}
                      className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-3 text-xs"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/5 pb-2">
                        <div className="flex items-center gap-2">
                          <strong className="text-white text-sm">{enq.name}</strong>
                          <span className="text-slate-400 font-mono">({enq.contactMethod}: {enq.contactValue})</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[11px] text-slate-500">{enq.createdAt}</span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                              enq.status === 'New'
                                ? 'bg-[#00D9FF]/20 text-[#00D9FF]'
                                : enq.status === 'Replied'
                                ? 'bg-[#42E6A4]/20 text-[#42E6A4]'
                                : 'bg-slate-700 text-slate-300'
                            }`}
                          >
                            {enq.status}
                          </span>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="text-slate-400">
                          <span className="text-white font-medium">Service:</span> {enq.serviceType} · <span className="text-white font-medium">Budget:</span> {enq.budgetRange}
                        </div>
                        <p className="text-slate-200 bg-black/30 p-2.5 rounded-lg border border-white/5 whitespace-pre-wrap leading-relaxed">
                          {enq.description}
                        </p>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center justify-between pt-1">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleUpdateEnquiryStatus(enq.id, 'Replied')}
                            className="px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-slate-300 text-[11px]"
                          >
                            Mark Replied
                          </button>
                          <button
                            type="button"
                            onClick={() => handleUpdateEnquiryStatus(enq.id, 'Archived')}
                            className="px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-slate-400 text-[11px]"
                          >
                            Archive
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDeleteEnquiry(enq.id)}
                          className="text-rose-400 hover:text-rose-300 p-1"
                          title="Delete enquiry"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: BACKEND ARCHITECTURE ROADMAP */}
          {activeTab === 'backend-roadmap' && (
            <div className="space-y-5 text-xs text-slate-300 leading-relaxed">
              <div className="p-4 rounded-xl bg-amber-500/[0.08] border border-amber-500/20 text-amber-200 space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-sm text-amber-400">
                  <AlertTriangle className="w-4 h-4" />
                  Honest Production Architecture Disclosure
                </div>
                <p>
                  As required by the studio design specification, we never implement fake authentication or pretend that browser local storage is a multi-user secure server database.
                </p>
              </div>

              <div className="space-y-3 bg-white/[0.02] border border-white/5 p-5 rounded-2xl">
                <h4 className="text-sm font-bold text-white">What is Working Right Now:</h4>
                <ul className="space-y-1.5 list-disc list-inside text-slate-300">
                  <li>Complete high-end dark portfolio responsive UI with mobile-first Android layout.</li>
                  <li>Portfolio category filtering across Websites, Video Editing, Posters, Thumbnails, Banners.</li>
                  <li>Ember & Olive interactive restaurant concept with live menu and table booking simulator.</li>
                  <li>Validated enquiry submission with one-click direct WhatsApp routing and direct Email opening.</li>
                  <li>Local project creation, editing, and backup export via JSON on Dilshad's phone.</li>
                </ul>
              </div>

              <div className="space-y-3 bg-white/[0.02] border border-white/5 p-5 rounded-2xl">
                <h4 className="text-sm font-bold text-white">Recommended Next Phase (Cloud Backend):</h4>
                <p>
                  When Dilshad wants to enable multi-device synchronization and public logins from anywhere without relying on device browser storage:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div className="p-3 rounded-lg bg-black/40 border border-white/5 space-y-1">
                    <span className="font-semibold text-[#00D9FF] block">1. Firebase / Supabase Integration</span>
                    <p className="text-slate-400 text-[11px]">
                      Persistent Cloud Firestore database for storing projects and inquiries accessible from any phone or PC.
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-black/40 border border-white/5 space-y-1">
                    <span className="font-semibold text-[#42E6A4] block">2. Real Server Auth</span>
                    <p className="text-slate-400 text-[11px]">
                      Firebase Authentication or Google Sign-In with server-enforced security rules preventing unauthorized modifications.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 sm:px-8 py-3.5 border-t border-white/10 bg-[#0F1622] flex items-center justify-between text-xs text-slate-400">
          <span>Dilshad · OVERALL Creative Studio</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium"
          >
            Close Panel
          </button>
        </div>
      </div>
    </div>
  );
};
