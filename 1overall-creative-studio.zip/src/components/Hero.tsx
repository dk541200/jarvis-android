import React from 'react';
import { ArrowDown, ArrowUpRight, Compass, Layers, Film, Palette } from 'lucide-react';
import { heroImg } from '../data/portfolioData';

interface HeroProps {
  onExploreWork: () => void;
  onStartProject: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreWork, onStartProject }) => {
  return (
    <section id="home" className="relative pt-8 pb-16 lg:pt-16 lg:pb-24 overflow-hidden">
      {/* Subtle Background Lighting & Mesh (Lightweight CSS, no heavy shaders) */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 overflow-hidden"
      >
        <div className="absolute -top-32 -left-32 w-96 h-96 bg-[#00D9FF]/10 rounded-full blur-3xl" />
        <div className="absolute top-1/4 -right-32 w-96 h-96 bg-[#42E6A4]/8 rounded-full blur-3xl" />
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)`,
            backgroundSize: '40px 40px',
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Split Grid: Left Typography + Right Media Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Typographic Anchor */}
          <div className="lg:col-span-7 space-y-6">
            {/* Honest Editorial Lead (Zero Pills, Clean Text with typographic separator) */}
            <div className="flex items-center gap-2 text-xs font-medium text-slate-400 tracking-wide uppercase">
              <span className="text-[#00D9FF]">OVERALL Creative Studio</span>
              <span aria-hidden="true">·</span>
              <span>Created by Dilshad</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.08] [text-wrap:balance]">
              Ideas Into <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00D9FF] via-[#42E6A4] to-white">
                Digital Experiences.
              </span>
            </h1>

            {/* Supporting Prose */}
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl font-light">
              Crafting responsive website designs, high-retention video edits, and bold visual
              graphics. An independent portfolio platform built with clean dark aesthetics, fluid
              micro-interactions, and mobile-first care.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                type="button"
                onClick={onExploreWork}
                className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-[#00D9FF] to-[#42E6A4] text-slate-950 font-bold text-sm flex items-center gap-2 hover:shadow-lg hover:shadow-[#00D9FF]/25 hover:brightness-105 active:scale-95 transition-all whitespace-nowrap"
              >
                <span>Explore My Work</span>
                <ArrowDown className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onStartProject}
                className="px-6 py-3.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.09] text-white border border-white/10 hover:border-[#00D9FF]/40 font-medium text-sm flex items-center gap-2 transition-all whitespace-nowrap active:scale-95"
              >
                <span>Start a Project</span>
                <ArrowUpRight className="w-4 h-4 text-[#00D9FF]" />
              </button>
            </div>

            {/* Discipline Bar (Unboxed text with separators, no pills) */}
            <div className="pt-4 flex flex-wrap items-center gap-3 text-xs text-slate-400">
              <span className="flex items-center gap-1.5 text-slate-300">
                <Layers className="w-3.5 h-3.5 text-[#00D9FF]" /> Website Design
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1.5 text-slate-300">
                <Film className="w-3.5 h-3.5 text-[#42E6A4]" /> Short-Form Video
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1.5 text-slate-300">
                <Palette className="w-3.5 h-3.5 text-[#00D9FF]" /> Visual Posters & Thumbnails
              </span>
            </div>
          </div>

          {/* Right Column: Visual Frame */}
          <div className="lg:col-span-5">
            <div className="relative group">
              {/* Subtle Ambient Back-Glow */}
              <div className="absolute -inset-1 bg-gradient-to-r from-[#00D9FF]/20 to-[#42E6A4]/20 rounded-2xl blur-xl opacity-60 group-hover:opacity-80 transition-opacity" />

              {/* Obsidian Glass Card Container */}
              <div className="relative rounded-2xl overflow-hidden bg-[#0E1520] border border-white/10 shadow-2xl">
                {/* Media Header Bar */}
                <div className="bg-[#121A26] px-4 py-3 border-b border-white/5 flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-700" />
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-700" />
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-700" />
                  </div>
                  <span className="font-mono text-[11px] text-[#00D9FF]">overall-studio.workspace</span>
                </div>

                {/* Main Visual Image */}
                <div className="relative aspect-video sm:aspect-[4/3] overflow-hidden bg-[#0A0E14]">
                  <img
                    src={heroImg}
                    alt="OVERALL Creative Studio Workstation"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#090D12] via-transparent to-transparent opacity-80" />
                </div>

                {/* Bottom Frame Caption */}
                <div className="p-4 sm:p-5 bg-[#0C121A] border-t border-white/5 flex items-center justify-between gap-4">
                  <div>
                    <h3 className="text-white text-sm font-semibold">Digital Production Suite</h3>
                    <p className="text-xs text-slate-400">Designed & engineered by Dilshad</p>
                  </div>
                  <button
                    type="button"
                    onClick={onExploreWork}
                    className="text-xs text-[#00D9FF] hover:text-[#42E6A4] font-medium flex items-center gap-1 transition-colors"
                  >
                    View Concepts <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Full-width editorial strip below the split */}
        <div className="mt-14 pt-8 border-t border-white/5 grid grid-cols-2 md:grid-cols-4 gap-6 text-left">
          <div className="space-y-1">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Aesthetic Focus</span>
            <p className="text-sm font-semibold text-white">Futuristic Dark & Obsidian</p>
          </div>
          <div className="space-y-1">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Ergonomics</span>
            <p className="text-sm font-semibold text-white">Mobile-First Touch Architecture</p>
          </div>
          <div className="space-y-1">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Motion Quality</span>
            <p className="text-sm font-semibold text-white">60fps Timeline Pacing & Color</p>
          </div>
          <div className="space-y-1">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Transparency</span>
            <p className="text-sm font-semibold text-[#42E6A4]">100% Honest Concept Labeling</p>
          </div>
        </div>
      </div>
    </section>
  );
};
