import React, { useState } from 'react';
import { Flame, Utensils, Calendar, Clock, Users, CheckCircle2, ChevronRight, Smartphone, Monitor } from 'lucide-react';
import emberHeroImg from '../assets/images/ember_olive_concept_1791610240150.jpg';

interface MenuItem {
  name: string;
  category: 'Small Plates' | 'Wood-Fired Mains' | 'Hearth Breads' | 'Desserts';
  price: string;
  description: string;
  woodType: string;
}

const MENU_ITEMS: MenuItem[] = [
  {
    name: 'Charred Spanish Octopus',
    category: 'Small Plates',
    price: '$28',
    description: 'Olive tapenade, charred fingerling potatoes, salsa verde, ember-smoked olive oil',
    woodType: 'White Oak'
  },
  {
    name: 'Reverse-Seared 45-Day Wagyu Ribeye',
    category: 'Wood-Fired Mains',
    price: '$72',
    description: 'Smoked bone marrow ash butter, charred heirloom carrots, pickled ramp reduction',
    woodType: 'Hickory & Applewood'
  },
  {
    name: 'Wood-Fired Sourdough & Hearth Butter',
    category: 'Hearth Breads',
    price: '$14',
    description: '36-hour slow fermented flour, house-churned cultured butter smoked over peat embers',
    woodType: 'Cherry Wood'
  },
  {
    name: 'Charred Heritage Pork Belly',
    category: 'Wood-Fired Mains',
    price: '$38',
    description: 'Burnt honey glaze, pickled mustard seeds, roasted fennel puree, crisp crackling',
    woodType: 'Applewood'
  },
  {
    name: 'Smoked Dark Chocolate Tart',
    category: 'Desserts',
    price: '$18',
    description: 'Charred orange zest, sea salt caramel, smoked hazelnut gelato',
    woodType: 'Almond Wood'
  }
];

export const EmberOliveInteractivePreview: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [viewMode, setViewMode] = useState<'desktop' | 'mobile'>('desktop');
  
  // Reservation form state
  const [guests, setGuests] = useState('2 Guests');
  const [date, setDate] = useState('Today, 7:30 PM');
  const [tableType, setTableType] = useState("Chef's Hearth Counter");
  const [reservationBooked, setReservationBooked] = useState(false);

  const categories = ['All', 'Small Plates', 'Wood-Fired Mains', 'Hearth Breads', 'Desserts'];

  const filteredMenu = selectedCategory === 'All' 
    ? MENU_ITEMS 
    : MENU_ITEMS.filter(item => item.category === selectedCategory);

  const handleBookTable = (e: React.FormEvent) => {
    e.preventDefault();
    setReservationBooked(true);
  };

  return (
    <div className="bg-[#0B0F14] text-slate-200 rounded-xl border border-white/10 overflow-hidden">
      {/* Prototype Control Bar */}
      <div className="bg-[#121820] px-4 py-3 border-b border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
          <span className="font-semibold text-amber-400 uppercase tracking-wider">Concept Prototype Live Demo</span>
          <span className="text-slate-400 hidden sm:inline">· Fictional Restaurant Project</span>
        </div>
        
        <div className="flex items-center gap-1 bg-[#090D12] p-1 rounded-lg border border-white/5">
          <button
            type="button"
            onClick={() => setViewMode('desktop')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-colors ${
              viewMode === 'desktop' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            Desktop
          </button>
          <button
            type="button"
            onClick={() => setViewMode('mobile')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-colors ${
              viewMode === 'mobile' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            Mobile View
          </button>
        </div>
      </div>

      {/* Main Container Wrapper depending on viewMode */}
      <div className={`transition-all duration-300 mx-auto ${viewMode === 'mobile' ? 'max-w-sm my-6 border-4 border-slate-700 rounded-3xl overflow-hidden shadow-2xl shadow-amber-500/10' : 'w-full'}`}>
        {/* Restaurant Header */}
        <div className="bg-[#0E131A] px-6 py-4 border-b border-white/5 flex items-center justify-between">
          <div>
            <span className="text-xs uppercase tracking-widest text-amber-500/90 font-medium">Concept Portfolio Design</span>
            <h3 className="text-xl font-bold tracking-tight text-white font-serif">EMBER & OLIVE</h3>
          </div>
          <div className="text-right text-xs text-slate-400">
            <span className="hidden sm:inline">Wood-Fired Hearth · </span>
            <span className="text-amber-400">Evening Service 5PM–11PM</span>
          </div>
        </div>

        {/* Hero Visual Card */}
        <div className="relative aspect-video max-h-80 w-full overflow-hidden bg-black">
          <img
            src={emberHeroImg}
            alt="Ember & Olive Gastronomy"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-85"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F14] via-[#0B0F14]/40 to-transparent flex flex-col justify-end p-6">
            <span className="text-amber-400 text-xs uppercase tracking-widest font-semibold flex items-center gap-1.5 mb-1">
              <Flame className="w-3.5 h-3.5" /> Handcrafted Hearth Cooking
            </span>
            <h4 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-tight">
              The Art of Smoke & Cinder
            </h4>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1">
              Prime wood-fired cuts, cold-pressed olive oils, and seasonal coastal gastronomy prepared over live embers.
            </p>
          </div>
        </div>

        {/* Menu & Reservation Split */}
        <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Menu Column */}
          <div className="lg:col-span-7 space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Utensils className="w-4 h-4 text-amber-400" />
                <h4 className="font-serif text-lg font-bold text-white">Seasonal Hearth Menu</h4>
              </div>
              <span className="text-xs text-slate-400">Autumn Tasting</span>
            </div>

            {/* Menu Category Filter */}
            <div className="flex flex-wrap gap-1.5 pb-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`text-xs px-3 py-1 rounded-md transition-all ${
                    selectedCategory === cat
                      ? 'bg-amber-500 text-slate-950 font-semibold'
                      : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Items List */}
            <div className="space-y-3">
              {filteredMenu.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-lg bg-white/[0.03] border border-white/5 hover:border-amber-500/30 transition-colors"
                >
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="font-medium text-white text-sm">{item.name}</span>
                    <span className="font-mono text-amber-400 font-semibold text-sm">{item.price}</span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">{item.description}</p>
                  <div className="mt-2 flex items-center gap-2 text-[11px] text-slate-400">
                    <span className="text-amber-500/80 font-medium">Wood smoke profile:</span>
                    <span>{item.woodType}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Interactive Reservation Simulator */}
          <div className="lg:col-span-5 bg-white/[0.02] border border-white/10 rounded-xl p-5 space-y-4 h-fit">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div>
                <h4 className="font-serif text-base font-bold text-white">Table Reservation</h4>
                <p className="text-xs text-slate-400">Experience our open wood hearth</p>
              </div>
              <Flame className="w-5 h-5 text-amber-500" />
            </div>

            {reservationBooked ? (
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                <h5 className="font-semibold text-emerald-300 text-sm">Demo Booking Confirmed!</h5>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Table for <span className="text-white font-medium">{guests}</span> on{' '}
                  <span className="text-white font-medium">{date}</span> at the{' '}
                  <span className="text-white font-medium">{tableType}</span>.
                </p>
                <button
                  type="button"
                  onClick={() => setReservationBooked(false)}
                  className="mt-3 text-xs px-3 py-1.5 rounded bg-white/10 hover:bg-white/20 text-white font-medium"
                >
                  Reset Demo Booking
                </button>
              </div>
            ) : (
              <form onSubmit={handleBookTable} className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1 font-medium flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-amber-400" /> Party Size
                  </label>
                  <select
                    value={guests}
                    onChange={(e) => setGuests(e.target.value)}
                    className="w-full bg-[#121820] border border-white/10 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-amber-400"
                  >
                    <option>2 Guests</option>
                    <option>4 Guests</option>
                    <option>6 Guests</option>
                    <option>8 Guests (Private Hearth Table)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-medium flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-amber-400" /> Date & Time
                  </label>
                  <select
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-[#121820] border border-white/10 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-amber-400"
                  >
                    <option>Today, 7:30 PM</option>
                    <option>Today, 9:00 PM</option>
                    <option>Tomorrow, 6:30 PM</option>
                    <option>Tomorrow, 8:15 PM</option>
                    <option>Friday, 7:00 PM</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-medium flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-amber-400" /> Seating Preference
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setTableType("Chef's Hearth Counter")}
                      className={`p-2 rounded-lg text-left transition-colors border ${
                        tableType === "Chef's Hearth Counter"
                          ? 'bg-amber-500/20 border-amber-500 text-amber-200 font-medium'
                          : 'bg-[#121820] border-white/5 text-slate-400 hover:text-white'
                      }`}
                    >
                      Hearth Counter
                    </button>
                    <button
                      type="button"
                      onClick={() => setTableType('Dining Room')}
                      className={`p-2 rounded-lg text-left transition-colors border ${
                        tableType === 'Dining Room'
                          ? 'bg-amber-500/20 border-amber-500 text-amber-200 font-medium'
                          : 'bg-[#121820] border-white/5 text-slate-400 hover:text-white'
                      }`}
                    >
                      Dining Room
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full mt-2 py-2.5 px-4 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold flex items-center justify-center gap-1.5 transition-colors shadow-lg shadow-amber-500/20"
                >
                  Simulate Booking Flow
                  <ChevronRight className="w-4 h-4" />
                </button>

                <p className="text-[11px] text-slate-400 text-center leading-normal">
                  Interactive simulation designed by Dilshad to showcase hospitality UX and booking flows.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
