package com.jarvis.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

public class JarvisService extends Service {
    public static final String ACTION_ON = "com.jarvis.android.action.ON";
    public static final String ACTION_SLEEP = "com.jarvis.android.action.SLEEP";
    public static final String ACTION_OFF = "com.jarvis.android.action.OFF";

    private static final int NOTIFICATION_ID = 1;
    private static final String CHANNEL_ID = "jarvis_core";

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();

        // Must be called quickly after startForegroundService().
        startForeground(NOTIFICATION_ID, buildNotification("JARVIS ACTIVE"));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_ON : intent.getAction();

        if (ACTION_SLEEP.equals(action)) {
            updateNotification("JARVIS SLEEPING");
        } else if (ACTION_OFF.equals(action)) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        } else {
            updateNotification("JARVIS ACTIVE");
        }

        return START_STICKY;
    }

    private void updateNotification(String status) {
        NotificationManager manager =
            (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, buildNotification(status));
    }

    private Notification buildNotification(String status) {
        PendingIntent on = actionPendingIntent(ACTION_ON, 10);
        PendingIntent sleep = actionPendingIntent(ACTION_SLEEP, 11);
        PendingIntent off = actionPendingIntent(ACTION_OFF, 12);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis")
            .setContentText(status)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(new NotificationCompat.Action(0, "ON", on))
            .addAction(new NotificationCompat.Action(0, "SLEEP", sleep))
            .addAction(new NotificationCompat.Action(0, "OFF", off))
            .build();
    }

    private PendingIntent actionPendingIntent(String action, int requestCode) {
        Intent intent = new Intent(this, JarvisService.class).setAction(action);
        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Jarvis Core",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Jarvis background service status");
            NotificationManager manager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
