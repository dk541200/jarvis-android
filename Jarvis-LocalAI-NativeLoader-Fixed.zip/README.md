# Jarvis Local AI Android

This source is designed to be injected into the official `ggml-org/llama.cpp` Android project.

Important:
- Jarvis application package: `com.jarvis.android`
- `com.arm.aichat.*` imports are intentionally preserved because they belong to the llama.cpp Android AI library.
- The workflow builds the official llama.cpp native library and then builds the Jarvis Android app.
- The workflow publishes a direct APK GitHub Release; it does not rely on an Actions ZIP artifact.
- Android SDK setup is done directly with `sdkmanager` to avoid the `sdkmanager tools` failure.
