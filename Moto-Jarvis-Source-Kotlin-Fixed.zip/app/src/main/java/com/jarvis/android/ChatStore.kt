package com.jarvis.android

import android.content.Context

/** Conversation persistence facade; messages remain in app-private local storage. */
class ChatStore(context: Context) {
    private val memory = MemoryStore(context)
    fun saveUser(text: String) = memory.saveTurn("user", text)
    fun saveAssistant(text: String) = memory.saveTurn("assistant", text)
    fun recent(limit: Int = 12) = memory.recentTurns(limit)
    fun clear() = memory.clearChat()
}
