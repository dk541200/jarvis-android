package com.jarvis.android

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Small, device-local memory. Nothing is uploaded unless a prompt is sent to a configured LLM. */
class MemoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("moto_private", Context.MODE_PRIVATE)

    @Synchronized fun remember(text: String): String {
        val clean = text.trim().take(500)
        if (clean.isBlank()) return "Bhai, kya yaad rakhna hai woh bata."
        val list = JSONArray(prefs.getString("memory", "[]"))
        // Avoid exact duplicates.
        for (i in 0 until list.length()) if (list.optString(i).equals(clean, true)) {
            return "Ye baat pehle se yaad hai: $clean"
        }
        list.put(clean)
        while (list.length() > 80) list.remove(0)
        prefs.edit().putString("memory", list.toString()).apply()
        return "Theek hai bhai, apne phone par save kar liya: $clean"
    }

    @Synchronized fun setName(name: String) {
        val clean = name.trim().take(80)
        if (clean.isNotBlank()) prefs.edit().putString("user_name", clean).apply()
    }

    fun name(): String = prefs.getString("user_name", "") ?: ""

    fun all(): List<String> {
        val json = JSONArray(prefs.getString("memory", "[]"))
        return (0 until json.length()).map { json.optString(it) }.filter { it.isNotBlank() }
    }

    fun summary(): String = buildString {
        val n = name()
        if (n.isNotBlank()) append("User name: ").append(n).append(". ")
        val facts = all()
        if (facts.isNotEmpty()) append("Remembered facts: ").append(facts.takeLast(30).joinToString("; "))
    }.take(6000)

    @Synchronized fun clear() { prefs.edit().remove("memory").remove("user_name").apply() }

    @Synchronized fun saveTurn(role: String, content: String) {
        val turns = JSONArray(prefs.getString("history", "[]"))
        turns.put(JSONObject().put("role", role).put("content", content.take(6000)))
        while (turns.length() > 80) turns.remove(0)
        prefs.edit().putString("history", turns.toString()).apply()
    }

    fun recentTurns(limit: Int = 12): JSONArray {
        val all = JSONArray(prefs.getString("history", "[]"))
        val out = JSONArray()
        val start = (all.length() - limit).coerceAtLeast(0)
        for (i in start until all.length()) out.put(all.getJSONObject(i))
        return out
    }

    @Synchronized fun clearChat() { prefs.edit().remove("history").apply() }
}
