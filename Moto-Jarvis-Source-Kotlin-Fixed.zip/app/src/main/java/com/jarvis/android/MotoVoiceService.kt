package com.jarvis.android

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** User-started foreground speech loop. It is not a privileged DSP hotword service. */
open class MotoVoiceService : Service(), TextToSpeech.OnInitListener {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var active = false
    private var speaking = false
    private lateinit var brain: MotoBrain

    override fun onCreate() {
        super.onCreate()
        brain = MotoBrain(this)
        tts = TextToSpeech(this, this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopListening()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return START_NOT_STICKY
        }
        active = true
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(NOTIFICATION_ID, notification)
        broadcastStatus(true)
        main.post { beginListening() }
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Moto voice standby", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Persistent notification while Moto listens for its wake phrase"
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 2, Intent(this, JarvisService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Moto voice standby")
            .setContentText("Say ‘Hey Moto’. Tap Stop to turn off microphone listening.")
            .setContentIntent(open).setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop listening", stop).build())
            .build()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val engine = tts ?: return
            val result = engine.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) engine.language = Locale("en", "IN")
            engine.setSpeechRate(1.0f)
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { speaking = true }
                override fun onDone(utteranceId: String?) {
                    speaking = false
                    if (active) main.postDelayed({ beginListening() }, 350)
                }
                @Deprecated("Deprecated in Java") override fun onError(utteranceId: String?) {
                    speaking = false
                    if (active) main.postDelayed({ beginListening() }, 700)
                }
                override fun onError(utteranceId: String?, errorCode: Int) {
                    speaking = false
                    if (active) main.postDelayed({ beginListening() }, 700)
                }
            })
        }
    }

    private fun beginListening() {
        if (!active || speaking) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { stopSelf(); return }
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                recognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: android.os.Bundle?) { }
                    override fun onBeginningOfSpeech() { }
                    override fun onRmsChanged(rmsdB: Float) { }
                    override fun onBufferReceived(buffer: ByteArray?) { }
                    override fun onEndOfSpeech() { }
                    override fun onError(error: Int) {
                        if (!active) return
                        // Permission / unsupported errors should not spin aggressively.
                        val delay = if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1800L else 900L
                        main.postDelayed({ beginListening() }, delay)
                    }
                    override fun onResults(results: android.os.Bundle?) {
                        if (!active) return
                        val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        processRecognized(phrase)
                    }
                    override fun onPartialResults(partialResults: android.os.Bundle?) { }
                    override fun onEvent(eventType: Int, params: android.os.Bundle?) { }
                })
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            main.postDelayed({ beginListening() }, 1500)
        }
    }

    private fun processRecognized(original: String) {
        val phrase = original.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()
        val wakePrefixes = listOf("hey moto", "moto wake up", "moto kaha ho", "moto kahan ho", "moto where are you", "moto suno", "moto sun")
        val matched = wakePrefixes.firstOrNull { phrase == it || phrase.startsWith("$it ") }
        val hasMotoPrefix = matched != null || phrase == "moto" || phrase.startsWith("moto ")
        if (!hasMotoPrefix) {
            main.postDelayed({ beginListening() }, 150)
            return
        }
        var command = phrase
        if (matched != null) command = phrase.removePrefix(matched).trim()
        else if (phrase.startsWith("hey moto ")) command = phrase.removePrefix("hey moto ").trim()
        else if (phrase.startsWith("moto ")) command = phrase.removePrefix("moto ").trim()
        if (command.isBlank() || command in listOf("wake up", "kaha ho", "kahan ho", "where are you", "sun", "suno")) {
            speak("Haan bhai, Moto yahin hai. Bol, kya karna hai?")
            return
        }
        // A single recognised command is routed to deterministic phone actions first, then the configured LLM.
        brain.handle(command) { answer -> if (active) speak(answer) }
    }

    private fun speak(text: String) {
        val engine = tts
        if (engine == null) { main.postDelayed({ beginListening() }, 400); return }
        speaking = true
        engine.speak(text.take(3000), TextToSpeech.QUEUE_FLUSH, null, "moto-voice-${System.currentTimeMillis()}")
    }

    private fun stopListening() {
        active = false
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        try { tts?.stop() } catch (_: Exception) {}
        broadcastStatus(false)
    }

    private fun broadcastStatus(isActive: Boolean) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra("active", isActive))
    }

    override fun onDestroy() {
        stopListening()
        try { tts?.shutdown() } catch (_: Exception) {}
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.jarvis.android.voice.START"
        const val ACTION_STOP = "com.jarvis.android.voice.STOP"
        const val ACTION_STATUS = "com.jarvis.android.voice.STATUS"
        private const val CHANNEL_ID = "moto_voice_channel"
        private const val NOTIFICATION_ID = 7411
    }
}
