package com.jarvis.android

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var brain: MotoBrain
    private lateinit var memory: MemoryStore
    private lateinit var tts: TextToSpeech
    private lateinit var endpointField: EditText
    private lateinit var modelField: EditText
    private lateinit var keyField: EditText
    private lateinit var promptField: EditText
    private lateinit var answerView: TextView
    private lateinit var statusView: TextView
    private lateinit var screenImage: ImageView
    private var lastScreenPath: String? = null
    private var receiverRegistered = false
    private var voiceActive = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                MotoVoiceService.ACTION_STATUS -> {
                    voiceActive = intent.getBooleanExtra("active", false)
                    updateStatus(if (voiceActive) "VOICE STANDBY ACTIVE · Say ‘Hey Moto’" else "Voice standby stopped")
                }
                ScreenCaptureService.ACTION_CAPTURED -> {
                    lastScreenPath = intent.getStringExtra(ScreenCaptureService.EXTRA_PATH)
                    val path = lastScreenPath
                    if (!path.isNullOrBlank() && File(path).exists()) {
                        screenImage.setImageBitmap(BitmapFactory.decodeFile(path))
                        screenImage.visibility = View.VISIBLE
                        speak("Screen capture ready hai, bhai. Ab 'Ask Moto about screen' dabakar isse samjha sakte hain.")
                        updateStatus("SCREEN CAPTURE READY · Image device cache mein hai")
                    }
                }
                ScreenCaptureService.ACTION_FAILED -> {
                    updateStatus(intent.getStringExtra("error") ?: "Screen capture failed")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 11, 19)
        window.navigationBarColor = Color.rgb(7, 11, 19)
        brain = MotoBrain(this)
        memory = MemoryStore(this)
        tts = TextToSpeech(this, this)
        buildUi()
        val filter = IntentFilter().apply {
            addAction(MotoVoiceService.ACTION_STATUS)
            addAction(ScreenCaptureService.ACTION_CAPTURED)
            addAction(ScreenCaptureService.ACTION_FAILED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
        receiverRegistered = true
        updateStatus("READY · Configure AI endpoint or use phone commands")
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(7, 11, 19), Color.rgb(10, 25, 37), Color.rgb(7, 11, 19)))
        }
        val scroll = ScrollView(this).apply { setFillViewport(true); addView(page) }
        val title = TextView(this).apply {
            text = "M O T O"
            textSize = 29f; setTextColor(Color.rgb(89, 239, 220)); typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
        }
        page.addView(title)
        page.addView(TextView(this).apply {
            text = "PERSONAL VOICE ASSISTANT"
            textSize = 11f; letterSpacing = 0.16f; setTextColor(Color.rgb(160, 180, 197))
            setPadding(0, dp(2), 0, dp(14))
        })
        statusView = TextView(this).apply {
            textSize = 12f; setTextColor(Color.rgb(80, 224, 194)); setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(Color.rgb(13, 35, 43), Color.rgb(36, 105, 105), 14)
        }
        page.addView(statusView, matchWrap())
        page.addView(section("Voice control"))
        val voiceRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        voiceRow.addView(button("Start listening") { startVoice() }, weighted())
        voiceRow.addView(space(dp(8)))
        voiceRow.addView(button("Stop") { stopVoice() }, weighted())
        page.addView(voiceRow)
        page.addView(button("Allow contact lookup (optional)") { requestContacts() }, matchWrap())
        page.addView(TextView(this).apply {
            text = "Wake words: Hey Moto · Moto wake up · Moto kaha ho. Keep the ongoing notification visible. Continuous recognition can use battery and may rely on the phone's speech service."
            textSize = 12f; setTextColor(Color.rgb(161, 178, 194)); setPadding(0, dp(8), 0, dp(4))
        })

        page.addView(section("Talk to Moto"))
        promptField = EditText(this).apply {
            hint = "Bol bhai… e.g. India ki latest news bata"
            setTextColor(Color.WHITE); setHintTextColor(Color.rgb(128, 146, 163)); textSize = 16f
            setPadding(dp(14), dp(12), dp(14), dp(12)); minLines = 2; maxLines = 5
            background = rounded(Color.rgb(16, 26, 40), Color.rgb(38, 67, 84), 16)
        }
        page.addView(promptField, matchWrap())
        page.addView(button("Ask Moto") {
            val q = promptField.text?.toString()?.trim().orEmpty()
            if (q.isNotBlank()) { hideKeyboard(); ask(q) }
        }, matchWrap())
        page.addView(button("Search Internet") {
            val q = promptField.text?.toString()?.trim().orEmpty()
            if (q.isNotBlank()) { hideKeyboard(); ask("search $q") }
            else toast("Pehle search topic likh ya bol, bhai.")
        }, matchWrap())

        answerView = TextView(this).apply {
            text = "Moto ready hai. Factual/latest questions par internet search ki koshish karega. Answer summarize karne ke liye AI endpoint/server bhi configured aur online hona chahiye."
            textSize = 15f; setTextColor(Color.rgb(234, 242, 250)); setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(12, 22, 34), Color.rgb(30, 56, 74), 16)
        }
        val answerParams = matchWrap().apply { topMargin = dp(10) }
        page.addView(answerView, answerParams)

        page.addView(section("Screen guidance"))
        page.addView(button("Share screen (one capture)") { requestScreenCapture() }, matchWrap())
        page.addView(TextView(this).apply {
            text = "Android permission dialog har share session par aayega. Screenshot pehle phone par save hota hai; Ask Moto dabane par hi configured endpoint ko bheja ja sakta hai. Hidden/continuous screen monitoring nahi hai."
            textSize = 12f; setTextColor(Color.rgb(161, 178, 194)); setPadding(0, dp(6), 0, dp(8))
        })
        screenImage = ImageView(this).apply {
            visibility = View.GONE; adjustViewBounds = true; maxHeight = dp(300)
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = rounded(Color.rgb(12, 22, 34), Color.rgb(30, 56, 74), 12)
        }
        page.addView(screenImage, matchWrap())
        page.addView(button("Ask Moto about captured screen") {
            val path = lastScreenPath
            if (path.isNullOrBlank() || !File(path).exists()) {
                toast("Pehle Share screen capture karo.")
            } else {
                val q = promptField.text?.toString()?.trim().orEmpty().ifBlank { "Meri screen par kya dikh raha hai? Hinglish mein step-by-step guide karo." }
                updateStatus("SENDING SCREEN TO CONFIGURED AI ENDPOINT…")
                brain.askAboutImage(q, path) { displayAnswer(it) }
            }
        }, matchWrap())

        page.addView(section("AI connection"))
        page.addView(fieldLabel("OpenAI-compatible chat completions URL"))
        endpointField = EditText(this).apply {
            setSingleLine(true); textSize = 13f; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            hint = "http://127.0.0.1:8080/v1/chat/completions"
            setText(getSharedPreferences("moto_private", MODE_PRIVATE).getString("endpoint", "http://127.0.0.1:8080/v1/chat/completions"))
            background = rounded(Color.rgb(16, 26, 40), Color.rgb(38, 67, 84), 12); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        page.addView(endpointField, matchWrap())
        page.addView(fieldLabel("Model ID (server ke /v1/models se exact ID daalo)"))
        modelField = EditText(this).apply {
            setSingleLine(true); textSize = 14f; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            hint = "Qwen3-1.7B"; setText(getSharedPreferences("moto_private", MODE_PRIVATE).getString("model", "Qwen3-1.7B"))
            background = rounded(Color.rgb(16, 26, 40), Color.rgb(38, 67, 84), 12); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        page.addView(modelField, matchWrap())
        page.addView(fieldLabel("API key (optional; saved on this device)"))
        keyField = EditText(this).apply {
            setSingleLine(true); textSize = 14f; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            hint = "Paste your own API key if required"; inputType = 129
            setText(SecretStore(this@MainActivity).getApiKey())
            background = rounded(Color.rgb(16, 26, 40), Color.rgb(38, 67, 84), 12); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        page.addView(keyField, matchWrap())
        page.addView(button("Save AI settings") {
            val ep = endpointField.text.toString().trim()
            if (!ep.startsWith("http://") && !ep.startsWith("https://")) toast("Valid http(s) endpoint daalo.")
            else {
                getSharedPreferences("moto_private", MODE_PRIVATE).edit()
                    .putString("endpoint", ep).putString("model", modelField.text.toString().trim().ifBlank { "local-model" })
                    .apply()
                SecretStore(this).putApiKey(keyField.text.toString().trim())
                updateStatus("AI SETTINGS SAVED ON THIS DEVICE")
                toast("Settings save ho gayi.")
            }
        }, matchWrap())
        page.addView(button("Test AI connection") { ask("Reply only: Moto connection test successful. Short Hinglish.") }, matchWrap())
        page.addView(TextView(this).apply {
            text = "Internet answers: factual/latest questions par Moto web search snippets laane ki koshish karta hai aur sources ke links dikhata hai. 'Search Internet' button ya 'search [topic]' command se direct search karo. Search ko API key nahi chahiye; AI answer summarize karne ke liye local Termux server ya apna configured compatible AI endpoint chahiye. Internet search fail ho sakti hai agar search provider connection/blocking ki wajah se unavailable ho."
            textSize = 12f; setTextColor(Color.rgb(161, 178, 194)); setPadding(0, dp(8), 0, dp(8))
        })
        page.addView(button("Clear chat history") {
            memory.clearChat(); answerView.text = "Chat history clear kar di. Saved memory alag hai."
        }, matchWrap())
        page.addView(button("Forget all saved memory") {
            memory.clear(); answerView.text = "Saved memory clear kar di."
        }, matchWrap())
        page.addView(TextView(this).apply {
            text = "MOTO v1 · Phone actions may require confirmation. Android does not allow silent app installs, forced app-closing, or third-party call blocking. Screen capture and contact access are permission-gated."
            textSize = 11f; setTextColor(Color.rgb(111, 132, 150)); setPadding(0, dp(18), 0, 0)
        })
        setContentView(scroll)
    }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_PERMISSIONS)
            return
        }
        try {
            val intent = Intent(this, JarvisService::class.java).setAction(MotoVoiceService.ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            updateStatus("STARTING VOICE STANDBY…")
        } catch (e: Exception) {
            updateStatus("Voice start failed: ${e.message}")
        }
    }

    private fun requestContacts() {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            toast("Contact lookup already allowed hai.")
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTACTS)
        }
    }

    private fun stopVoice() {
        startService(Intent(this, JarvisService::class.java).setAction(MotoVoiceService.ACTION_STOP))
        voiceActive = false
        updateStatus("VOICE STANDBY STOPPED")
    }

    private fun ask(question: String) {
        updateStatus("THINKING…")
        answerView.text = "Moto soch raha hai…"
        brain.handle(question) { displayAnswer(it) }
    }

    private fun displayAnswer(text: String) {
        answerView.text = text
        updateStatus("READY")
        speak(text)
    }

    private fun requestScreenCapture() {
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), REQ_SCREEN)
        } catch (e: Exception) { toast("Screen capture available nahi: ${e.message}") }
    }

    @Deprecated("Android system screen-capture permission result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SCREEN) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, ScreenCaptureService::class.java)
                    .setAction(ScreenCaptureService.ACTION_CAPTURE)
                    .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                    .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
                updateStatus("CAPTURING ONE SCREEN FRAME…")
            } else updateStatus("SCREEN CAPTURE CANCELLED")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMISSIONS) {
            val index = permissions.indexOf(Manifest.permission.RECORD_AUDIO)
            if (index >= 0 && grantResults.getOrNull(index) == PackageManager.PERMISSION_GRANTED) startVoice()
            else toast("Mic permission ke bina voice standby nahi chalega.")
        } else if (requestCode == REQ_CONTACTS) {
            toast(if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) "Contact lookup allowed hai." else "Theek hai, contacts access nahi diya. App names aur phone numbers phir bhi use kar sakta hai.")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) tts.language = Locale("en", "IN")
            tts.setSpeechRate(1.0f)
        }
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text.take(4000), TextToSpeech.QUEUE_FLUSH, null, "moto-${System.currentTimeMillis()}")
    }

    private fun updateStatus(value: String) { if (::statusView.isInitialized) statusView.text = value }
    private fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()
    private fun hideKeyboard() {
        try { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(promptField.windowToken, 0); promptField.clearFocus() } catch (_: Exception) {}
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun rounded(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply { setColor(fill); setCornerRadius(dp(radius).toFloat()); setStroke(dp(1), stroke) }
    private fun section(label: String) = TextView(this).apply {
        text = label; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(238, 247, 255))
        setPadding(0, dp(18), 0, dp(9))
    }
    private fun fieldLabel(label: String) = TextView(this).apply { text = label; textSize = 12f; setTextColor(Color.rgb(157, 181, 198)); setPadding(0, dp(8), 0, dp(5)) }
    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f; setTextColor(Color.rgb(5, 20, 28))
        background = rounded(Color.rgb(75, 226, 208), Color.rgb(110, 247, 228), 13)
        setPadding(dp(8), dp(5), dp(8), dp(5)); setOnClickListener { onClick() }
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(7) }
    private fun weighted() = LinearLayout.LayoutParams(0, dp(48), 1f)
    private fun space(width: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(width, 1) }

    override fun onDestroy() {
        if (receiverRegistered) try { unregisterReceiver(receiver) } catch (_: Exception) {}
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }

    companion object {
        private const val REQ_PERMISSIONS = 100
        private const val REQ_SCREEN = 101
        private const val REQ_CONTACTS = 102
    }
}
