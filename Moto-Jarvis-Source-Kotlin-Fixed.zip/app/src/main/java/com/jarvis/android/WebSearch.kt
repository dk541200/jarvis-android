package com.jarvis.android

import android.text.Html
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.regex.Pattern

/** Best-effort, no-API-key web search. Retrieved web content is untrusted reference text. */
data class WebHit(val title: String, val url: String, val snippet: String)

object WebSearch {
    fun search(query: String, limit: Int = 5): List<WebHit> {
        val q = query.trim().take(300)
        require(q.isNotBlank()) { "Search query khaali hai." }
        val searchUrl = "https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8")
        val connection = java.net.URL(searchUrl).openConnection() as java.net.HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 8000
        connection.readTimeout = 9000
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36")
        connection.setRequestProperty("Accept-Language", "en-US,en;q=0.9,hi;q=0.8")
        connection.setRequestProperty("Accept", "text/html,application/xhtml+xml")
        val code = connection.responseCode
        if (code !in 200..299) {
            connection.disconnect()
            throw IllegalStateException("Search HTTP $code")
        }
        val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText().take(1_500_000) }
        connection.disconnect()

        val anchorPattern = Pattern.compile("""(?is)<a\b([^>]*class=['"][^'"]*result__a[^'"]*['"][^>]*)>(.*?)</a>""")
        val matcher = anchorPattern.matcher(html)
        val hits = mutableListOf<WebHit>()
        while (matcher.find() && hits.size < limit) {
            val attrs = matcher.group(1).orEmpty()
            val title = cleanHtml(matcher.group(2).orEmpty()).take(180)
            val hrefMatch = Pattern.compile("""(?is)href\s*=\s*['"]([^'"]+)['"]""").matcher(attrs)
            if (!hrefMatch.find()) continue
            var link = cleanHtml(hrefMatch.group(1).orEmpty()).trim()
            if (link.contains("uddg=")) {
                val encoded = link.substringAfter("uddg=").substringBefore('&')
                try { link = URLDecoder.decode(encoded, "UTF-8") } catch (_: Exception) { }
            }
            if (link.startsWith("//")) link = "https:$link"
            if (title.isBlank() || !link.startsWith("https://") || link.contains("duckduckgo.com/y.js")) continue
            val from = matcher.end()
            val nearby = html.substring(from, minOf(html.length, from + 2400))
            val snippetMatch = Pattern.compile("""(?is)<(?:a|div|td)[^>]*class=['"][^'"]*result__snippet[^'"]*['"][^>]*>(.*?)</(?:a|div|td)>""").matcher(nearby)
            val snippet = if (snippetMatch.find()) cleanHtml(snippetMatch.group(1).orEmpty()).take(450) else ""
            hits.add(WebHit(title, link, snippet))
        }
        return hits.distinctBy { it.url }.take(limit)
    }

    private fun cleanHtml(value: String): String = Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY)
        .toString().replace(Regex("\\s+"), " ").trim()

    fun context(hits: List<WebHit>): String = hits.mapIndexed { i, hit ->
        "[${i + 1}] ${hit.title}\nURL: ${hit.url}\nSnippet: ${hit.snippet.ifBlank { "No snippet provided." }}"
    }.joinToString("\n\n").take(5000)

    fun sourceList(hits: List<WebHit>): String = hits.take(5).mapIndexed { i, hit ->
        "${i + 1}. ${hit.title}\n${hit.url}"
    }.joinToString("\n")
}
