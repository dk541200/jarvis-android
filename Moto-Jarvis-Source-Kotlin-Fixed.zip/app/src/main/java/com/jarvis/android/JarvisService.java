package com.jarvis.android;

/** Compatibility entry point for the existing JARVIS APK build pipeline. */
public final class JarvisService extends MotoVoiceService {
    public JarvisService() { super(); }
}
