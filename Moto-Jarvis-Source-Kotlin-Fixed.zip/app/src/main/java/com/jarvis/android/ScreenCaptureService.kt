package com.jarvis.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.io.FileOutputStream

/** Captures one frame only after the Android system consent dialog. */
class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var captured = false
    private val main = Handler(Looper.getMainLooper())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_CAPTURE) { stopSelf(); return START_NOT_STICKY }
        createChannel()
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val notification = builder.setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Moto screen capture")
            .setContentText("Capturing one frame after your approval")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIF, notification)

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) else intent.getParcelableExtra(EXTRA_RESULT_DATA)
        if (data == null || resultCode == 0) { fail("System screen permission data missing."); return START_NOT_STICKY }
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels.coerceAtLeast(1)
            val height = metrics.heightPixels.coerceAtLeast(1)
            val density = metrics.densityDpi
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            reader?.setOnImageAvailableListener({ imageReader ->
                if (captured) return@setOnImageAvailableListener
                val image = try { imageReader.acquireLatestImage() } catch (_: Exception) { null } ?: return@setOnImageAvailableListener
                try {
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val wideBitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                    wideBitmap.copyPixelsFromBuffer(buffer)
                    val cropped = Bitmap.createBitmap(wideBitmap, 0, 0, width, height)
                    val maxSide = 1600
                    val scale = minOf(1f, maxSide.toFloat() / maxOf(width, height))
                    val finalBitmap = if (scale < 1f) Bitmap.createScaledBitmap(cropped, (width * scale).toInt(), (height * scale).toInt(), true) else cropped
                    val file = File(cacheDir, "moto-screen.jpg")
                    FileOutputStream(file).use { finalBitmap.compress(Bitmap.CompressFormat.JPEG, 75, it) }
                    captured = true
                    sendBroadcast(Intent(ACTION_CAPTURED).setPackage(packageName).putExtra(EXTRA_PATH, file.absolutePath))
                    if (finalBitmap !== cropped) finalBitmap.recycle()
                    if (cropped !== wideBitmap) cropped.recycle()
                    wideBitmap.recycle()
                    main.postDelayed({ stopCapture() }, 200)
                } catch (e: Exception) { fail("Could not capture screen: ${e.message}") }
                finally { image.close() }
            }, main)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopCapture() }
            }, main)
            virtualDisplay = projection?.createVirtualDisplay(
                "MotoSingleScreenCapture", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader?.surface, null, main
            )
            main.postDelayed({ if (!captured) fail("Screen frame not available. Try again once.") }, 2500)
        } catch (e: Exception) { fail("Screen capture error: ${e.message}") }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
                NotificationChannel(CHANNEL, "Moto screen capture", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }
    private fun fail(reason: String) {
        sendBroadcast(Intent(ACTION_FAILED).setPackage(packageName).putExtra("error", reason))
        stopCapture()
    }
    private fun stopCapture() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { reader?.setOnImageAvailableListener(null, null); reader?.close() } catch (_: Exception) {}
        reader = null
        val current = projection
        projection = null
        try { current?.stop() } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
    override fun onDestroy() { stopCapture(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_CAPTURE = "com.jarvis.android.screen.CAPTURE"
        const val ACTION_CAPTURED = "com.jarvis.android.screen.CAPTURED"
        const val ACTION_FAILED = "com.jarvis.android.screen.FAILED"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_PATH = "path"
        private const val CHANNEL = "moto_screen_channel"
        private const val NOTIF = 7412
    }
}
