# Security notes

- Keep the repository private while preparing the app. Never commit credentials, model tokens, keystore files, or real personal chat exports.
- Use HTTPS for non-loopback AI endpoints. The Android network security config permits cleartext only for loopback targets used by local inference.
- Provider keys are stored in AndroidX EncryptedSharedPreferences. Rooted devices, backups outside the app, memory inspection, provider logs and compromised devices remain outside this app's guarantees.
- The app PIN is optional and stored as a PBKDF2-HMAC-SHA256 hash with a random salt; it is not a substitute for the Android device lock.
- Backup files are encrypted separately with a user-provided password. Keep that password separate from the backup. There is no password reset for an encrypted backup.
- Phone shortcuts only open apps/system UIs. Calls open the dialler; messages and payments are not silently submitted.
- Search results are untrusted context. The model instruction says not to treat website text as commands, but model prompt instructions are not a formal security boundary.
- Review and device-test all changes before installing a build from any source.
- Owner voice matching is experimental speaker-vector similarity for hands-free commands only. It is vulnerable to replay/imitation and may reject the owner's voice; it is not liveness detection or secure authentication. Never use it to unlock Android, approve payments, or protect accounts.
- The message agent uses Accessibility to inspect visible UI and may draft a message, but it requires a separate confirmation before attempting a Send click. UI heuristics may fail; always check recipient and message in the target app and verify delivery yourself.
