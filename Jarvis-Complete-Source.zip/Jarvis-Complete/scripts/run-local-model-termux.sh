#!/data/data/com.termux/files/usr/bin/bash
set -eu

# Usage: bash run-local-model-termux.sh [path-to-model.gguf] [api-model-alias]
# The model file is intentionally not included in the project ZIP.
if ! command -v llama-server >/dev/null 2>&1; then
  echo "llama-server is not installed or not on PATH. Install/build llama.cpp first." >&2
  exit 1
fi

MODEL_PATH="${1:-}"
MODEL_ALIAS="${2:-}"
if [ -z "$MODEL_PATH" ]; then
  for candidate in \
    "$HOME/models/Qwen3-1.7B-Q4_K_M.gguf" \
    "$HOME/models/qwen3-1.7b/Qwen3-1.7B-Q4_K_M.gguf" \
    "$HOME/models/qwen4b/Qwen3-4B-Q4_K_M.gguf"; do
    if [ -f "$candidate" ]; then MODEL_PATH="$candidate"; break; fi
  done
fi
if [ -z "$MODEL_PATH" ] || [ ! -f "$MODEL_PATH" ]; then
  echo "Model file not found. Run: bash run-local-model-termux.sh /full/path/model.gguf ModelAlias" >&2
  exit 2
fi
if [ -z "$MODEL_ALIAS" ]; then
  base="$(basename "$MODEL_PATH" | tr '[:upper:]' '[:lower:]')"
  case "$base" in
    *qwen3-4b*) MODEL_ALIAS="Qwen3-4B" ;;
    *qwen3-1.7b*) MODEL_ALIAS="Qwen3-1.7B" ;;
    *) MODEL_ALIAS="JarvisLocal" ;;
  esac
fi

echo "Starting local model: $MODEL_ALIAS"
echo "Jarvis endpoint: http://127.0.0.1:8080/v1/chat/completions"
echo "Keep Termux open and set this same model alias in Jarvis Settings."
exec llama-server -m "$MODEL_PATH" --host 127.0.0.1 --port 8080 -c 2048 --alias "$MODEL_ALIAS"
