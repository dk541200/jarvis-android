@echo off
setlocal
set "VERSION=8.9"
where gradle >nul 2>nul
if %ERRORLEVEL%==0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
set "BASE=%USERPROFILE%\.gradle\jarvis-gradle"
set "GRADLE_HOME=%BASE%\gradle-%VERSION%"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  set "ARCHIVE=%BASE%\gradle-%VERSION%-bin.zip"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%BASE%\gradle-%VERSION%-bin.zip'; Expand-Archive -Path '%BASE%\gradle-%VERSION%-bin.zip' -DestinationPath '%BASE%' -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
