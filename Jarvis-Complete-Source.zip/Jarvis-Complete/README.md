# Jarvis AI — consolidated Android source package

A dark, local-first Android assistant source project for the `com.jarvis.android` app. This package combines the app UI, AI routing, web context, on-device encrypted storage, explicit memories, app lock, password-encrypted backup/restore, phone shortcuts, photo/screenshot questions, voice input and spoken replies.

> **Build status:** this environment does not have the Android SDK/Gradle distribution and cannot run an Android device. The source ZIP has been checked for file integrity and XML structure, but the APK has **not** been built or device-tested here. A GitHub Actions workflow is included to compile it on a GitHub runner. Do not treat a source ZIP as an already-tested APK.

## Included features

- **Built-in on-device AI:** the Release workflow adds Qwen3-0.6B Q4_K_M and the official llama.cpp Android native inference library to the APK. It is much smaller than the previous 1.7B model and should reduce memory/storage pressure; the 0.6B model is also less capable, and actual speed must be measured on the target phone. In Settings you can switch to an external OpenAI-compatible local server instead.
- **Local-first routing:** in `AUTO` mode ordinary questions use the embedded model first; current-information, long/research-style and image questions can try an optional online endpoint first. If a route fails, the router tries the other available route. `LOCAL_ONLY` turns off online AI and auto-search; `ONLINE_FIRST` tries the configured online model and then local.
- **Automatic web context:** current-information questions can search the public web and pass result snippets/URLs into the model. A separate Internet tab performs a search when you tap Search. Search snippets are untrusted input; verify important claims at the linked sources. Availability/markup of the search provider can change.
- **Spoken replies and voice-first input:** uses Android Text-to-Speech and the phone's SpeechRecognizer. Recognized speech is automatically submitted to the assistant. Language, rate and pitch are configurable; voice quality depends on installed Android voice packs. The phone's speech recognition service may use its own online service.
- **Incremental local replies:** local-model tokens are displayed as they arrive; normal replies use a shorter generation budget. Common `<think>` / control markers are removed before chat display and speech.
- **Installed-app discovery:** recognizes common aliases, then searches Android launcher activities so commands can open other installed apps too (normal apps with a launcher icon). Examples include `open Instagram`, `Spotify open karo`, `open Settings`, `Chrome kholo`, and `Hey Jarvis, open YouTube`.
- **Image questions:** attach a photo or screenshot from your gallery. Images are resized before sending. You need a vision-capable local model or configured online vision endpoint for image understanding.
- **Encrypted on-device data:** API settings, chat history and explicit memories use AndroidX EncryptedSharedPreferences backed by Android Keystore. A salted PBKDF2 app PIN can lock the interface.
- **Encrypted backup/restore:** exports settings, chat and saved memories to a password-encrypted `.jrb` file using PBKDF2-HMAC-SHA256 and AES-256-GCM. The app-lock PIN is intentionally not exported.
- **Memory controls:** say `remember: ...`, `show memory`, or `forget memory`; you can add/remove facts from the Memory page.
- **Song requests:** `YouTube kholo aur Tu Hai Kahan song play karo`, `open YouTube and play Tu Hai Kahan`, or `Play Tu Hai Kahan on Spotify` open the relevant search results without waiting for the AI model. When Jarvis Accessibility is enabled, it makes a best-effort attempt to tap a matching result. UI changes, ads, or mismatched speech recognition can still require a manual tap; it cannot promise playback.
- **Optional screen controls:** an actual Android AccessibilityService can handle Back, Home, scrolling, media play/pause, and one-time media-result selection. Android requires the user to enable this separately in Settings; opening apps and searching a song do not require it.
- **Phone actions:** open installed launchable apps, set a timer, navigate Back/Home/scroll, lock the screen through Android Accessibility (Android 9+), or open the dialler for a number.
- **Agent routing and message drafts:** `AgentCoordinator.kt` parses explicit app-message commands such as `Instagram par Faizan ko hi bhej do`. With Jarvis Accessibility enabled, the best-effort UI agent can open the target app, type a recipient into a clearly labelled search field, and draft the body after the intended recipient appears on screen. You must inspect the recipient and draft, then separately say `Jarvis confirm send` to let it tap a visible Send button. UI changes can stop the automation; delivery is never guaranteed by Jarvis. `Jarvis cancel draft` clears the pending task.
- **Honest fallback:** if the model endpoint is unavailable, Jarvis reports the connection problem instead of inventing that an AI answer was generated.
- **No embedded secrets:** online endpoint, model and API key are entered in Settings and stored encrypted on the device.

## Build and device-test notes

1. **The source ZIP does not contain the large model files.** The supplied GitHub Actions workflow downloads Qwen3-0.6B Q4_K_M (about 0.48 GB) and the small Hindi Vosk wake model (about 42 MB), then bundles both. Expect an APK around half a gigabyte, not a 17 MB app. On first use, the models are copied to app-private storage; keep around 1.5 GB free. Qwen3-0.6B is faster/lighter in principle but gives weaker answers than a larger model. It is text-only; image understanding requires a configured vision-capable online/external model.
2. **Hey Jarvis is opt-in.** Settings → Start Hey Jarvis listener requests microphone and notification permissions and starts an Android foreground microphone service with a persistent notification. The Hindi Vosk model runs on-device. The service continues listening until stopped in Jarvis Settings or the notification/service is stopped; it uses extra battery. Speech after the wake phrase is handled locally for supported phone actions. General AI questions arrive through a notification tap rather than unexpectedly forcing Jarvis onto the screen.
3. **Accessibility is also opt-in.** Settings → Open Accessibility Settings → enable “Jarvis screen controls” only if you want screen navigation or the best-effort automatic song-result tap. App launching and song search do not need this permission. Android requires the user to enable the service manually.
4. Voice-command reliability depends on the Vosk model and the phone's microphone. Hindi/Devanagari variants for common app names and commands are normalized, but not every Hinglish accent or every app-specific screen will be understood correctly. A song request normally opens results; playback is not guaranteed because YouTube/Spotify screen layouts can change. Message draft automation is also best-effort and can require manual screen taps.
5. **No online API key is included.** Add your own provider credentials in Settings if you need cloud fallback. Provider quotas/pricing still apply; the package does not guarantee unlimited free API calls.
6. **No PC desktop agent is bundled into this Android application.** This is the Android app source package; a PC companion needs a separate trusted endpoint and device-pairing design.
7. This package is source code, not a built or device-tested APK. The current environment has no Android SDK/device, so use the workflow and then test it on your Moto phone before treating the build as working.

## Optional external local AI (Termux)

The built-in model is the default and does not require Termux. If you want to use a different GGUF model already installed in Termux, turn off “Use built-in Qwen3 0.6B model” in Settings. Then run `scripts/run-local-model-termux.sh` with your model path.

```bash
llama-server -m "$HOME/models/qwen4b/Qwen3-4B-Q4_K_M.gguf" --host 127.0.0.1 --port 8080 -c 2048 --alias Qwen3-4B
```

Then open Jarvis → **Settings** → set the local endpoint to:

`http://127.0.0.1:8080/v1/chat/completions`

For the command above, set local model name to `Qwen3-4B`, then press **Test local connection** and **Save settings**. If a smaller model runs better on your phone, use that model's filename and alias instead. Keep the server process running while you use local AI.

## Configure online fallback

In **Settings → Optional online provider**, add an HTTPS base URL such as the provider's `.../v1`, its exact model ID, and an API key if the provider requires one. The provider must support OpenAI-compatible `POST /v1/chat/completions` requests and the usual `choices[0].message.content` response. Use `https://` for remote endpoints; plain HTTP is allowed only for loopback addresses. Test the endpoint before saving. Keep keys private.

## Build the APK

The supplied workflow must exist at `.github/workflows/build.yml` in `dk541200/jarvis-android`. Put the matching `Jarvis-Complete-Source.zip` at the repository root, then run the workflow from GitHub Actions. It clones the official llama.cpp Android binding, downloads the smaller Qwen3 model, Hindi Vosk wake model, and Vosk speaker-identification model, then verifies the assets are in the APK, and publishes the APK to GitHub Releases. The APK is around half a gigabyte. Manual runs default to **Preview** mode: no signing secrets are needed, and the APK uses package id `com.jarvis.android.preview` so it can install beside the currently installed app. **Update** mode retains `com.jarvis.android` and requires four repository Actions secrets (`JARVIS_KEYSTORE_BASE64`, `JARVIS_KEYSTORE_PASSWORD`, `JARVIS_KEY_ALIAS`, and `JARVIS_KEY_PASSWORD`) containing the exact same signing key as the installed app. Do not uninstall the current app just to work around a signing mismatch.

### Important build note

This ZIP is the app-source input for `build.yml`. That workflow clones the official `llama.cpp` Android `:lib` module and downloads both models before building. The source ZIP alone does not contain the native inference library or large model assets; use the workflow for a full APK.

## Agent actions and owner voice limitations

Jarvis uses a deterministic on-device command coordinator for app launch, screen actions, and a best-effort message draft flow. The message agent can open a supported app, search a recipient via Android Accessibility, and draft the message where that app exposes recognizable UI labels. The target recipient and text must be verified on screen; sending requires an additional explicit `confirm send` command, and delivery is not guaranteed. This is not a universal API for every messaging app and may need manual taps when an app changes its UI.

The experimental Owner Voice Profile screen collects three Vosk speaker vectors and stores only the normalized vector in encrypted app storage, not the audio samples. It currently gates commands received by the hands-free listener, not the separate tap-to-talk recognizer. A speaker vector is not liveness detection: recordings or imitation may fool the check, and the initial similarity threshold has not been calibrated on the target phone. Do not use this feature to protect money, accounts, or device access. Android's own PIN/pattern/biometric controls remain the only device-unlock path.

The coordinator is rule-based task routing, not a self-directed multi-agent system that can invent and autonomously verify arbitrary tasks. Future agent types should expose a narrow allow-listed action API, return structured results, and require confirmation for external side effects.

## Usage examples

- `open Instagram` / `Instagram open karo`
- `open WhatsApp` / `WhatsApp kholo`
- `Chrome open karo` / `open Settings`
- `Hey Jarvis, YouTube kholo aur Tu Hai Kahan song play karo`
- `open YouTube and play Tu Hai Kahan`
- `Play Tu Hai Kahan on Spotify`
- `pause music` / `go back` (after enabling Accessibility)
- `set timer for 5 minutes`
- `remember: I prefer Hinglish explanations`
- `show memory`
- `forget memory`
- `aaj ka weather in Gwalior` (with web enabled and internet available)

## Project layout

- `app/src/main/java/com/jarvis/android/MainActivity.kt` — dark UI, chat, settings, voice, backup dialogs and page navigation
- `EmbeddedLocalModel.kt` — direct on-device GGUF inference via the llama.cpp Android binding
- `JarvisEngine.kt` — embedded-local/optional-online router and OpenAI-compatible API requests
- `WebSearch.kt` — public search provider integration
- `SecureStore.kt` — encrypted settings, conversations, memories and app PIN
- `BackupCrypto.kt` — password-encrypted backup file
- `VoiceOutput.kt` — Android TTS voice selection/speech rate/pitch
- `LocalActions.kt` — deterministic phone actions
- `ImageUtils.kt` — screenshot/photo resizing and encoding
- `scripts/run-local-model-termux.sh` — helper for starting local GGUF server

## Privacy

This app has no built-in analytics, advertising SDK, account backend or cloud database. Chat and settings are locally encrypted. When online AI or web search runs, the question and relevant context leave the phone for the configured provider/search site. The phone's own speech recognition and TTS services may have separate data handling. Android Keystore encryption does not protect a device that is already unlocked or compromised.


## Patch notes (3.1.1 source)

- Switched built-in inference from Qwen3-1.7B to Qwen3-0.6B Q4_K_M to reduce model size and memory pressure; the speed/quality trade-off still needs device testing.
- Added a Hindi Vosk model and explicit opt-in foreground microphone service for offline `Hey Jarvis` detection.
- Added runtime permission prompts for microphone and notifications when the wake service is started; added a persistent notification and stop control in Settings.
- Added Android AccessibilityService setup and optional Back/Home/scroll/media controls plus best-effort media-result selection.
- Improved app-command parsing for English/Hinglish word orders (for example, “YouTube open karo aur Tu Hai Kahan song play karo”) and Spotify deep-link visibility. Arbitrary apps are discovered through Android launcher activities; apps without a launcher icon cannot be launched by name.
- Voice transcript automatically submits after tap-to-talk recognition; local AI answers stream to the UI with a shorter output budget and cleaned model-control markers.
- Bumped Android metadata to versionCode 5 / versionName 3.1.1-command-parser for signed update builds.
