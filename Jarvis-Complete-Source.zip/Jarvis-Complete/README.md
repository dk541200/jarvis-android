# Jarvis AI — consolidated Android source package

A dark, local-first Android assistant source project for the `com.jarvis.android` app. This package combines the app UI, AI routing, web context, on-device encrypted storage, explicit memories, app lock, password-encrypted backup/restore, phone shortcuts, photo/screenshot questions, voice input and spoken replies.

> **Build status:** this environment does not have the Android SDK/Gradle distribution and cannot run an Android device. The source ZIP has been checked for file integrity and XML structure, but the APK has **not** been built or device-tested here. A GitHub Actions workflow is included to compile it on a GitHub runner. Do not treat a source ZIP as an already-tested APK.

## Included features

- **Built-in on-device AI:** the Release workflow adds the Qwen3-1.7B Q4_K_M GGUF model and the official llama.cpp Android native inference library directly to the APK. Text questions run on-device after the model is copied to private app storage on first use. In Settings you can switch to an external OpenAI-compatible local server instead.
- **Local-first routing:** in `AUTO` mode ordinary questions use the embedded model first; current-information, long/research-style and image questions can try an optional online endpoint first. If a route fails, the router tries the other available route. `LOCAL_ONLY` turns off online AI and auto-search; `ONLINE_FIRST` tries the configured online model and then local.
- **Automatic web context:** current-information questions can search the public web and pass result snippets/URLs into the model. A separate Internet tab performs a search when you tap Search. Search snippets are untrusted input; verify important claims at the linked sources. Availability/markup of the search provider can change.
- **Natural spoken replies and voice input:** uses Android Text-to-Speech and the phone's SpeechRecognizer. Language, rate and pitch are configurable. Quality depends on the voice packages installed on Android. Voice input starts only when you tap the mic; the phone's recognition service may use its own online service.
- **Image questions:** attach a photo or screenshot from your gallery. Images are resized before sending. You need a vision-capable local model or configured online vision endpoint for image understanding.
- **Encrypted on-device data:** API settings, chat history and explicit memories use AndroidX EncryptedSharedPreferences backed by Android Keystore. A salted PBKDF2 app PIN can lock the interface.
- **Encrypted backup/restore:** exports settings, chat and saved memories to a password-encrypted `.jrb` file using PBKDF2-HMAC-SHA256 and AES-256-GCM. The app-lock PIN is intentionally not exported.
- **Memory controls:** say `remember: ...`, `show memory`, or `forget memory`; you can add/remove facts from the Memory page.
- **Phone actions:** open installed Instagram/WhatsApp/YouTube/Telegram/Chrome/Settings, set a timer, or open the dialler for a number. It does not silently send messages or make a call/payment.
- **Honest fallback:** if the model endpoint is unavailable, Jarvis reports the connection problem instead of inventing that an AI answer was generated.
- **No embedded secrets:** online endpoint, model and API key are entered in Settings and stored encrypted on the device.

## What cannot be bundled as a working binary

1. **The source ZIP does not contain the large GGUF model.** The repository build workflow downloads the Qwen3-1.7B Q4_K_M GGUF model and bundles it into the release APK with the native llama.cpp inference library. Expect an APK around 1.3 GB, not a 17 MB app. On the first launch, Jarvis copies the model to private app storage; keep at least about 2.6 GB free. The model is text-only; image understanding requires a configured vision-capable online or external model.
2. **No online API key is included.** Add your own provider credentials in Settings if you need cloud fallback. Provider quotas/pricing still apply; this package does not guarantee unlimited free API calls.
3. **Always-on `Hey Jarvis` wake-word detection is not enabled.** The included voice path is permission-based tap-to-talk. A reliable always-on offline wake word needs a dedicated wake-word model, battery/background behavior and testing on the target phone; this ZIP does not pretend that it is implemented.
4. **No PC desktop agent is bundled into this Android application.** This is the Android app source package; a PC companion needs a separate trusted endpoint and device-pairing design.
5. This package is source code, not a signed APK. Sign/review a release build before distributing it.

## Optional external local AI (Termux)

The built-in model is the default and does not require Termux. If you want to use a different GGUF model already installed in Termux, turn off “Use built-in Qwen3 1.7B model” in Settings. Then run `scripts/run-local-model-termux.sh` with your model path.

```bash
llama-server -m "$HOME/models/qwen4b/Qwen3-4B-Q4_K_M.gguf" --host 127.0.0.1 --port 8080 -c 2048 --alias Qwen3-4B
```

Then open Jarvis → **Settings** → set the local endpoint to:

`http://127.0.0.1:8080/v1/chat/completions`

For the command above, set local model name to `Qwen3-4B`, then press **Test local connection** and **Save settings**. If a smaller model runs better on your phone, use that model's filename and alias instead. Keep the server process running while you use local AI.

## Configure online fallback

In **Settings → Optional online provider**, add an HTTPS base URL such as the provider's `.../v1`, its exact model ID, and an API key if the provider requires one. The provider must support OpenAI-compatible `POST /v1/chat/completions` requests and the usual `choices[0].message.content` response. Use `https://` for remote endpoints; plain HTTP is allowed only for loopback addresses. Test the endpoint before saving. Keep keys private.

## Build the APK

The repository-root `.github/workflows/build.yml` is the intended build for this package. Upload `Jarvis-Complete-Source.zip` to the root of `dk541200/jarvis-android`, replace the root `build.yml` with the supplied native-model workflow, then run it from GitHub Actions. That workflow clones the official llama.cpp Android binding, downloads the Qwen3 model, verifies the model is present in the APK, and publishes a debug-signed APK to GitHub Releases. The APK will be large; it is not a small 17 MB download.

### Important build note

This ZIP is the app-source input for the repository-root `build.yml` workflow. That workflow clones the official `llama.cpp` Android `:lib` module and downloads the GGUF model before building. The source ZIP by itself is therefore not a standalone Android Studio project; use the native-model workflow so the actual inference library and bundled model are present.

## Usage examples

- `open instagram`
- `open what` / `open whatsapp`
- `open yt` / `open youtube`
- `set timer for 5 minutes`
- `remember: I prefer Hinglish explanations`
- `show memory`
- `forget memory`
- `aaj ka weather in Gwalior` (with web enabled and internet available)

## Project layout

- `app/src/main/java/com/jarvis/android/MainActivity.kt` — dark UI, chat, settings, voice, backup dialogs and page navigation
- `EmbeddedLocalModel.kt` — direct on-device GGUF inference via the llama.cpp Android binding
- `JarvisEngine.kt` — embedded-local/optional-online router and OpenAI-compatible API requests
- `WebSearch.kt` — public search provider integration
- `SecureStore.kt` — encrypted settings, conversations, memories and app PIN
- `BackupCrypto.kt` — password-encrypted backup file
- `VoiceOutput.kt` — Android TTS voice selection/speech rate/pitch
- `LocalActions.kt` — deterministic phone actions
- `ImageUtils.kt` — screenshot/photo resizing and encoding
- `scripts/run-local-model-termux.sh` — helper for starting local GGUF server

## Privacy

This app has no built-in analytics, advertising SDK, account backend or cloud database. Chat and settings are locally encrypted. When online AI or web search runs, the question and relevant context leave the phone for the configured provider/search site. The phone's own speech recognition and TTS services may have separate data handling. Android Keystore encryption does not protect a device that is already unlocked or compromised.
