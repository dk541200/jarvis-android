# Keep Android and OkHttp defaults. Release shrinking is disabled until a signed release is configured.
