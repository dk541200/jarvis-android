package com.jarvis.android

import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

/** Lightweight public web search. Results are untrusted snippets, never instructions. */
class WebSearch {
    private val client = OkHttpClient.Builder()
        .callTimeout(12, TimeUnit.SECONDS)
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    fun search(query: String, maxResults: Int = 5): List<SearchHit> {
        val encoded = URLEncoder.encode(query.take(240), StandardCharsets.UTF_8.name())
        val request = Request.Builder()
            .url("https://html.duckduckgo.com/html/?q=$encoded")
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36")
            .build()
        val html = client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Web search returned HTTP ${response.code}")
            response.body?.string().orEmpty()
        }
        val resultBlocks = Regex("(?s)<div class=\\\"result results_links.*?</div>\\s*</div>\\s*</div>", RegexOption.IGNORE_CASE)
        val blocks = resultBlocks.findAll(html).map { it.value }.toList()
        val parsed = blocks.mapNotNull { block ->
            val linkMatch = Regex("<a[^>]*class=\\\"result__a\\\"[^>]*href=\\\"([^\\\"]+)\\\"[^>]*>(.*?)</a>", RegexOption.IGNORE_CASE).find(block)
                ?: Regex("<a[^>]*href=\\\"([^\\\"]+)\\\"[^>]*class=\\\"result__a\\\"[^>]*>(.*?)</a>", RegexOption.IGNORE_CASE).find(block)
            val snippetMatch = Regex("<a[^>]*class=\\\"result__snippet\\\"[^>]*>(.*?)</a>|<div[^>]*class=\\\"result__snippet[^\\\"]*\\\"[^>]*>(.*?)</div>", RegexOption.IGNORE_CASE).find(block)
            val title = linkMatch?.groupValues?.getOrNull(2)?.let(::stripHtml).orEmpty()
            val link = linkMatch?.groupValues?.getOrNull(1).orEmpty().let(::decodeRedirect)
            val snippet = snippetMatch?.groupValues?.drop(1)?.firstOrNull { it.isNotBlank() }?.let(::stripHtml).orEmpty()
            if (title.isBlank() || !link.startsWith("http")) null else SearchHit(title, snippet, link)
        }.distinctBy { it.url }.take(maxResults)
        if (parsed.isNotEmpty()) return parsed

        // Markup changes happen; a conservative fallback extracts distinct outgoing links and nearby text.
        return Regex("(?s)<a[^>]+href=\\\"(https?://[^\\\"]+)\\\"[^>]*>(.*?)</a>")
            .findAll(html).mapNotNull { m ->
                val url = m.groupValues[1]
                val title = stripHtml(m.groupValues[2])
                if (title.length < 4 || url.contains("duckduckgo.com")) null else SearchHit(title, "", url)
            }.distinctBy { it.url }.take(maxResults).toList()
    }

    private fun decodeRedirect(raw: String): String {
        val unescaped = raw.replace("&amp;", "&")
        val target = Regex("[?&]uddg=([^&]+)").find(unescaped)?.groupValues?.getOrNull(1)
        return if (target != null) runCatching { java.net.URLDecoder.decode(target, "UTF-8") }.getOrDefault(unescaped) else unescaped
    }

    private fun stripHtml(raw: String): String = raw
        .replace(Regex("<[^>]+>"), " ")
        .replace("&amp;", "&").replace("&quot;", "\"")
        .replace("&#x27;", "'").replace("&#39;", "'")
        .replace("&lt;", "<").replace("&gt;", ">")
        .replace(Regex("\\s+"), " ").trim()
}
