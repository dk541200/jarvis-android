package com.jarvis.android

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.util.Locale

/** Optional, user-enabled service for explicit screen-navigation and media-button commands. */
class JarvisAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        activeService = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // The message flow only drafts text. Sending requires a separate explicit confirmation.
        advancePendingMessageTask()
        // Only auto-select a media result after an explicit spoken play-song request.
        tryTapQueuedMediaResult()
    }
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (activeService === this) activeService = null
        super.onDestroy()
    }

    private fun execute(action: String): Boolean = when (action) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "scroll_down" -> scrollScrollableNode(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        "scroll_up" -> scrollScrollableNode(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
        "media_play" -> clickMatchingAction(setOf("play", "resume", "continue"))
        "media_pause" -> clickMatchingAction(setOf("pause", "stop"))
        "lock_screen" -> if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        } else false
        else -> false
    }

    private var queuedMediaQuery: String? = null
    private var queuedMediaPackage: String? = null
    private var queuedMediaDeadline: Long = 0L

    private enum class MessagePhase { OPENING, WAITING_FOR_RECIPIENT, READY_TO_SEND }
    @Volatile private var pendingMessageTask: AgentCoordinator.MessageTask? = null
    private var messagePhase: MessagePhase = MessagePhase.OPENING
    private var draftSet = false
    private var lastMessageUiNoticeAt = 0L

    /**
     * Best-effort UI agent. It may type the recipient into an obvious search field and
     * draft text only after the recipient appears on screen. It never taps Send here.
     */
    private fun advancePendingMessageTask() {
        val task = pendingMessageTask ?: return
        val root = rootInActiveWindow ?: return
        try {
            val currentPackage = root.packageName?.toString() ?: return
            if (currentPackage != task.packageName) return
            if (System.currentTimeMillis() - messageStartedAt > 90_000L) {
                clearPendingMessage()
                showMessageUiNotice("Jarvis message task timed out. Koi message send nahi hua.")
                return
            }

            when (messagePhase) {
                MessagePhase.OPENING -> {
                    if (recipientAppearsOnScreen(root, task.recipient) && findMessageComposer(root) != null) {
                        draftMessageIntoComposer(root, task)
                        return
                    }
                    val search = findRecipientSearchField(root)
                    if (search != null) {
                        if (setNodeText(search, task.recipient)) {
                            messagePhase = MessagePhase.WAITING_FOR_RECIPIENT
                            showMessageUiNotice("Search mein '${task.recipient}' dala hai. Ab sahi recipient par tap karo; phir Jarvis message draft karega. Abhi send nahi hua.")
                            return
                        }
                    }
                    if (tapLabeledAction(root, listOf("new message", "new chat", "compose", "create message", "messages", "direct messages", "inbox"))) {
                        showMessageUiNotice("Message screen kholne ki koshish ki. Screen par recipient check karo.")
                    }
                }
                MessagePhase.WAITING_FOR_RECIPIENT -> {
                    if (recipientAppearsOnScreen(root, task.recipient)) {
                        draftMessageIntoComposer(root, task)
                    }
                }
                MessagePhase.READY_TO_SEND -> Unit
            }
        } catch (_: Exception) {
            // UI automation is intentionally best-effort; a changing screen must not crash Jarvis.
        } finally {
            root.recycleCompat()
        }
    }

    private var messageStartedAt: Long = 0L

    private fun draftMessageIntoComposer(root: AccessibilityNodeInfo, task: AgentCoordinator.MessageTask) {
        if (draftSet) return
        val composer = findMessageComposer(root) ?: return
        if (!recipientAppearsOnScreen(root, task.recipient)) return
        if (setNodeText(composer, task.body)) {
            draftSet = true
            messagePhase = MessagePhase.READY_TO_SEND
            showMessageUiNotice("Draft ready: ${task.recipient} ko '${task.body}'. Screen par recipient/message check karke ‘Jarvis confirm send’ bolo, ya khud Send dabao.")
        }
    }

    private fun findRecipientSearchField(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val nodes = collectNodes(root)
        return nodes.firstOrNull { node ->
            if (!node.isEditable || !node.isEnabled) return@firstOrNull false
            val label = nodeLabel(node).lowercase(Locale.ROOT)
            label.contains("search") || label.contains("to ") || label == "to" ||
                label.contains("people") || label.contains("recipient") || label.contains("contact") || label.contains("username")
        }
    }

    private fun findMessageComposer(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        // Fail closed: never guess that a search box is the message composer. Instagram,
        // WhatsApp and Telegram normally expose a Message/Write message hint on the draft field.
        // UI labels can change, in which case the user must type manually instead.
        return collectNodes(root).firstOrNull { node ->
            if (!node.isEditable || !node.isEnabled) return@firstOrNull false
            val label = nodeLabel(node).lowercase(Locale.ROOT)
            label.contains("message") || label.contains("write a message") ||
                label.contains("type a message") || label.contains("reply to")
        }
    }

    private fun recipientAppearsOnScreen(root: AccessibilityNodeInfo, recipient: String): Boolean {
        val wanted = normalizeText(recipient)
        if (wanted.length < 2) return false
        return collectNodes(root).any { node ->
            !node.isEditable && !node.isPassword && normalizeText(nodeLabel(node)).let { label ->
                label == wanted || (label.length in wanted.length..(wanted.length + 28) && label.startsWith(wanted))
            }
        }
    }

    private fun nodeLabel(node: AccessibilityNodeInfo): String = listOf(
        node.text?.toString().orEmpty(),
        node.contentDescription?.toString().orEmpty(),
        if (android.os.Build.VERSION.SDK_INT >= 26) node.hintText?.toString().orEmpty() else ""
    ).filter(String::isNotBlank).joinToString(" ").trim()

    private fun collectNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val all = ArrayList<AccessibilityNodeInfo>()
        fun walk(node: AccessibilityNodeInfo) {
            all += node
            for (index in 0 until node.childCount) {
                val child = node.getChild(index) ?: continue
                walk(child)
            }
        }
        walk(root)
        return all
    }

    private fun setNodeText(node: AccessibilityNodeInfo, text: String): Boolean {
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun tapLabeledAction(root: AccessibilityNodeInfo, labels: List<String>): Boolean {
        val match = findNode(root) { node ->
            if (!node.isEnabled || !node.isClickable) return@findNode false
            val label = nodeLabel(node).lowercase(Locale.ROOT)
            labels.any { label == it || label.contains(it) }
        } ?: return false
        return match.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun showMessageUiNotice(message: String) {
        val now = System.currentTimeMillis()
        if (now - lastMessageUiNoticeAt < 1_500L) return
        lastMessageUiNoticeAt = now
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
        }
    }

    private fun clearPendingMessage() {
        pendingMessageTask = null
        messagePhase = MessagePhase.OPENING
        draftSet = false
        messageStartedAt = 0L
    }

    private fun confirmPendingMessageSend(): Boolean {
        val task = pendingMessageTask ?: return false
        if (messagePhase != MessagePhase.READY_TO_SEND || !draftSet) return false
        val root = rootInActiveWindow ?: return false
        try {
            if (root.packageName?.toString() != task.packageName) return false
            if (!recipientAppearsOnScreen(root, task.recipient)) return false
            val composer = findMessageComposer(root) ?: return false
            if (normalizeText(nodeLabel(composer)).contains(normalizeText(task.body)).not()) return false
            val send = findNode(root) { node ->
                if (!node.isEnabled || !node.isClickable) return@findNode false
                val label = normalizeText(nodeLabel(node))
                label in setOf("send", "sendmessage", "sendnow")
            } ?: return false
            val clicked = send.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            if (clicked) {
                clearPendingMessage()
                return true
            }
            return false
        } finally {
            root.recycleCompat()
        }
    }

    private fun tryTapQueuedMediaResult() {
        val query = queuedMediaQuery ?: return
        if (System.currentTimeMillis() > queuedMediaDeadline) {
            queuedMediaQuery = null
            return
        }
        val expectedPackage = queuedMediaPackage ?: return
        if (rootInActiveWindow?.packageName?.toString() != expectedPackage) return
        val root = rootInActiveWindow ?: return
        try {
            val wanted = normalizeText(query)
            if (wanted.length < 3) return
            val match = findNode(root) { candidate ->
                val className = candidate.className?.toString().orEmpty()
                val label = "${candidate.text?.toString().orEmpty()} ${candidate.contentDescription?.toString().orEmpty()}"
                !className.contains("EditText", ignoreCase = true) &&
                    label.length in 4..220 && normalizeText(label).contains(wanted)
            } ?: return
            var clickable: AccessibilityNodeInfo? = match
            repeat(7) {
                val node = clickable ?: return@repeat
                if (node.isClickable && node.isEnabled && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    queuedMediaQuery = null
                    queuedMediaPackage = null
                    return
                }
                clickable = node.parent
            }
        } finally {
            root.recycleCompat()
        }
    }

    private fun scrollScrollableNode(action: Int): Boolean {
        val root = rootInActiveWindow ?: return false
        return try {
            findNode(root) { it.isScrollable }?.performAction(action) == true
        } finally {
            root.recycleCompat()
        }
    }

    private fun clickMatchingAction(words: Set<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        return try {
            val node = findNode(root) { candidate ->
                val label = "${candidate.text?.toString().orEmpty()} ${candidate.contentDescription?.toString().orEmpty()}".lowercase(Locale.ROOT)
                words.any { word -> label.contains(word) } && candidate.isEnabled && candidate.isClickable
            } ?: return false
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } finally {
            root.recycleCompat()
        }
    }

    private fun findNode(root: AccessibilityNodeInfo, predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (predicate(root)) return root
        for (index in 0 until root.childCount) {
            val child = root.getChild(index) ?: continue
            val found = findNode(child, predicate)
            if (found != null) return found
        }
        return null
    }

    companion object {
        @Volatile private var activeService: JarvisAccessibilityService? = null

        /** Returns false when the user hasn't explicitly enabled the service in Android Settings. */
        fun performAction(action: String): Boolean = activeService?.execute(action) ?: false

        /** Package on the currently visible screen, used only to route an explicitly requested task. */
        fun foregroundPackageName(): String? = runCatching {
            activeService?.rootInActiveWindow?.packageName?.toString()
        }.getOrNull()

        fun queueMessageTask(task: AgentCoordinator.MessageTask): Boolean {
            val service = activeService ?: return false
            service.pendingMessageTask = task
            service.messagePhase = MessagePhase.OPENING
            service.draftSet = false
            service.messageStartedAt = System.currentTimeMillis()
            service.lastMessageUiNoticeAt = 0L
            return true
        }

        fun cancelPendingMessage(): Boolean {
            val service = activeService ?: return false
            val existed = service.pendingMessageTask != null
            service.clearPendingMessage()
            return existed
        }

        fun confirmPendingMessageSend(): Boolean = activeService?.confirmPendingMessageSend() ?: false

        /** Queue a one-time click for a song result, only if the user enabled Accessibility. */
        fun queueMediaResultTap(title: String, platform: String): Boolean {
            val service = activeService ?: return false
            service.queuedMediaQuery = title
            service.queuedMediaPackage = if (platform == "spotify") "com.spotify.music" else "com.google.android.youtube"
            service.queuedMediaDeadline = System.currentTimeMillis() + 25_000L
            return true
        }

        private fun normalizeText(value: String): String = value.lowercase(Locale.ROOT).filter(Char::isLetterOrDigit)
    }
}

/** AccessibilityNodeInfo recycling is not required on newer Android, but this keeps traversal tidy. */
private fun AccessibilityNodeInfo.recycleCompat() {
    @Suppress("DEPRECATION")
    recycle()
}
