package com.jarvis.android

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream

object ImageUtils {
    /** Downscales images before sending them to a configured vision endpoint. */
    fun toJpegDataUri(context: Context, uri: Uri, maxSide: Int = 1280): String {
        val original = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            ?: throw IllegalArgumentException("Image could not be opened. Try another image.")
        val ratio = minOf(1f, maxSide.toFloat() / maxOf(original.width, original.height))
        val bitmap = if (ratio < 1f) Bitmap.createScaledBitmap(
            original,
            (original.width * ratio).toInt().coerceAtLeast(1),
            (original.height * ratio).toInt().coerceAtLeast(1),
            true
        ) else original
        val output = ByteArrayOutputStream()
        try {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 72, output)
            require(output.size() <= 3 * 1024 * 1024) { "Image is too large after compression. Choose a smaller screenshot." }
            return "data:image/jpeg;base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
        } finally {
            if (bitmap !== original) bitmap.recycle()
            original.recycle()
        }
    }
}
