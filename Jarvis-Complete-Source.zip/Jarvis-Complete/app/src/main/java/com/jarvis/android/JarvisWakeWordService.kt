package com.jarvis.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.SpeakerModel
import org.vosk.android.RecognitionListener as VoskRecognitionListener
import org.vosk.android.SpeechService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

/** Optional, explicit offline wake-word listener. The user starts/stops it from Jarvis Settings. */
class JarvisWakeWordService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var speechService: SpeechService? = null
    @Volatile private var voskRecognizer: Recognizer? = null
    @Volatile private var voskModel: Model? = null
    @Volatile private var voskSpeakerModel: SpeakerModel? = null
    @Volatile private var initialized = false
    @Volatile private var enrollmentActive = false
    private val enrollmentVectors = mutableListOf<List<Double>>()
    private lateinit var secureStore: SecureStore
    private var armedUntil = 0L
    private var lastHandledText = ""
    private var lastHandledAt = 0L
    private lateinit var actions: LocalActions

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Loading offline wake detector…"))
        secureStore = SecureStore(applicationContext)
        actions = LocalActions(applicationContext, secureStore)
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, true).apply()

        serviceScope.launch {
            try {
                val modelPath = ensureWakeModelCopied()
                val speakerModelPath = ensureSpeakerModelCopied()
                val model = Model(modelPath.absolutePath)
                val speakerModel = SpeakerModel(speakerModelPath.absolutePath)
                val recognizer = Recognizer(model, 16_000.0f, speakerModel)
                val listener = object : VoskRecognitionListener {
                    override fun onPartialResult(hypothesis: String?) = Unit
                    override fun onResult(hypothesis: String?) = handleHypothesis(hypothesis)
                    override fun onFinalResult(hypothesis: String?) = handleHypothesis(hypothesis)
                    override fun onTimeout() = Unit
                    override fun onError(exception: Exception?) {
                        Log.e(TAG, "Wake-word microphone error", exception)
                        updateNotification("Mic/listening error. Open Jarvis and restart Hey Jarvis.")
                    }
                }
                withContext(Dispatchers.Main) {
                    voskModel = model
                    voskSpeakerModel = speakerModel
                    voskRecognizer = recognizer
                    val service = SpeechService(recognizer, 16_000.0f)
                    speechService = service
                    initialized = service.startListening(listener)
                    if (initialized) updateNotification(if (enrollmentActive) enrollmentPrompt() else "Listening offline for ‘Hey Jarvis’. Say the command in the same sentence or within 10 seconds.")
                    else throw IllegalStateException("Offline microphone listener could not start.")
                }
            } catch (error: Throwable) {
                Log.e(TAG, "Unable to start wake-word service", error)
                updateNotification("Wake listener could not start: ${(error.message ?: "unknown error").take(120)}")
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, false).apply()
                stopSelf()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                enrollmentActive = false
                enrollmentVectors.clear()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_ENROLL_OWNER_VOICE -> {
                enrollmentVectors.clear()
                enrollmentActive = true
                updateNotification(enrollmentPrompt())
            }
        }
        return START_STICKY
    }

    private fun handleHypothesis(rawJson: String?) {
        val raw = rawJson.orEmpty()
        val text = runCatching { JSONObject(raw).optString("text") }.getOrDefault("")
            .trim().replace(Regex("\\s+"), " ")
        if (text.isBlank()) return

        // Vosk may report one utterance through both onResult and onFinalResult.
        // Deduplicate those callbacks; the user should pause between enrolment samples.
        val now = android.os.SystemClock.elapsedRealtime()
        val fingerprint = text.lowercase(Locale.ROOT).filter(Char::isLetterOrDigit)
        if (fingerprint.isNotBlank() && fingerprint == lastHandledText && now - lastHandledAt < 2_500L) return
        lastHandledText = fingerprint
        lastHandledAt = now

        if (enrollmentActive) {
            val vector = OwnerVoiceProfile.vectorFromRecognizerJson(raw)
            if (vector == null) {
                updateNotification("Voice sample did not contain a speaker vector. Speak one full sentence clearly, pause, and try again. Samples: ${enrollmentVectors.size}/3")
                return
            }
            enrollmentVectors += vector
            if (enrollmentVectors.size >= 3) {
                val profile = OwnerVoiceProfile.centroid(enrollmentVectors.take(3))
                if (profile != null) {
                    secureStore.saveOwnerVoiceProfile(profile)
                    enrollmentActive = false
                    enrollmentVectors.clear()
                    updateNotification("Owner voice profile saved encrypted on this phone. This is only a convenience filter, not secure authentication; voice replay can fool it.")
                } else {
                    enrollmentVectors.clear()
                    updateNotification("Could not build owner voice profile. Tap Owner Voice Setup and record three clearer samples.")
                }
            } else {
                updateNotification("Owner voice sample ${enrollmentVectors.size}/3 saved temporarily. Say the same setup phrase again after a short pause.")
            }
            return
        }

        val lower = text.lowercase(Locale.ROOT)
        val wake = Regex("(?i)\\bhey\\s+jarvis\\b|\\bjarvis\\b|हे\\s*जार्विस|हे\\s*जर्विस|जार्विस|जर्विस")
            .find(lower)
        if (wake != null) {
            val remainder = text.substring((wake.range.last + 1).coerceAtMost(text.length))
                .trim(' ', ',', '.', '!', '?', ':', ';', '-')
            armedUntil = System.currentTimeMillis() + COMMAND_WINDOW_MS
            if (remainder.isNotBlank()) {
                armedUntil = 0L
                executeRecognizedCommand(remainder, raw)
            } else {
                updateNotification("Wake word heard. Ab command bolo — next 10 seconds mein.")
            }
            return
        }
        if (System.currentTimeMillis() <= armedUntil) {
            armedUntil = 0L
            executeRecognizedCommand(text, raw)
        }
    }

    private fun enrollmentPrompt(): String = "Owner Voice Setup: same short phrase 3 times bolo, har sample ke beech pause. Audio is not saved; only a voice vector is encrypted. This cannot securely unlock the phone. Samples: ${enrollmentVectors.size}/3."

    private fun executeRecognizedCommand(spoken: String, rawJson: String? = null) {
        val enrolledProfile = secureStore.ownerVoiceProfile()
        if (enrolledProfile != null) {
            val sample = OwnerVoiceProfile.vectorFromRecognizerJson(rawJson.orEmpty())
            if (sample == null) {
                updateNotification("Owner voice check couldn't read this sample. No action was run; speak a full command clearly and retry.")
                return
            }
            if (!OwnerVoiceProfile.likelySameSpeaker(sample, enrolledProfile)) {
                updateNotification("Voice did not match the saved owner profile. No action was run. This is a convenience filter, not a secure lock.")
                return
            }
        }
        // App launches and media searches execute locally without waiting for the LLM.
        val actionResult = runCatching { actions.tryRun(spoken) }.getOrNull()
        if (actionResult != null) {
            updateNotification(actionResult.take(150))
            return
        }
        // Questions that need AI open Jarvis via a notification; Android may block background
        // activity launches from a service, so do not force-open the screen unexpectedly.
        val notificationIntent = Intent(this, MainActivity::class.java).apply {
            putExtra(MainActivity.EXTRA_WAKE_QUERY, spoken)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        val pending = PendingIntent.getActivity(
            this, 7101, notificationIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = buildNotification("Heard: ${spoken.take(90)} · tap notification to ask Jarvis", pending)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification)
    }

    private fun ensureWakeModelCopied(): File {
        val target = File(filesDir, "models/vosk-hindi-small")
        val marker = File(target, ".jarvis-ready")
        if (marker.isFile && File(target, "am/final.mdl").isFile && File(target, "conf/model.conf").isFile) return target
        val staging = File(filesDir, "models/vosk-hindi-small.part")
        staging.deleteRecursively()
        if (!staging.mkdirs()) throw IllegalStateException("Could not create wake-model folder.")
        copyAssetTree("jarvis-wake", staging)
        if (!File(staging, "am/final.mdl").isFile || !File(staging, "conf/model.conf").isFile) {
            staging.deleteRecursively()
            throw IllegalStateException("Offline Hindi wake model missing from APK. Rebuild with the supplied workflow.")
        }
        File(staging, ".jarvis-ready").writeText("ready")
        target.deleteRecursively()
        if (!staging.renameTo(target)) throw IllegalStateException("Could not finish copying wake model.")
        return target
    }

    private fun ensureSpeakerModelCopied(): File {
        val target = File(filesDir, "models/vosk-speaker")
        val marker = File(target, ".jarvis-ready")
        val required = listOf("mfcc.conf", "final.ext.raw", "mean.vec", "transform.mat")
        if (marker.isFile && required.all { File(target, it).isFile }) return target
        val staging = File(filesDir, "models/vosk-speaker.part")
        staging.deleteRecursively()
        if (!staging.mkdirs()) throw IllegalStateException("Could not create speaker-model folder.")
        copyAssetTree("jarvis-speaker", staging)
        if (!required.all { File(staging, it).isFile }) {
            staging.deleteRecursively()
            throw IllegalStateException("Owner voice model missing from APK. Rebuild with the current GitHub workflow.")
        }
        File(staging, ".jarvis-ready").writeText("ready")
        target.deleteRecursively()
        if (!staging.renameTo(target)) throw IllegalStateException("Could not finish copying speaker model.")
        return target
    }

    private fun copyAssetTree(assetPath: String, destination: File) {
        val children = assets.list(assetPath).orEmpty()
        if (children.isEmpty()) {
            destination.parentFile?.mkdirs()
            assets.open(assetPath).use { input -> FileOutputStream(destination).use { output -> input.copyTo(output) } }
        } else {
            if (!destination.exists() && !destination.mkdirs()) throw IllegalStateException("Could not create ${destination.name}")
            children.forEach { child -> copyAssetTree("$assetPath/$child", File(destination, child)) }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Jarvis wake word", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Visible while the user has opted in to offline Hey Jarvis detection."
                setShowBadge(false)
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(text: String, contentIntent: PendingIntent? = defaultPendingIntent()): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID)
        else Notification.Builder(this)
        builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis · Hey Jarvis")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        if (contentIntent != null) builder.setContentIntent(contentIntent)
        return builder.build()
    }

    private fun defaultPendingIntent(): PendingIntent? = runCatching {
        PendingIntent.getActivity(
            this, 7100, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }.getOrNull()

    private fun updateNotification(text: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        initialized = false
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, false).apply()
        runCatching { speechService?.stop() }
        runCatching { speechService?.shutdown() }
        speechService = null
        runCatching { voskRecognizer?.close() }
        voskRecognizer = null
        runCatching { voskModel?.close() }
        voskModel = null
        runCatching { voskSpeakerModel?.close() }
        voskSpeakerModel = null
        enrollmentActive = false
        enrollmentVectors.clear()
        serviceScope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.jarvis.android.action.START_WAKE_WORD"
        const val ACTION_STOP = "com.jarvis.android.action.STOP_WAKE_WORD"
        const val ACTION_ENROLL_OWNER_VOICE = "com.jarvis.android.action.ENROLL_OWNER_VOICE"
        const val PREFS = "jarvis_wake_word"
        const val KEY_ENABLED = "enabled"
        private const val TAG = "JarvisWakeWord"
        private const val CHANNEL_ID = "jarvis_wake_word"
        private const val NOTIFICATION_ID = 54120
        private const val COMMAND_WINDOW_MS = 10_000L
    }
}
