package com.jarvis.android

import org.json.JSONObject
import kotlin.math.sqrt

/**
 * Local speaker-vector helper backed by Vosk's optional speaker model.
 * This is a convenience voice-match signal, not cryptographic or liveness-secure identity proof.
 */
object OwnerVoiceProfile {
    fun vectorFromRecognizerJson(rawJson: String): List<Double>? = runCatching {
        val array = JSONObject(rawJson).optJSONArray("spk") ?: return null
        if (array.length() !in 16..512) return null
        val vector = (0 until array.length()).map { index -> array.optDouble(index, Double.NaN) }
        if (vector.any { !it.isFinite() }) return null
        normalize(vector)
    }.getOrNull()

    fun centroid(vectors: List<List<Double>>): List<Double>? {
        if (vectors.size < 3) return null
        val dimensions = vectors.firstOrNull()?.size ?: return null
        if (dimensions !in 16..512 || vectors.any { it.size != dimensions }) return null
        val mean = (0 until dimensions).map { index -> vectors.map { it[index] }.average() }
        return normalize(mean)
    }

    /** Cosine similarity of normalized speaker vectors, in [-1, 1]. */
    fun similarity(first: List<Double>, second: List<Double>): Double {
        if (first.isEmpty() || first.size != second.size) return -1.0
        val dot = first.indices.sumOf { first[it] * second[it] }
        val firstNorm = sqrt(first.sumOf { it * it })
        val secondNorm = sqrt(second.sumOf { it * it })
        if (firstNorm <= 1e-9 || secondNorm <= 1e-9) return -1.0
        return (dot / (firstNorm * secondNorm)).coerceIn(-1.0, 1.0)
    }

    /** Initial conservative convenience threshold; it must be checked on the target phone. */
    fun likelySameSpeaker(sample: List<Double>, enrolled: List<Double>, threshold: Double = 0.72): Boolean =
        similarity(sample, enrolled) >= threshold

    private fun normalize(values: List<Double>): List<Double>? {
        val norm = sqrt(values.sumOf { it * it })
        if (!norm.isFinite() || norm <= 1e-9) return null
        return values.map { it / norm }
    }
}
