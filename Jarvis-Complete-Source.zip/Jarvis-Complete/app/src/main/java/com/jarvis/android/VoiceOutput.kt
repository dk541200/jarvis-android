package com.jarvis.android

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/** On-device Android TTS. Voice quality follows the installed system speech engine/voice packs. */
class VoiceOutput(context: Context) : TextToSpeech.OnInitListener {
    private val appContext = context.applicationContext
    @Volatile private var ready = false
    @Volatile private var latestSettings = JarvisSettings()
    private val tts = TextToSpeech(appContext, this)

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) applySettings()
    }

    fun update(settings: JarvisSettings) {
        latestSettings = settings
        if (ready) applySettings()
    }

    private fun applySettings() {
        val target = Locale.forLanguageTag(latestSettings.voiceLanguage)
        val result = tts.setLanguage(target)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale("en", "IN"))
        }
        tts.setSpeechRate(latestSettings.speechRate.coerceIn(0.75f, 1.2f))
        tts.setPitch(latestSettings.speechPitch.coerceIn(0.8f, 1.2f))
        // Prefer a good locally available voice for the requested language when installed.
        val candidates: List<Voice> = tts.voices?.filter { voice ->
            voice.locale.language == target.language && !voice.isNetworkConnectionRequired
        }.orEmpty()
        candidates.maxByOrNull { it.quality }?.let { runCatching { tts.voice = it } }
    }

    fun speak(raw: String) {
        if (!ready || !latestSettings.speakReplies) return
        val spoken = cleanAssistantOutput(raw)
            .replace(Regex("https?://\\S+"), "")
            .replace(Regex("[`*_>#]"), "")
            .replace(Regex("\\n{2,}"), ". ")
            .take(4_000)
        if (spoken.isNotBlank()) tts.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.currentTimeMillis()}")
    }

    fun stop() { if (ready) tts.stop() }
    fun shutdown() { runCatching { tts.stop(); tts.shutdown() }; ready = false }
}
