package com.jarvis.android

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import java.util.Locale

/** Small, deterministic phone actions. Sensitive actions are never silently executed. */
class LocalActions(private val context: Context, private val store: SecureStore) {
    fun tryRun(raw: String): String? {
        val query = raw.trim()
        val lower = query.lowercase(Locale.ROOT)

        val remember = Regex("^(?:jarvis[, ]+)?remember(?: this)?[: ]+(.+)$", RegexOption.IGNORE_CASE).find(query)
        if (remember != null) {
            val fact = remember.groupValues[1].trim()
            store.addMemory(fact)
            return "Theek hai, maine ye baat is phone par encrypted memory mein save kar di: “$fact”"
        }
        if (lower in setOf("forget memory", "clear memory", "meri memory bhool ja", "sab memory delete kar", "forget everything")) {
            store.clearMemories()
            return "Saved memories cleared. Chat history abhi alag saved hai; use bhi Settings mein clear kar sakte ho."
        }
        if (lower in setOf("show memory", "what do you remember", "meri memory dikha")) {
            val memories = store.memories()
            return if (memories.isEmpty()) "Abhi koi saved memory nahi hai." else "Saved memories:\n" + memories.joinToString("\n") { "• $it" }
        }

        val appName = Regex("^(?:jarvis[, ]+)?(?:open|launch|kholo|chalao)\\s+(.+)$", RegexOption.IGNORE_CASE).find(query)?.groupValues?.get(1)?.trim()?.lowercase(Locale.ROOT)
        if (appName != null) {
            val packageNames = when (appName) {
                "instagram", "insta", "ig" -> listOf("com.instagram.android")
                "whatsapp", "what", "wa" -> listOf("com.whatsapp")
                "youtube", "yt" -> listOf("com.google.android.youtube", "com.google.android.apps.youtube.music")
                "telegram", "tg" -> listOf("org.telegram.messenger", "org.thunderdog.challegram")
                "settings", "phone settings" -> emptyList()
                "browser", "chrome", "internet" -> listOf("com.android.chrome")
                else -> emptyList()
            }
            if (appName in setOf("settings", "phone settings")) {
                context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return "Phone Settings khol diya."
            }
            for (packageName in packageNames) {
                val launch = context.packageManager.getLaunchIntentForPackage(packageName)
                if (launch != null) {
                    context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return "$appName open kar diya."
                }
            }
            if (packageNames.isNotEmpty()) return "$appName phone par installed nahi mila. App install karke phir try karo."
        }

        val timer = Regex("^(?:set )?(?:a )?timer (?:for )?(\\d+)\\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)$", RegexOption.IGNORE_CASE).find(query)
        if (timer != null) {
            val amount = timer.groupValues[1].toIntOrNull() ?: return null
            val unit = timer.groupValues[2].lowercase(Locale.ROOT)
            val seconds = when {
                unit.startsWith("hour") || unit.startsWith("hr") -> amount * 3600
                unit.startsWith("min") -> amount * 60
                else -> amount
            }.coerceAtMost(24 * 3600)
            val intent = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis timer")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return try { context.startActivity(intent); "Timer screen khol diya—start karne se pehle time check kar lena." }
            catch (_: Exception) { "Is phone par timer app available nahi mila." }
        }

        val dial = Regex("^(?:call|dial|phone)\\s+([+0-9][+0-9() -]{4,})$", RegexOption.IGNORE_CASE).find(query)
        if (dial != null) {
            val number = dial.groupValues[1].trim()
            context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Dialer khol diya hai. Call karne se pehle number verify karke khud call button dabana."
        }

        // Never send messages, spend money, delete external files, or make calls without user interaction.
        if (lower.startsWith("send message") || lower.startsWith("send whatsapp") || lower.startsWith("pay ") || lower.startsWith("transfer money")) {
            return "Main message/payment khud se send nahi karunga. Main draft ya relevant app kholne mein help kar sakta hoon; final send/payment tum khud verify karke karna."
        }
        return null
    }
}
