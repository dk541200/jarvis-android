package com.jarvis.android

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import java.util.Locale

/** Deterministic on-device actions. External/sensitive operations are never silently confirmed. */
class LocalActions(private val context: Context, private val store: SecureStore) {
    fun tryRun(raw: String): String? {
        val command = raw.trim()
            .replace(Regex("(?i)^\\s*(?:hey\\s+jarvis|jarvis)[, ]*"), "")
            .replace(Regex("^\\s*(?:हे\\s*जार्विस|हे\\s*जर्विस|जार्विस|जर्विस)[, ]*"), "")
            // Hindi speech-recognition variants for common command words and installed apps.
            .replace("यूट्यूब", "youtube").replace("युट्यूब", "youtube")
            .replace("इंस्टाग्राम", "instagram").replace("व्हाट्सएप", "whatsapp")
            .replace("स्पॉटिफाई", "spotify").replace("स्पॉटिफ़ाई", "spotify")
            .replace("डिस्कॉर्ड", "discord").replace("टेलीग्राम", "telegram")
            .replace("क्रोम", "chrome").replace("सेटिंग्स", "settings").replace("सेटिंग", "settings")
            .replace("ओपन", "open").replace("लॉन्च", "launch").replace("प्ले", "play").replace("सर्च", "search")
            .replace("और", " aur ").replace("गाना", "gaana")
            .replace("खोलो", "kholo").replace("खोलना", "kholna").replace("खोल दो", "khol do")
            .replace("कर दो", "kar do").replace("करो", "karo").replace("करना", "karna")
            .replace("पर", "par").replace("पे", "pe").replace("में", "mein")
            .replace("रोक दो", "rok do").replace("बंद करो", "band karo")
            .replace("चलाओ", "chalao").replace("बजाओ", "bajao")
            .trim()
        if (command.isBlank()) return null
        val lower = command.lowercase(Locale.ROOT)

        if (AgentCoordinator.isLockScreenCommand(command)) {
            return accessibilityAction("lock_screen", "Phone lock action")
        }
        if (AgentCoordinator.isUnlockScreenCommand(command)) {
            return "Phone ko voice se secure lock bypass karke unlock nahi kar sakta. Android ka normal PIN, pattern ya system biometric use karo."
        }
        if (AgentCoordinator.isCancelMessageCommand(command)) {
            return if (JarvisAccessibilityService.cancelPendingMessage()) "Message draft cancel kar diya. Koi message send nahi hua." else "Koi active Jarvis message draft nahi mila."
        }
        if (AgentCoordinator.isConfirmSendCommand(command)) {
            return if (JarvisAccessibilityService.confirmPendingMessageSend()) {
                "Send button tap kiya. Instagram/WhatsApp mein status check kar lo; Jarvis app ke bahar delivery guarantee nahi kar sakta."
            } else {
                "Abhi koi verified message draft ready nahi hai. Pehle recipient choose karke message draft verify karo."
            }
        }
        AgentCoordinator.parseMessageTask(raw, JarvisAccessibilityService.foregroundPackageName())?.let { task ->
            if (!JarvisAccessibilityService.queueMessageTask(task)) {
                return "Message agent ke liye Jarvis Accessibility Service enable karo. Uske baad command dobara bolo. Message abhi send nahi hua."
            }
            return try {
                val deepLink = when (task.packageName) {
                    "com.instagram.android" -> Intent(Intent.ACTION_VIEW, Uri.parse("instagram://direct/new")).setPackage(task.packageName)
                    else -> null
                }
                val launch = deepLink?.takeIf { context.packageManager.resolveActivity(it, 0) != null }
                    ?: context.packageManager.getLaunchIntentForPackage(task.packageName)
                    ?: return "${task.appLabel} installed nahi hai. Message send nahi hua."
                context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "${task.appLabel} message agent start kar diya: ${task.recipient} ko ‘${task.body}’. Jarvis recipient search/draft mein help karega. Bhejne se pehle ‘Jarvis confirm send’ bolo; pehle screen par recipient aur message check karna."
            } catch (_: Exception) {
                JarvisAccessibilityService.cancelPendingMessage()
                "${task.appLabel} khol nahi paaya. Message send nahi hua."
            }
        }

        val remember = Regex("^remember(?: this)?[: ]+(.+)$", RegexOption.IGNORE_CASE).find(command)
        if (remember != null) {
            val fact = remember.groupValues[1].trim()
            store.addMemory(fact)
            return "Theek hai, maine ye baat is phone par encrypted memory mein save kar di: “$fact”"
        }
        if (lower in setOf("forget memory", "clear memory", "meri memory bhool ja", "sab memory delete kar", "forget everything")) {
            store.clearMemories()
            return "Saved memories cleared. Chat history abhi alag saved hai; use bhi Settings mein clear kar sakte ho."
        }
        if (lower in setOf("show memory", "what do you remember", "meri memory dikha")) {
            val memories = store.memories()
            return if (memories.isEmpty()) "Abhi koi saved memory nahi hai." else "Saved memories:\n" + memories.joinToString("\n") { "• $it" }
        }

        // Media queries are handled before app-launch commands so a compound request such as
        // "Hey Jarvis, YouTube kholo aur Tu Hai Kahan song play karo" opens the song search.
        extractSongQuery(command)?.let { (song, platform) ->
            return openMusicSearch(song, platform)
        }

        when (lower) {
            "go back", "back", "wapas ja", "peeche ja" ->
                return accessibilityAction("back", "Back action")
            "go home", "home screen", "phone home", "home par ja" ->
                return accessibilityAction("home", "Home screen action")
            "scroll down", "neeche scroll karo", "neeche karo" ->
                return accessibilityAction("scroll_down", "Scroll down")
            "scroll up", "upar scroll karo", "upar karo" ->
                return accessibilityAction("scroll_up", "Scroll up")
            "pause", "pause video", "pause music", "music pause karo", "gaana rok do", "music stop", "stop music", "band karo" ->
                return accessibilityAction("media_pause", "Media pause")
            "resume", "resume video", "resume music", "play", "play music", "music chalao", "gaana chalao", "gaana bajao", "music bajao" ->
                return accessibilityAction("media_play", "Media play")
            "open accessibility", "accessibility settings", "accessibility on karo" -> {
                return try {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Accessibility Settings khol di. Jarvis ko sirf tab enable karna jab tum screen-control features use karna chahte ho."
                } catch (_: Exception) { "Accessibility Settings nahi khul paayi." }
            }
        }

        // Handle both English and Hinglish orderings, with polite endings from speech-to-text:
        // "open Instagram", "Instagram kholo", "YouTube open karo", "Chrome khol do please".
        val appName = Regex("^(?:(?:please|hey jarvis)\\s+)*(?:open|launch|start|khol|kholo|chalao)\\s+(.+?)(?:\\s+(?:please|now|karo|kar do|khol do))?$", RegexOption.IGNORE_CASE)
            .find(command)?.groupValues?.get(1)?.trim()?.trimEnd('.', ',', '!', '?')
            ?: Regex("^(.+?)\\s+(?:open|launch|start|khol|kholo|khol do|chalao)(?:\\s+(?:please|karo|kar do|khol do))?$", RegexOption.IGNORE_CASE)
                .find(command)?.groupValues?.get(1)?.trim()?.trimEnd('.', ',', '!', '?')
        if (appName != null) return launchApp(appName)

        val timer = Regex("^(?:set )?(?:a )?timer (?:for )?(\\d+)\\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)$", RegexOption.IGNORE_CASE).find(command)
        if (timer != null) {
            val amount = timer.groupValues[1].toIntOrNull() ?: return null
            val unit = timer.groupValues[2].lowercase(Locale.ROOT)
            val seconds = when {
                unit.startsWith("hour") || unit.startsWith("hr") -> amount * 3600
                unit.startsWith("min") -> amount * 60
                else -> amount
            }.coerceAtMost(24 * 3600)
            val intent = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis timer")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return try { context.startActivity(intent); "Timer screen khol diya—start karne se pehle time check kar lena." }
            catch (_: Exception) { "Is phone par timer app available nahi mila." }
        }

        val dial = Regex("^(?:call|dial|phone)\\s+([+0-9][+0-9() -]{4,})$", RegexOption.IGNORE_CASE).find(command)
        if (dial != null) {
            val number = dial.groupValues[1].trim()
            return try {
                context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Dialer khol diya hai. Call karne se pehle number verify karke khud call button dabana."
            } catch (_: Exception) { "Dialer nahi khul paaya." }
        }

        // Never send messages, spend money, delete external files, or make calls without interaction.
        if (lower.startsWith("send message") || lower.startsWith("send whatsapp") || lower.startsWith("pay ") || lower.startsWith("transfer money")) {
            return "Main message/payment khud se send nahi karunga. Main draft ya relevant app kholne mein help kar sakta hoon; final send/payment tum khud verify karke karna."
        }
        return null
    }

    private fun launchApp(rawName: String): String {
        val appName = rawName
            .replace(Regex("(?i)\\s+(app|application)$"), "")
            .trim()
        val name = normalize(appName)
        if (name.isBlank()) return "Kaunsi app kholni hai? App ka naam bolo."

        val specialPackageNames = when (name) {
            "ig", "insta", "instagram" -> listOf("com.instagram.android")
            "what", "wa", "whatsapp" -> listOf("com.whatsapp")
            "yt", "youtube" -> listOf("com.google.android.youtube", "com.google.android.apps.youtube.music")
            "telegram", "tg" -> listOf("org.telegram.messenger", "org.thunderdog.challegram")
            "spotify", "spoti" -> listOf("com.spotify.music")
            "discord", "dc", "discoard", "discoord" -> listOf("com.discord")
            "gemini", "gmini", "gminy", "googlegemini", "bard" -> listOf("com.google.android.apps.bard")
            "bgmi", "bgmii", "battlegroundsmobileindia", "battlegrounds" -> listOf("com.pubg.imobile")
            "freefiremax", "ffmax" -> listOf("com.dts.freefiremax")
            "freefire", "ff" -> listOf("com.dts.freefireth")
            "chrome", "crome", "googlechrome", "browser", "internet" -> listOf("com.android.chrome", "com.google.android.googlequicksearchbox")
            "settings", "phonesettings", "setting" -> emptyList()
            else -> emptyList()
        }

        if (name in setOf("settings", "phonesettings", "setting")) {
            return try {
                context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Phone Settings khol di."
            } catch (_: Exception) { "Phone Settings nahi khul paayi." }
        }

        for (packageName in specialPackageNames) {
            val launch = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) {
                return try {
                    context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "${appName} open kar di."
                } catch (_: Exception) { "${appName} kholne mein problem aayi." }
            }
        }

        val allLaunchableApps = queryLaunchableApps()
        val exact = allLaunchableApps.firstOrNull { normalize(it.label) == name || normalize(it.packageName.substringAfterLast('.')) == name }
        val match = exact ?: allLaunchableApps.firstOrNull { normalize(it.label).startsWith(name) && name.length >= 3 }
            ?: allLaunchableApps.firstOrNull { name.length >= 3 && normalize(it.label).contains(name) }
        if (match != null) {
            val launch = context.packageManager.getLaunchIntentForPackage(match.packageName)
            if (launch != null) {
                return try {
                    context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "${match.label} open kar di."
                } catch (_: Exception) { "${match.label} kholne mein problem aayi." }
            }
        }
        return "Phone mein '$appName' naam ki launchable app nahi mili. App ka exact naam bolkar phir try karo."
    }

    private data class LaunchableApp(val label: String, val packageName: String)

    @Suppress("DEPRECATION")
    private fun queryLaunchableApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return runCatching {
            context.packageManager.queryIntentActivities(intent, 0)
                .mapNotNull { info ->
                    val activity = info.activityInfo ?: return@mapNotNull null
                    if (activity.packageName == context.packageName) return@mapNotNull null
                    val label = info.loadLabel(context.packageManager)?.toString()?.trim().orEmpty()
                    if (label.isBlank()) null else LaunchableApp(label, activity.packageName)
                }
                .distinctBy { it.packageName }
        }.getOrDefault(emptyList())
    }

    private fun extractSongQuery(raw: String): Pair<String, String>? {
        val original = raw.trim()
        val lower = original.lowercase(Locale.ROOT)
        val platform = if (Regex("\\bspotify\\b|\\bspoti\\b", RegexOption.IGNORE_CASE).containsMatchIn(original)) "spotify" else "youtube"
        val hasMediaIntent = Regex("(?i)\\b(play|chalao|bajao|search|find|song|gaana|track|music)\\b").containsMatchIn(original)
        if (!hasMediaIntent) return null

        // If the user says "open YouTube aur Tu Hai Kahan song play karo", parse the
        // final media clause, not the app-launch clause. This stays deterministic and fast.
        val segments = Regex("(?i)\\s+(?:and|aur|our|phir|then)\\s+")
            .split(original).filter { part ->
                Regex("(?i)\\b(play|chalao|bajao|search|find|song|gaana|track)\\b").containsMatchIn(part)
            }
        val candidates = (segments.asReversed() + original).distinct()
        val patterns = listOf(
            // Direct compound form: "open YouTube play Tu Hai Kahan" (no "and/aur" required).
            Regex("(?i)^(?:please\\s+)?(?:open|launch|start)\\s+(?:youtube|yt|spotify)\\s+(?:(?:and|aur|our|then)\\s+)?(?:play|chalao|bajao|search|find)\\s+(?:the\\s+)?(?:(?:song|gaana|track)\\s+)?(.+?)$"),
            // Check platform-prefixed commands first so "YouTube par ... song play karo"
            // does not mistakenly include the word "YouTube par" in the song title.
            Regex("(?i)^(?:youtube|yt|spotify)\\s+(?:par|pe|mein|me)\\s+(.+?)\\s+(?:play|chalao|bajao)(?:\\s+(?:karo|kar do))?$"),
            // "Tu Hai Kahan song play karo" / "Tu Hai Kahan gaana bajao"
            Regex("(?i)^(.+?)\\s+(?:song|gaana|track)\\s+(?:play|chalao|bajao)(?:\\s+(?:karo|kar do))?$"),
            // "play the song Tu Hai Kahan", "play Tu Hai Kahan song on YouTube"
            Regex("(?i)^(?:please\\s+)?(?:play|chalao|bajao|search|find)\\s+(?:the\\s+)?(?:(?:song|gaana|track)\\s+)?(.+?)$"),
            // "Tu Hai Kahan on YouTube" or "play ... on Spotify"
            Regex("(?i)^(.+?)\\s+(?:on|in|par|pe)\\s+(?:youtube|yt|spotify)$"),
            // "Tu Hai Kahan play karo" (including the compound request's final clause)
            Regex("(?i)^(.+?)\\s+(?:play|chalao|bajao)(?:\\s+(?:karo|kar do))?$")
        )

        for (candidate in candidates) {
            val title = patterns.firstNotNullOfOrNull { pattern ->
                pattern.find(candidate.trim())?.groupValues?.get(1)
            } ?: continue
            var cleaned = title
            cleaned = cleaned.replace(Regex("(?i)^\\s*(?:hey\\s+jarvis|jarvis)[, ]*"), " ")
            cleaned = cleaned.replace(Regex("(?i)^\\s*(?:open|launch|start)\\s+(?:youtube|yt|spotify)\\s+(?:(?:and|aur|our|then)\\s+)?"), " ")
            cleaned = cleaned.replace(Regex("(?i)^\\s*(?:youtube|yt|spotify)\\s+(?:(?:open|launch|start)\\s+)?(?:aur|and|our)?\\s*"), " ")
            cleaned = cleaned.replace(Regex("(?i)^\\s*(?:the\\s+)?(?:song|gaana|track)\\s+"), " ")
            cleaned = cleaned.replace(Regex("(?i)\\s+(?:on|in|par|pe)\\s+(?:youtube|yt|spotify)\\s*$"), " ")
            cleaned = cleaned.replace(Regex("(?i)\\s+(?:song|gaana|track|music)\\s*$"), " ")
            cleaned = cleaned.replace(Regex("(?i)\\s+(?:karo|kar do|please|now)\\s*$"), " ")
            cleaned = cleaned.trim(' ', ',', '.', '!', '?', ':', ';', '"', '\'')
            val normalized = normalize(cleaned)
            if (cleaned.length < 2) continue
            if (normalized in setOf(
                    "music", "song", "gaana", "track", "video", "audio", "youtube", "yt", "spotify",
                    "instagram", "insta", "whatsapp", "telegram", "discord", "chrome", "settings", "setting"
                )) continue
            if (normalized in setOf("openyoutube", "youtubeopen", "openspotify", "spotifyopen")) continue
            // Never turn a plain launch request into a search for a song.
            if (lower.matches(Regex("(?i)^(?:hey\\s+jarvis[, ]*)?(?:open|launch|start|khol|kholo|chalao)\\s+(?:youtube|yt|spotify)$"))) return null
            return cleaned to platform
        }
        return null
    }

    private fun openMusicSearch(song: String, platform: String): String {
        val accessibilityWillTryToSelect = JarvisAccessibilityService.queueMediaResultTap(song, platform)
        return try {
            if (platform == "spotify") {
                val spotifyIntent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(song)}"))
                    .setPackage("com.spotify.music")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val canOpenSpotify = context.packageManager.resolveActivity(spotifyIntent, 0) != null
                if (canOpenSpotify) context.startActivity(spotifyIntent) else {
                    val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/search/${Uri.encode(song)}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(web)
                }
                if (accessibilityWillTryToSelect) "Spotify par '$song' search khol di. Jarvis matching result tap karne ki koshish karega; agar na chale to result par tap karna." else "Spotify par '$song' search khol di. Song start karne ke liye result par tap karo."
            } else {
                val url = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(song)}")
                val appIntent = Intent(Intent.ACTION_VIEW, url).setPackage("com.google.android.youtube")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val youtubeCanOpen = context.packageManager.resolveActivity(appIntent, 0) != null
                if (youtubeCanOpen) context.startActivity(appIntent) else {
                    context.startActivity(Intent(Intent.ACTION_VIEW, url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                if (accessibilityWillTryToSelect) "YouTube par '$song' ke results khol diye. Jarvis matching result select karne ki koshish karega; agar na chale to result par tap karna." else "YouTube par '$song' ke results khol diye. Gaana start karne ke liye result par tap karo."
            }
        } catch (_: Exception) {
            "Song search khol nahi paayi. Check karo ki YouTube/Spotify ya browser installed hai."
        }
    }

    private fun accessibilityAction(action: String, label: String): String {
        val done = JarvisAccessibilityService.performAction(action)
        return if (done) "$label complete." else "Screen control ke liye pehle Settings mein Jarvis Accessibility Service enable karo. App kholna aur YouTube/Spotify search karna is permission ke bina bhi kaam karta hai."
    }

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT).filter(Char::isLetterOrDigit)
}
