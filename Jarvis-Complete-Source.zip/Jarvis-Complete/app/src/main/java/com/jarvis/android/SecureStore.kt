package com.jarvis.android

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** API secrets, settings, chat history and explicit memories remain encrypted on-device. */
class SecureStore(context: Context) {
    private val preferences = EncryptedSharedPreferences.create(
        context,
        "jarvis_private_v2",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    @Synchronized fun settings(): JarvisSettings = runCatching {
        JarvisSettings.fromJson(JSONObject(preferences.getString("settings", "{}") ?: "{}"))
    }.getOrDefault(JarvisSettings())

    @Synchronized fun saveSettings(settings: JarvisSettings) {
        preferences.edit().putString("settings", settings.toJson().toString()).apply()
    }

    @Synchronized fun chat(): List<ChatMessage> = messagesFromJson(preferences.getString("chat", "[]") ?: "[]")

    @Synchronized fun saveChat(messages: List<ChatMessage>) {
        preferences.edit().putString("chat", messagesToJson(messages)).apply()
    }

    @Synchronized fun memories(): List<String> = runCatching {
        val array = JSONArray(preferences.getString("memories", "[]") ?: "[]")
        (0 until array.length()).mapNotNull { array.optString(it).takeIf(String::isNotBlank) }
    }.getOrDefault(emptyList())

    @Synchronized fun addMemory(fact: String) {
        val clean = fact.trim().take(500)
        if (clean.isBlank()) return
        val all = (memories().filterNot { it.equals(clean, true) } + clean).takeLast(50)
        preferences.edit().putString("memories", JSONArray(all).toString()).apply()
    }

    @Synchronized fun removeMemory(fact: String) {
        val all = memories().filterNot { it == fact }
        preferences.edit().putString("memories", JSONArray(all).toString()).apply()
    }

    @Synchronized fun clearMemories() { preferences.edit().remove("memories").apply() }
    @Synchronized fun clearChat() { preferences.edit().remove("chat").apply() }

    fun hasAppPin(): Boolean = !preferences.getString("app_pin_hash", null).isNullOrBlank()

    @Synchronized fun setAppPin(pin: String) {
        require(pin.matches(Regex("[0-9]{6,12}"))) { "PIN must be 6 to 12 digits." }
        val salt = ByteArray(16).also(SecureRandom()::nextBytes)
        val hash = hashPin(pin.toCharArray(), salt)
        preferences.edit()
            .putString("app_pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("app_pin_hash", Base64.encodeToString(hash, Base64.NO_WRAP))
            .apply()
    }

    @Synchronized fun verifyAppPin(pin: String): Boolean = runCatching {
        val salt = Base64.decode(preferences.getString("app_pin_salt", "") ?: "", Base64.NO_WRAP)
        val expected = Base64.decode(preferences.getString("app_pin_hash", "") ?: "", Base64.NO_WRAP)
        val actual = hashPin(pin.toCharArray(), salt)
        java.security.MessageDigest.isEqual(expected, actual)
    }.getOrDefault(false)

    @Synchronized fun removeAppPin() {
        preferences.edit().remove("app_pin_salt").remove("app_pin_hash").apply()
    }

    private fun hashPin(pin: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin, salt, 150_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword(); pin.fill('\u0000') }
    }


    @Synchronized fun exportPayload(): String = JSONObject().apply {
        put("format", "jarvis-backup-v1")
        put("createdAt", System.currentTimeMillis())
        put("settings", settings().toJson())
        put("chat", JSONArray(messagesToJson(chat())))
        put("memories", JSONArray(memories()))
    }.toString(2)

    @Synchronized fun importPayload(raw: String) {
        val obj = JSONObject(raw)
        require(obj.optString("format") == "jarvis-backup-v1") { "This isn't a Jarvis backup." }
        obj.optJSONObject("settings")?.let { saveSettings(JarvisSettings.fromJson(it)) }
        obj.optJSONArray("chat")?.let { arr ->
            val list = (0 until arr.length()).mapNotNull { i ->
                runCatching { ChatMessage.fromJson(arr.getJSONObject(i)) }.getOrNull()
            }
            saveChat(list)
        }
        obj.optJSONArray("memories")?.let { arr ->
            val list = (0 until arr.length()).mapNotNull { i -> arr.optString(i).takeIf(String::isNotBlank) }.takeLast(50)
            preferences.edit().putString("memories", JSONArray(list).toString()).apply()
        }
    }
}
