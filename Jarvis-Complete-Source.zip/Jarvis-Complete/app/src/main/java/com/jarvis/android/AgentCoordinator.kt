package com.jarvis.android

import java.util.Locale

/**
 * Deterministic coordinator for commands that must not wait for the language model.
 * This is the routing layer, not an LLM-driven autonomous agent. It intentionally
 * requires explicit user confirmation before an external message is sent.
 */
object AgentCoordinator {
    data class MessageTask(
        val appLabel: String,
        val packageName: String,
        val recipient: String,
        val body: String
    )

    private data class AppTarget(val label: String, val packageName: String)

    private val appTargets = mapOf(
        "instagram" to AppTarget("Instagram", "com.instagram.android"),
        "insta" to AppTarget("Instagram", "com.instagram.android"),
        "ig" to AppTarget("Instagram", "com.instagram.android"),
        "whatsapp" to AppTarget("WhatsApp", "com.whatsapp"),
        "wa" to AppTarget("WhatsApp", "com.whatsapp"),
        "telegram" to AppTarget("Telegram", "org.telegram.messenger"),
        "tg" to AppTarget("Telegram", "org.telegram.messenger"),
        "discord" to AppTarget("Discord", "com.discord"),
        "dc" to AppTarget("Discord", "com.discord")
    )

    /** Parses e.g. "Instagram par Faizan ko hi bhej do" or "Faizan ko hi bhej do". */
    fun parseMessageTask(raw: String, foregroundPackage: String? = null): MessageTask? {
        val command = normalizeCommand(raw)
        if (command.isBlank()) return null
        val pattern = Regex(
            "^(?:(instagram|insta|ig|whatsapp|wa|telegram|tg|discord|dc)\\s+(?:par|pe|mein|me)\\s+)?" +
                "(.+?)\\s+ko\\s+(.+?)\\s+(?:message\\s+)?(?:bhej\\s+do|bhej\\s+dena|bhejo|send(?:\\s+kar(?:\\s+do)?)?|msg\\s+kar\\s+do)$",
            RegexOption.IGNORE_CASE
        )
        val match = pattern.find(command) ?: return null
        val explicitApp = match.groupValues[1].lowercase(Locale.ROOT).takeIf(String::isNotBlank)
        val recipient = match.groupValues[2].trim().trim('"', '\'', ',', '.', '!')
        val body = match.groupValues[3].trim()
            .replace(Regex("(?i)\\s+(?:a\\s+)?message$"), "")
            .trim(' ', '"', '\'', ',', '.', '!')
        if (recipient.length !in 2..80 || body.length !in 1..1_000) return null
        val target = explicitApp?.let(appTargets::get) ?: targetForPackage(foregroundPackage) ?: return null
        return MessageTask(target.label, target.packageName, recipient, body)
    }

    fun isConfirmSendCommand(raw: String): Boolean {
        val command = normalizeCommand(raw).lowercase(Locale.ROOT)
        return command in setOf(
            "confirm send", "confirm send message", "send it", "send now", "haan bhej do",
            "ha bhej do", "haan send karo", "yes send", "yes send it", "message send kar do",
            "ab bhej do", "confirm message"
        )
    }

    fun isLockScreenCommand(raw: String): Boolean {
        val command = normalizeCommand(raw).lowercase(Locale.ROOT)
        return command in setOf(
            "lock phone", "phone lock karo", "phone lock kar do", "screen lock karo",
            "lock my phone", "lock screen", "phone band lock karo", "mobile lock karo",
            "mobile lock kar do", "phone ko lock karo"
        )
    }

    fun isCancelMessageCommand(raw: String): Boolean {
        val command = normalizeCommand(raw).lowercase(Locale.ROOT)
        return command in setOf("cancel message", "cancel draft", "message cancel karo", "draft cancel karo", "mat bhejo", "cancel send")
    }

    fun isUnlockScreenCommand(raw: String): Boolean {
        val command = normalizeCommand(raw).lowercase(Locale.ROOT)
        return command in setOf(
            "unlock phone", "phone unlock karo", "phone unlock kar do", "mobile unlock karo",
            "mobile unlock kar do", "unlock my phone", "screen unlock karo", "phone khol do"
        )
    }

    private fun targetForPackage(packageName: String?): AppTarget? = when (packageName) {
        "com.instagram.android" -> appTargets.getValue("instagram")
        "com.whatsapp" -> appTargets.getValue("whatsapp")
        "org.telegram.messenger", "org.thunderdog.challegram" -> appTargets.getValue("telegram")
        "com.discord" -> appTargets.getValue("discord")
        else -> null
    }

    private fun normalizeCommand(raw: String): String = raw.trim()
        .replace(Regex("(?i)^\\s*(?:hey\\s+jarvis|jarvis)[, ]*"), "")
        .replace(Regex("^\\s*(?:हे\\s*जार्विस|हे\\s*जर्विस|जार्विस|जर्विस)[, ]*"), "")
        .replace("इंस्टाग्राम", "instagram")
        .replace("व्हाट्सएप", "whatsapp")
        .replace("टेलीग्राम", "telegram")
        .replace("डिस्कॉर्ड", "discord")
        .replace("पर", "par").replace("पे", "pe").replace("में", "mein")
        .replace("भेज दो", "bhej do").replace("भेज देना", "bhej dena").replace("भेजो", "bhejo")
        .replace("मैसेज", "message").replace("संदेश", "message")
        .replace("कर दो", "kar do").replace("करो", "karo")
        .replace(Regex("\\s+"), " ")
        .trim()
}
