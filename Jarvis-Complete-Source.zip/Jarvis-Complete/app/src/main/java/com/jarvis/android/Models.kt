package com.jarvis.android

import org.json.JSONArray
import org.json.JSONObject

enum class RouterMode { AUTO, LOCAL_ONLY, ONLINE_FIRST }

data class JarvisSettings(
    val localEndpoint: String = "http://127.0.0.1:8080/v1/chat/completions",
    val localModel: String = "Qwen3-1.7B-Q4_K_M",
    val useBundledModel: Boolean = true,
    val onlineEndpoint: String = "",
    val onlineModel: String = "",
    val apiKey: String = "",
    val routerMode: RouterMode = RouterMode.AUTO,
    val autoWebSearch: Boolean = true,
    val speakReplies: Boolean = true,
    val voiceLanguage: String = "hi-IN",
    val speechRate: Float = 0.96f,
    val speechPitch: Float = 1.02f
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("localEndpoint", localEndpoint)
        put("localModel", localModel)
        put("useBundledModel", useBundledModel)
        put("onlineEndpoint", onlineEndpoint)
        put("onlineModel", onlineModel)
        put("apiKey", apiKey)
        put("routerMode", routerMode.name)
        put("autoWebSearch", autoWebSearch)
        put("speakReplies", speakReplies)
        put("voiceLanguage", voiceLanguage)
        put("speechRate", speechRate.toDouble())
        put("speechPitch", speechPitch.toDouble())
    }

    companion object {
        fun fromJson(json: JSONObject): JarvisSettings = JarvisSettings(
            localEndpoint = json.optString("localEndpoint", "http://127.0.0.1:8080/v1/chat/completions"),
            localModel = json.optString("localModel", "Qwen3-1.7B-Q4_K_M"),
            useBundledModel = json.optBoolean("useBundledModel", true),
            onlineEndpoint = json.optString("onlineEndpoint", ""),
            onlineModel = json.optString("onlineModel", ""),
            apiKey = json.optString("apiKey", ""),
            routerMode = runCatching { RouterMode.valueOf(json.optString("routerMode", "AUTO")) }.getOrDefault(RouterMode.AUTO),
            autoWebSearch = json.optBoolean("autoWebSearch", true),
            speakReplies = json.optBoolean("speakReplies", true),
            voiceLanguage = json.optString("voiceLanguage", "hi-IN"),
            speechRate = json.optDouble("speechRate", 0.96).toFloat().coerceIn(0.75f, 1.2f),
            speechPitch = json.optDouble("speechPitch", 1.02).toFloat().coerceIn(0.8f, 1.2f)
        )
    }
}

data class ChatMessage(
    val id: Long = System.nanoTime(),
    val role: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("role", role); put("content", content); put("timestamp", timestamp)
    }
    companion object {
        fun fromJson(json: JSONObject) = ChatMessage(
            id = json.optLong("id", System.nanoTime()),
            role = json.optString("role", "assistant"),
            content = json.optString("content", ""),
            timestamp = json.optLong("timestamp", System.currentTimeMillis())
        )
    }
}

data class SearchHit(val title: String, val snippet: String, val url: String)

data class EngineReply(
    val text: String,
    val route: String,
    val sources: List<SearchHit> = emptyList(),
    val needsSetup: Boolean = false
)

internal fun messagesToJson(messages: List<ChatMessage>): String = JSONArray().apply {
    messages.takeLast(60).forEach { put(it.toJson()) }
}.toString()

internal fun messagesFromJson(raw: String): List<ChatMessage> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).mapNotNull { i -> runCatching { ChatMessage.fromJson(array.getJSONObject(i)) }.getOrNull() }
}.getOrDefault(emptyList())
