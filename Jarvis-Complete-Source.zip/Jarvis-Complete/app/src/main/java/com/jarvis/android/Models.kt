package com.jarvis.android

import org.json.JSONArray
import org.json.JSONObject

enum class RouterMode { AUTO, LOCAL_ONLY, ONLINE_FIRST }

data class JarvisSettings(
    val localEndpoint: String = "http://127.0.0.1:8080/v1/chat/completions",
    val localModel: String = "Qwen3-0.6B-Q4_K_M",
    val useBundledModel: Boolean = true,
    val onlineEndpoint: String = "",
    val onlineModel: String = "",
    val apiKey: String = "",
    val routerMode: RouterMode = RouterMode.AUTO,
    val autoWebSearch: Boolean = true,
    val speakReplies: Boolean = true,
    val voiceLanguage: String = "hi-IN",
    val speechRate: Float = 0.96f,
    val speechPitch: Float = 1.02f
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("localEndpoint", localEndpoint)
        put("localModel", localModel)
        put("useBundledModel", useBundledModel)
        put("onlineEndpoint", onlineEndpoint)
        put("onlineModel", onlineModel)
        put("apiKey", apiKey)
        put("routerMode", routerMode.name)
        put("autoWebSearch", autoWebSearch)
        put("speakReplies", speakReplies)
        put("voiceLanguage", voiceLanguage)
        put("speechRate", speechRate.toDouble())
        put("speechPitch", speechPitch.toDouble())
    }

    companion object {
        fun fromJson(json: JSONObject): JarvisSettings = JarvisSettings(
            localEndpoint = json.optString("localEndpoint", "http://127.0.0.1:8080/v1/chat/completions"),
            localModel = json.optString("localModel", "Qwen3-0.6B-Q4_K_M"),
            useBundledModel = json.optBoolean("useBundledModel", true),
            onlineEndpoint = json.optString("onlineEndpoint", ""),
            onlineModel = json.optString("onlineModel", ""),
            apiKey = json.optString("apiKey", ""),
            routerMode = runCatching { RouterMode.valueOf(json.optString("routerMode", "AUTO")) }.getOrDefault(RouterMode.AUTO),
            autoWebSearch = json.optBoolean("autoWebSearch", true),
            speakReplies = json.optBoolean("speakReplies", true),
            voiceLanguage = json.optString("voiceLanguage", "hi-IN"),
            speechRate = json.optDouble("speechRate", 0.96).toFloat().coerceIn(0.75f, 1.2f),
            speechPitch = json.optDouble("speechPitch", 1.02).toFloat().coerceIn(0.8f, 1.2f)
        )
    }
}

data class ChatMessage(
    val id: Long = System.nanoTime(),
    val role: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("role", role); put("content", content); put("timestamp", timestamp)
    }
    companion object {
        fun fromJson(json: JSONObject) = ChatMessage(
            id = json.optLong("id", System.nanoTime()),
            role = json.optString("role", "assistant"),
            content = json.optString("content", ""),
            timestamp = json.optLong("timestamp", System.currentTimeMillis())
        )
    }
}

data class SearchHit(val title: String, val snippet: String, val url: String)

data class EngineReply(
    val text: String,
    val route: String,
    val sources: List<SearchHit> = emptyList(),
    val needsSetup: Boolean = false
)

internal fun messagesToJson(messages: List<ChatMessage>): String = JSONArray().apply {
    messages.takeLast(60).forEach { put(it.toJson()) }
}.toString()

internal fun messagesFromJson(raw: String): List<ChatMessage> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).mapNotNull { i -> runCatching { ChatMessage.fromJson(array.getJSONObject(i)) }.getOrNull() }
}.getOrDefault(emptyList())

/** Removes common reasoning/control markers accidentally emitted by some local models. */
internal fun cleanAssistantOutput(raw: String): String {
    var text = raw.replace("\r\n", "\n")
    // Never display or speak a model's <think> section. If a partial stream has not
    // closed the section yet, keep it hidden until the final answer begins.
    text = text.replace(Regex("(?is)<think>.*?</think>"), " ")
    text = text.replace(Regex("(?is)<think>.*$"), " ")
    text = text.replace(Regex("(?i)</?think>"), " ")
    text = text.replace(Regex("(?i)<\\|(?:im_start|im_end|fim_prefix|fim_middle|fim_suffix|endoftext)\\|>"), " ")
    text = text.replace(Regex("(?im)^\\s*\\*{0,2}think\\*{0,2}\\s*[:\\-]?\\s*$"), "")
    text = text.replace(Regex("(?im)^\\s*/no_think\\s*$"), "")
    text = text.replace(Regex("\\n{3,}"), "\n\n")
    return text.trim()
}
