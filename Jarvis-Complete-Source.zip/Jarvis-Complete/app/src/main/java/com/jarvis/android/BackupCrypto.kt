package com.jarvis.android

import android.content.ContentResolver
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Password-encrypted backup. The app's Android keystore key is not included in the file. */
object BackupCrypto {
    private val magic = "JARVISBK1".toByteArray(Charsets.US_ASCII)
    private const val SALT_BYTES = 16
    private const val IV_BYTES = 12
    private const val ITERATIONS = 210_000

    fun writeEncrypted(resolver: ContentResolver, uri: Uri, payload: String, password: CharArray) {
        require(password.size >= 8) { "Use a backup password with at least 8 characters." }
        val salt = ByteArray(SALT_BYTES).also(SecureRandom()::nextBytes)
        val iv = ByteArray(IV_BYTES).also(SecureRandom()::nextBytes)
        val key = deriveKey(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        cipher.updateAAD(magic)
        val encrypted = cipher.doFinal(payload.toByteArray(Charsets.UTF_8))
        resolver.openOutputStream(uri, "w")?.use { output ->
            output.write(magic); output.write(salt); output.write(iv); output.write(encrypted); output.flush()
        } ?: throw IllegalStateException("Couldn't open backup file for writing.")
    }

    fun readEncrypted(resolver: ContentResolver, uri: Uri, password: CharArray): String {
        val input = resolver.openInputStream(uri) ?: throw IllegalStateException("Couldn't open backup file.")
        val bytes = input.use { it.readAllBytesCompat() }
        val headerSize = magic.size + SALT_BYTES + IV_BYTES
        require(bytes.size > headerSize) { "Backup file is empty or damaged." }
        require(bytes.copyOfRange(0, magic.size).contentEquals(magic)) { "This is not a Jarvis encrypted backup." }
        val salt = bytes.copyOfRange(magic.size, magic.size + SALT_BYTES)
        val iv = bytes.copyOfRange(magic.size + SALT_BYTES, headerSize)
        val encrypted = bytes.copyOfRange(headerSize, bytes.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, deriveKey(password, salt), GCMParameterSpec(128, iv))
        cipher.updateAAD(magic)
        return cipher.doFinal(encrypted).toString(Charsets.UTF_8)
    }

    private fun deriveKey(password: CharArray, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password, salt, ITERATIONS, 256)
        return try {
            SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded, "AES")
        } finally { spec.clearPassword() }
    }

    private fun InputStream.readAllBytesCompat(): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (true) {
            val count = read(buffer)
            if (count < 0) break
            out.write(buffer, 0, count)
            require(out.size() <= 50 * 1024 * 1024) { "Backup is too large (50 MB maximum)." }
        }
        return out.toByteArray()
    }
}
