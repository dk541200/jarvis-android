# Device test checklist

## Build/install
- [ ] Run the GitHub Actions workflow and confirm `assembleDebug` succeeds.
- [ ] Install the generated debug APK on the target Android phone.
- [ ] Open the app and rotate the screen / switch apps without losing chat.

## Local AI
- [ ] Start `llama-server` with a local model and matching alias.
- [ ] In Settings, tap **Test local connection**.
- [ ] Set router to AUTO and send a normal prompt; verify route shows `local`.
- [ ] Stop the local server and confirm the app reports a connection problem or falls back online only when configured.

## Online routing and web
- [ ] Configure a provider endpoint/model/key, then test it.
- [ ] Ask a current-facts question and verify the app performs web search when enabled.
- [ ] Confirm response source URLs open and that API errors don't delete the user message.
- [ ] Set LOCAL ONLY and verify online AI/web search are not attempted.

## Voice and images
- [ ] Grant microphone permission and test Hindi/Hinglish and English input.
- [ ] Confirm recognized speech auto-sends without tapping Send.
- [ ] Confirm on-device model output appears progressively while it generates.
- [ ] Test TTS on a locally installed voice; tune rate/pitch from Settings.
- [ ] Attach a small photo/screenshot and test only with a vision-capable model.
- [ ] Deny microphone permission and confirm text chat still works.

## Memory, lock, backup
- [ ] Save and remove a memory fact; check that it is included in prompts.
- [ ] Set a 6-digit PIN, lock Jarvis, verify correct/incorrect PIN behavior.
- [ ] Export a backup with a strong password and restore it with the correct password.
- [ ] Confirm a wrong backup password does not alter existing data.
- [ ] Clear chat/memory and verify each action affects only its selected data.

## Safety
- [ ] Try a `call` command and confirm it opens the dialler instead of placing the call automatically.
- [ ] Verify the app does not silently send messages or payments.
- [ ] Run at least one offline test with mobile data/Wi-Fi disabled.
