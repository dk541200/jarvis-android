package com.jarvis.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class JarvisService extends Service {
    public static final String ACTION_ON = "com.jarvis.android.action.ON";
    public static final String ACTION_SLEEP = "com.jarvis.android.action.SLEEP";
    public static final String ACTION_OFF = "com.jarvis.android.action.OFF";

    private static final int NOTIFICATION_ID = 1;
    private static final String CHANNEL_ID = "jarvis_core";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private boolean sleeping = true;
    private boolean commandMode = false;
    private boolean listening = false;
    private boolean restarting = false;
    private boolean transitioning = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification("JARVIS SLEEPING"));
        sleeping = true;
        commandMode = false;
        startWakeListener();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_ON : intent.getAction();

        if (ACTION_SLEEP.equals(action)) {
            sleeping = true;
            commandMode = false;
            stopRecognitionOnly();
            updateNotification("JARVIS SLEEPING");
            scheduleStartWake(250);
        } else if (ACTION_OFF.equals(action)) {
            sleeping = true;
            commandMode = false;
            stopWakeListener();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        } else {
            sleeping = false;
            commandMode = false;
            stopRecognitionOnly();
            updateNotification("JARVIS ACTIVE");
            scheduleStartWake(250);
        }
        return START_STICKY;
    }

    private boolean hasMicPermission() {
        return Build.VERSION.SDK_INT < 23 ||
                checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean canRecognize() {
        return hasMicPermission() && SpeechRecognizer.isRecognitionAvailable(this);
    }

    private void startWakeListener() {
        if (commandMode || listening || restarting) return;
        if (!canRecognize()) {
            updateNotification("MICROPHONE / VOICE RECOGNITION NEEDED");
            return;
        }

        createRecognizerIfNeeded();
        startListening(false);
    }

    private void createRecognizerIfNeeded() {
        if (recognizer != null) return;
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { listening = true; }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { listening = false; }

            @Override public void onError(int error) {
                listening = false;
                if (transitioning) {
                    transitioning = false;
                    return;
                }
                if (commandMode) {
                    commandMode = false;
                    updateNotification(sleeping ? "JARVIS SLEEPING" : "JARVIS ACTIVE");
                }
                scheduleStartWake(700);
            }

            @Override public void onResults(Bundle results) {
                listening = false;
                if (commandMode) {
                    handleCommand(results);
                } else if (containsWakeWord(results)) {
                    wakeForCommand();
                } else {
                    scheduleStartWake(250);
                }
            }

            @Override public void onPartialResults(Bundle partialResults) {
                if (!commandMode && containsWakeWord(partialResults)) {
                    wakeForCommand();
                }
            }

            @Override public void onEvent(int eventType, Bundle params) { }
        });
    }

    private void startListening(boolean command) {
        if (recognizer == null || listening || restarting) return;
        if (!canRecognize()) return;

        commandMode = command;
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, !command);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
            recognizer.startListening(intent);
        } catch (Exception e) {
            listening = false;
            scheduleStartWake(1000);
        }
    }

    private void wakeForCommand() {
        if (commandMode) return;
        commandMode = true;
        transitioning = true;
        stopRecognitionOnly();
        updateNotification("JARVIS LISTENING");
        scheduleStartCommand(300);
    }

    private void startCommandListening() {
        if (!commandMode) return;
        if (!canRecognize()) {
            commandMode = false;
            updateNotification("MICROPHONE / VOICE RECOGNITION NEEDED");
            return;
        }
        createRecognizerIfNeeded();
        transitioning = false;
        startListening(true);
    }

    private boolean containsWakeWord(Bundle results) {
        if (results == null) return false;
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches == null) return false;
        for (String text : matches) {
            if (text == null) continue;
            String n = normalize(text);
            if (n.equals("jarvis") || n.startsWith("jarvis ") || n.contains("hey jarvis")) return true;
        }
        return false;
    }

    private String normalize(String text) {
        return text.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9 ]", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private void handleCommand(Bundle results) {
        ArrayList<String> matches = results == null ? null :
                results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        String command = matches == null || matches.isEmpty() ? "" : matches.get(0).trim();

        if (command.isEmpty()) {
            finishCommandMode();
            return;
        }

        String normalized = normalize(command);
        if (containsWakeWord(results)) {
            normalized = normalized.replaceFirst("^.*?hey jarvis\\s*", "").trim();
            normalized = normalized.replaceFirst("^jarvis\\s*", "").trim();
        }

        String requestedApp = extractAppName(normalized);
        if (requestedApp != null) {
            boolean opened = openInstalledApp(requestedApp);
            if (!opened) {
                updateNotification(requestedApp.toUpperCase(Locale.ROOT) + " NOT INSTALLED");
            }
            finishCommandMode();
            return;
        }

        updateNotification("COMMAND NOT RECOGNIZED");
        finishCommandMode();
    }

    private String extractAppName(String command) {
        String[] names = {"whatsapp", "youtube", "instagram", "chrome", "facebook", "telegram", "maps", "spotify", "gmail"};
        for (String name : names) {
            if (command.contains(name) && (command.contains("open") || command.contains("launch") || command.equals(name))) {
                return name;
            }
        }
        return null;
    }

    private boolean openInstalledApp(String name) {
        String[] packages;
        switch (name) {
            case "whatsapp": packages = new String[]{"com.whatsapp", "com.whatsapp.w4b"}; break;
            case "youtube": packages = new String[]{"com.google.android.youtube"}; break;
            case "instagram": packages = new String[]{"com.instagram.android"}; break;
            case "chrome": packages = new String[]{"com.android.chrome"}; break;
            case "facebook": packages = new String[]{"com.facebook.katana"}; break;
            case "telegram": packages = new String[]{"org.telegram.messenger", "org.telegram.messenger.web"}; break;
            case "maps": packages = new String[]{"com.google.android.apps.maps"}; break;
            case "spotify": packages = new String[]{"com.spotify.music"}; break;
            case "gmail": packages = new String[]{"com.google.android.gm"}; break;
            default: return false;
        }

        for (String pkg : packages) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                startActivity(launch);
                updateNotification("OPENED " + name.toUpperCase(Locale.ROOT));
                return true;
            }
        }
        return false;
    }

    private void finishCommandMode() {
        commandMode = false;
        transitioning = true;
        listening = false;
        updateNotification(sleeping ? "JARVIS SLEEPING" : "JARVIS ACTIVE");
        scheduleStartWake(600);
    }

    private void scheduleStartWake(long delay) {
        handler.removeCallbacksAndMessages(null);
        restarting = true;
        handler.postDelayed(() -> {
            restarting = false;
            if (!commandMode) startWakeListener();
        }, delay);
    }

    private void scheduleStartCommand(long delay) {
        handler.removeCallbacksAndMessages(null);
        restarting = true;
        handler.postDelayed(() -> {
            restarting = false;
            startCommandListening();
        }, delay);
    }

    private void stopRecognitionOnly() {
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) { }
        }
        listening = false;
        restarting = false;
    }

    private void stopWakeListener() {
        stopRecognitionOnly();
        if (recognizer != null) {
            try { recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
        listening = false;
        restarting = false;
    }

    private void updateNotification(String status) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, buildNotification(status));
    }

    private Notification buildNotification(String status) {
        PendingIntent on = actionPendingIntent(ACTION_ON, 10);
        PendingIntent sleep = actionPendingIntent(ACTION_SLEEP, 11);
        PendingIntent off = actionPendingIntent(ACTION_OFF, 12);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Jarvis")
                .setContentText(status)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .addAction(new NotificationCompat.Action(0, "ON", on))
                .addAction(new NotificationCompat.Action(0, "SLEEP", sleep))
                .addAction(new NotificationCompat.Action(0, "OFF", off))
                .build();
    }

    private PendingIntent actionPendingIntent(String action, int requestCode) {
        Intent intent = new Intent(this, JarvisService.class).setAction(action);
        return PendingIntent.getService(this, requestCode, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Jarvis Core", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Jarvis background service status");
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        stopWakeListener();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
