# Jarvis Part 3 — Local AI

This stage adds a real on-device GGUF inference engine based on the official llama.cpp Android binding.

- No API key.
- No cloud request for text generation.
- User selects a GGUF model from Android storage.
- The model is copied into Jarvis private storage and loaded locally.
- Chat generation runs on-device.
- Existing Jarvis foreground service/ON/SLEEP/OFF code is retained.

The GitHub Actions workflow fetches the official llama.cpp Android binding at build time, so the large native source is not stored inside this ZIP.
