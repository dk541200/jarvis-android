package com.jarvis.android

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var pick: Button

    private var engine: InferenceEngine? = null
    private var generationJob: Job? = null
    private var modelReady = false

    private val modelPicker = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { importAndLoadModel(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        lifecycleScope.launch(Dispatchers.Default) {
            engine = AiChat.getInferenceEngine(applicationContext)
            withContext(Dispatchers.Main) {
                status.text = "Local AI engine ready — choose a GGUF model"
            }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 20)
        }

        val title = TextView(this).apply {
            text = "JARVIS • LOCAL AI"
            textSize = 24f
            setPadding(0, 0, 0, 8)
        }
        root.addView(title, lp())

        status = TextView(this).apply {
            text = "Starting local AI engine…"
            textSize = 14f
        }
        root.addView(status, lp())

        pick = Button(this).apply {
            text = "SELECT GGUF MODEL"
            setOnClickListener { modelPicker.launch(arrayOf("*/*")) }
        }
        root.addView(pick, lp())

        val scroll = ScrollView(this)
        chat = TextView(this).apply {
            text = "No model loaded.\n\nYour model stays on this phone after import."
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }
        scroll.addView(chat, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            hint = "Ask Jarvis…"
            isEnabled = false
            maxLines = 4
        }
        root.addView(input, lp())

        send = Button(this).apply {
            text = "SEND"
            isEnabled = false
            setOnClickListener { sendPrompt() }
        }
        root.addView(send, lp())

        setContentView(root)
    }

    private fun lp() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = 10
    }

    private fun importAndLoadModel(uri: Uri) {
        pick.isEnabled = false
        status.text = "Importing model…"
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val name = safeModelName(uri)
                val dir = File(filesDir, "models").apply { mkdirs() }
                val file = File(dir, name)
                if (!file.exists() || file.length() == 0L) {
                    contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(file).use { output -> input.copyTo(output, 1024 * 1024) }
                    } ?: error("Could not open model")
                }

                val localEngine = engine ?: error("AI engine not ready")
                withContext(Dispatchers.Main) { status.text = "Loading model…" }
                localEngine.loadModel(file.absolutePath)

                withContext(Dispatchers.Main) {
                    modelReady = true
                    status.text = "LOCAL AI ONLINE • ${file.name}"
                    chat.text = "Model loaded successfully.\n\nAsk Jarvis anything."
                    input.isEnabled = true
                    send.isEnabled = true
                    pick.isEnabled = true
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    pick.isEnabled = true
                    status.text = "Model load failed"
                    Toast.makeText(this@MainActivity, t.message ?: "Unknown error", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun safeModelName(uri: Uri): String {
        val raw = uri.lastPathSegment?.substringAfterLast('/') ?: "jarvis-model.gguf"
        val clean = raw.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return if (clean.endsWith(".gguf", true)) clean else "$clean.gguf"
    }

    private fun sendPrompt() {
        if (!modelReady) return
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        val localEngine = engine ?: return

        generationJob?.cancel()
        input.setText("")
        input.isEnabled = false
        send.isEnabled = false

        chat.append("\n\nYOU: $prompt\nJARVIS: ")
        generationJob = lifecycleScope.launch(Dispatchers.Default) {
            localEngine.sendUserPrompt(prompt)
                .onCompletion {
                    withContext(Dispatchers.Main) {
                        input.isEnabled = true
                        send.isEnabled = true
                    }
                }
                .collect { token ->
                    withContext(Dispatchers.Main) {
                        chat.append(token)
                    }
                }
        }
    }

    override fun onDestroy() {
        generationJob?.cancel()
        engine?.destroy()
        super.onDestroy()
    }
}
