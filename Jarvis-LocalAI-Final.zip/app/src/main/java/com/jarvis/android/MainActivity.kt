package com.jarvis.android

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import com.arm.aichat.gguf.GgufMetadataReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var pick: Button
    private lateinit var root: LinearLayout

    private var engine: InferenceEngine? = null
    private var generationJob: Job? = null
    private var modelReady = false

    private val modelPicker = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { importAndLoadModel(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 9, 16)
        window.navigationBarColor = Color.rgb(5, 9, 16)
        buildUi()

        lifecycleScope.launch(Dispatchers.Default) {
            val localEngine = AiChat.getInferenceEngine(applicationContext)
            engine = localEngine
            try {
                localEngine.state.first {
                    it is InferenceEngine.State.Initialized || it is InferenceEngine.State.Error
                }
                if (localEngine.state.value is InferenceEngine.State.Error) {
                    localEngine.cleanUp()
                }
                withContext(Dispatchers.Main) {
                    setStatus("READY • SELECT A GGUF MODEL", false)
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    setStatus("ENGINE ERROR • ${t.javaClass.simpleName}", true)
                    chat.text = "Local AI engine could not start.\n\n${t.message ?: "Unknown error"}"
                }
            }
        }
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = GradientDrawable().apply {
                setColor(Color.rgb(5, 9, 16))
            }
        }

        val scrollRoot = ScrollView(this).apply {
            isFillViewport = true
            addView(root, ViewGroup.LayoutParams(-1, -1))
        }

        val title = TextView(this).apply {
            text = "JARVIS"
            textSize = 30f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        root.addView(title, lp(0))

        val subtitle = TextView(this).apply {
            text = "LOCAL AI  •  PRIVATE  •  OFFLINE"
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.rgb(0, 229, 255))
            letterSpacing = 0.08f
        }
        root.addView(subtitle, lp(dp(14)))

        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = cardBackground(Color.rgb(12, 20, 31), Color.rgb(0, 180, 210))
        }

        status = TextView(this).apply {
            text = "STARTING LOCAL AI ENGINE…"
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        statusCard.addView(status, lp(0))

        val hint = TextView(this).apply {
            text = "Your model stays inside this app's private storage."
            textSize = 12f
            setTextColor(Color.rgb(160, 175, 195))
        }
        statusCard.addView(hint, lp(dp(6)))
        root.addView(statusCard, lp(dp(14)))

        pick = Button(this).apply {
            text = "SELECT GGUF MODEL"
            isAllCaps = false
            textSize = 14f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = cardBackground(Color.rgb(0, 92, 108), Color.rgb(0, 229, 255))
            setOnClickListener { modelPicker.launch(arrayOf("application/octet-stream", "*/*")) }
        }
        root.addView(pick, lp(dp(14)))

        val divider = View(this).apply {
            setBackgroundColor(Color.rgb(25, 38, 52))
        }
        root.addView(divider, LinearLayout.LayoutParams(-1, dp(1)).apply {
            bottomMargin = dp(12)
        })

        chat = TextView(this).apply {
            text = "No model loaded yet.\n\nChoose a .gguf file above."
            textSize = 15f
            setTextColor(Color.rgb(225, 235, 245))
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = cardBackground(Color.rgb(9, 15, 24), Color.rgb(30, 48, 66))
        }
        root.addView(chat, lp(dp(14)))

        input = EditText(this).apply {
            hint = "Ask Jarvis…"
            isEnabled = false
            maxLines = 4
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(115, 135, 155))
            textSize = 15f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = cardBackground(Color.rgb(10, 17, 27), Color.rgb(30, 48, 66))
        }
        root.addView(input, lp(dp(10)))

        send = Button(this).apply {
            text = "SEND"
            isAllCaps = false
            textSize = 14f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = cardBackground(Color.rgb(0, 78, 92), Color.rgb(0, 229, 255))
            isEnabled = false
            setOnClickListener { sendPrompt() }
        }
        root.addView(send, lp(0))

        setContentView(scrollRoot)
    }

    private fun lp(bottom: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = bottom
        }

    private fun cardBackground(fill: Int, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(16).toFloat()
            setColor(fill)
            setStroke(dp(1), stroke)
        }

    private fun setStatus(text: String, error: Boolean) {
        status.text = text
        status.setTextColor(
            if (error) Color.rgb(255, 110, 110) else Color.rgb(0, 229, 255)
        )
    }

    private fun importAndLoadModel(uri: Uri) {
        modelReady = false
        pick.isEnabled = false
        input.isEnabled = false
        send.isEnabled = false
        setStatus("CHECKING GGUF…", false)

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val displayName = queryDisplayName(uri)
                if (!displayName.endsWith(".gguf", true)) {
                    error("Please select a .gguf model file")
                }

                val dir = File(filesDir, "models").apply { mkdirs() }
                val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val file = File(dir, safeName)
                val temp = File(dir, ".importing_${System.currentTimeMillis()}.gguf")

                withContext(Dispatchers.Main) {
                    setStatus("IMPORTING • $safeName", false)
                }

                contentResolver.openInputStream(uri)?.use { source ->
                    FileOutputStream(temp).use { target ->
                        source.copyTo(target, 1024 * 1024)
                    }
                } ?: error("Could not open selected file")

                if (!temp.exists() || temp.length() < 1024 * 1024) {
                    temp.delete()
                    error("Model file is incomplete or too small")
                }

                if (file.exists()) file.delete()
                if (!temp.renameTo(file)) {
                    temp.copyTo(file, overwrite = true)
                    temp.delete()
                }

                // Parse the copied private file, not the original content URI.
                // This confirms that the exact bytes passed to native llama.cpp are valid GGUF.
                val metadata = FileInputStreamCompat.open(file).use { stream ->
                    GgufMetadataReader.create().readStructuredMetadata(stream)
                }

                val architecture = metadata.architecture?.architecture ?: "unknown"
                val fileSizeMb = file.length() / (1024.0 * 1024.0)

                withContext(Dispatchers.Main) {
                    setStatus("GGUF OK • $architecture • ${"%.0f".format(fileSizeMb)} MB", false)
                    chat.text = "Model detected.\n\nName: ${metadata.basic.name ?: safeName}\nArchitecture: $architecture\nGGUF: ${metadata.version}\nSize: ${"%.0f".format(fileSizeMb)} MB\n\nLoading native model…"
                }

                val localEngine = engine ?: error("AI engine is not ready")
                localEngine.loadModel(file.absolutePath)

                withContext(Dispatchers.Main) {
                    modelReady = true
                    setStatus("LOCAL AI ONLINE • $architecture", false)
                    chat.text = "JARVIS IS READY\n\nModel: ${metadata.basic.name ?: safeName}\nArchitecture: $architecture\n\nAsk Jarvis anything."
                    input.isEnabled = true
                    send.isEnabled = true
                    pick.isEnabled = true
                }
            } catch (t: Throwable) {
                try { engine?.cleanUp() } catch (_: Throwable) {}
                withContext(Dispatchers.Main) {
                    pick.isEnabled = true
                    setStatus("MODEL LOAD FAILED", true)
                    val detail = "${t.javaClass.simpleName}: ${t.message ?: "Unknown error"}"
                    chat.text = "JARVIS COULD NOT LOAD THIS MODEL.\n\n$detail\n\nThe GGUF was checked before native loading."
                    Toast.makeText(this@MainActivity, detail, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        contentResolver.query(
            uri,
            arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (index >= 0) return cursor.getString(index)
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "jarvis-model.gguf"
    }

    private fun sendPrompt() {
        if (!modelReady) return
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        val localEngine = engine ?: return

        generationJob?.cancel()
        input.setText("")
        input.isEnabled = false
        send.isEnabled = false
        chat.append("\n\nYOU: $prompt\nJARVIS: ")

        generationJob = lifecycleScope.launch(Dispatchers.Default) {
            localEngine.sendUserPrompt(prompt)
                .onCompletion {
                    withContext(Dispatchers.Main) {
                        input.isEnabled = true
                        send.isEnabled = true
                    }
                }
                .collect { token ->
                    withContext(Dispatchers.Main) { chat.append(token) }
                }
        }
    }

    override fun onDestroy() {
        generationJob?.cancel()
        try { engine?.cleanUp() } catch (_: Throwable) {}
        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}

private object FileInputStreamCompat {
    fun open(file: File): java.io.InputStream = java.io.FileInputStream(file)
}
