# Jarvis Local AI — Android source

This package contains the Jarvis app source and the GitHub Actions workflow used to build it on top of the official llama.cpp Android binding.

## Expected model

Use a valid `.gguf` model. The app copies the selected model into private app storage, validates/parses its GGUF metadata, then passes the private file path to the official llama.cpp inference engine.

## Build

The workflow supports either:

1. `app/src/main` already extracted in the repository, or
2. a root-level `jarvis-github-final.zip` containing the `app/` directory.

The workflow reads the official llama.cpp Android project's required NDK and CMake versions instead of hard-coding older native tool versions.
