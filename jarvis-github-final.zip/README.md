# Jarvis Local AI Android — bundled local brain

- Package: `com.jarvis.android`
- Official llama.cpp Android AI library.
- Model picker removed.
- GitHub Actions downloads `Llama-3.2-1B-Instruct-Q4_0.gguf` into Android assets before building.
- On first launch Jarvis copies the bundled GGUF into private app storage and loads it with the native llama.cpp loader.
- Later launches reuse the private copy.
- GGUF is kept uncompressed in the APK resources.
- Workflow publishes a direct APK GitHub Release.
