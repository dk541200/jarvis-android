Jarvis Local AI source package for the existing GitHub build workflow.
