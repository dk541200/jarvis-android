# Jarvis Local AI v4.3

This build keeps the bundled Llama 3.2 1B Q4_0 model and fixes the Android native-loading path by building the arm64 CPU backend statically instead of relying on dynamically loaded CPU backend variants. It also uses NDK 29.0.13113456, legacy JNI packaging, and a clean native rebuild.
