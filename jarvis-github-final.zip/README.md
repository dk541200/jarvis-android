# JARVIS Local AI v5.0

This is the cleaned Android source package for the JARVIS local-AI project.

## Included
- Llama 3.2 1B Q4_0 bundled by GitHub Actions.
- Native llama.cpp Android integration.
- Persistent on-device chat history.
- New Chat / History controls.
- Dark futuristic JARVIS interface.
- Custom cyan/emerald JARVIS launcher icon.
- Foreground microphone service for background voice mode.
- Speech recognition wake/command loop.
- Text-to-speech responses for simple background commands.
- Real app-launch commands for supported installed apps.
- GitHub Actions workflow that builds and publishes the APK.

## Important Android limitation
The background service is a foreground microphone service. It is not a fake promise of unrestricted always-on hotword access. Modern Android can restrict microphone/background execution, and true system-assistant hotword behavior requires the user to select/configure an Android VoiceInteractionService/default assistant where supported.

The current build keeps the local Llama model in the main app process. The background voice service handles lightweight wake/command tasks rather than loading a second copy of the large model. This avoids wasting phone RAM.

## Build
Push this repository to GitHub and run the `Build Jarvis APK` workflow. The workflow downloads the official llama.cpp Android example, downloads the Llama GGUF, injects this app source, builds an arm64 debug APK, verifies the package/model/native library, and publishes the APK as a GitHub Release.
