# Jarvis Local AI — Native Loader Fix v4.1

This bundle contains the complete Jarvis Android source and GitHub Actions workflow.

Build behavior:
- Official `ggml-org/llama.cpp` Android project is used as the native build base.
- Llama 3.2 1B Instruct Q4_0 is downloaded by the workflow and bundled into the APK.
- The model picker is removed; Jarvis copies the bundled GGUF to private app storage and loads it automatically.
- arm64-v8a is the only packaged ABI.
- NDK 29.0.13113456 is installed.
- Native libraries use legacy extraction and largeHeap is enabled.
- The workflow verifies the package ID, arm64 native libraries, and bundled GGUF before publishing the APK.
