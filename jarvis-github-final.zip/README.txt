Keep JarvisSource.zip in the repository. The workflow automatically extracts it if app/src/main is not present.
