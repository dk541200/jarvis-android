package com.jarvis.android

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ChatStore {
    data class Item(val role: String, val text: String)
    private const val PREFS = "jarvis_chat"
    private const val KEY = "messages"

    fun read(context: Context): List<Item> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val array = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                add(Item(o.optString("role"), o.optString("text")))
            }
        }
    }

    @JvmStatic
    fun add(context: Context, role: String, text: String) {
        val array = toJson(read(context) + Item(role, text))
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }

    fun replaceLastAssistant(context: Context, text: String) {
        val items = read(context).toMutableList()
        val index = items.indexOfLast { it.role == "JARVIS" }
        if (index >= 0) items[index] = Item("JARVIS", text)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, toJson(items).toString()).apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }

    private fun toJson(items: List<Item>): JSONArray = JSONArray().apply {
        items.takeLast(200).forEach { put(JSONObject().put("role", it.role).put("text", it.text)) }
    }
}
