package com.jarvis.android

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var send: Button

    private var engine: InferenceEngine? = null
    private var generationJob: Job? = null
    private var modelReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        initializeJarvis()
    }

    private fun initializeJarvis() {
        lifecycleScope.launch(Dispatchers.Default) {
            try {
                withContext(Dispatchers.Main) {
                    status.text = "Starting local AI engine…"
                    chat.text = "Preparing Jarvis…"
                }

                val localEngine = AiChat.getInferenceEngine(applicationContext)
                engine = localEngine
                localEngine.state.first {
                    it is InferenceEngine.State.Initialized || it is InferenceEngine.State.Error
                }

                if (localEngine.state.value is InferenceEngine.State.Error) {
                    localEngine.cleanUp()
                    error("AI engine initialization failed")
                }

                withContext(Dispatchers.Main) {
                    status.text = "Loading Jarvis brain…"
                    chat.text = "Installing bundled local AI model…\n\nPlease wait."
                }

                val modelFile = copyBundledModel()

                withContext(Dispatchers.Main) {
                    status.text = "Loading local AI…"
                    chat.text = "Loading bundled Llama model…\n\nThis happens automatically."
                }

                // Native llama.cpp is the source of truth for GGUF loading.
                localEngine.loadModel(modelFile.absolutePath)

                withContext(Dispatchers.Main) {
                    modelReady = true
                    status.text = "● ACTIVE"
                    chat.text = "Jarvis is ready.\n\nAsk me anything."
                    input.isEnabled = true
                    send.isEnabled = true
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    modelReady = false
                    input.isEnabled = false
                    send.isEnabled = false
                    status.text = "LOCAL AI ERROR"
                    val detail = "${t.javaClass.simpleName}: ${t.message ?: "Unknown error"}"
                    chat.text = "Jarvis could not load its bundled local brain.\n\n$detail"
                    Toast.makeText(this@MainActivity, detail, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private suspend fun copyBundledModel(): File = withContext(Dispatchers.IO) {
        val dir = File(filesDir, "models").apply { mkdirs() }
        val model = File(dir, MODEL_FILE_NAME)

        // Avoid copying the ~771 MB model again on every app launch.
        if (model.exists() && model.length() > MIN_MODEL_BYTES) {
            return@withContext model
        }

        val temp = File(dir, ".${MODEL_FILE_NAME}.part")
        if (temp.exists()) temp.delete()

        assets.open(MODEL_FILE_NAME).use { input ->
            FileOutputStream(temp).use { output ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count <= 0) break
                    output.write(buffer, 0, count)
                }
                output.fd.sync()
            }
        }

        if (temp.length() <= MIN_MODEL_BYTES) {
            temp.delete()
            error("Bundled GGUF model is missing or incomplete")
        }

        if (model.exists()) model.delete()
        if (!temp.renameTo(model)) {
            temp.copyTo(model, overwrite = true)
            temp.delete()
        }

        model
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 28, 28, 20)
        }

        val title = TextView(this).apply {
            text = "JARVIS • LOCAL AI"
            textSize = 24f
            setPadding(0, 0, 0, 8)
        }
        root.addView(title, lp())

        status = TextView(this).apply {
            text = "Starting local AI engine…"
            textSize = 14f
        }
        root.addView(status, lp())

        val scroll = ScrollView(this)
        chat = TextView(this).apply {
            text = "Preparing Jarvis…"
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }
        scroll.addView(chat, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            this.hint = "Ask Jarvis…"
            isEnabled = false
            maxLines = 4
        }
        root.addView(input, lp())

        send = Button(this).apply {
            text = "SEND"
            isEnabled = false
            setOnClickListener { sendPrompt() }
        }
        root.addView(send, lp())

        setContentView(root)
    }

    private fun lp() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = 10
    }

    private fun sendPrompt() {
        if (!modelReady) return
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        val localEngine = engine ?: return

        generationJob?.cancel()
        input.setText("")
        input.isEnabled = false
        send.isEnabled = false

        chat.append("\n\nYOU: $prompt\nJARVIS: ")
        generationJob = lifecycleScope.launch(Dispatchers.Default) {
            localEngine.sendUserPrompt(prompt)
                .onCompletion {
                    withContext(Dispatchers.Main) {
                        input.isEnabled = true
                        send.isEnabled = true
                    }
                }
                .collect { token ->
                    withContext(Dispatchers.Main) {
                        chat.append(token)
                    }
                }
        }
    }

    override fun onDestroy() {
        generationJob?.cancel()
        try { engine?.cleanUp() } catch (_: Throwable) {}
        super.onDestroy()
    }

    companion object {
        private const val MODEL_FILE_NAME = "Llama-3.2-1B-Instruct-Q4_0.gguf"
        private const val MIN_MODEL_BYTES = 700L * 1024L * 1024L
    }
}
