package com.jarvis.android

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var history: Button
    private lateinit var clear: Button
    private lateinit var voice: Button

    private var engine: InferenceEngine? = null
    private var generationJob: Job? = null
    private var modelReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestMicPermissionIfNeeded()
        buildUi()
        renderHistory()
        initializeJarvis()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 20)
            setBackgroundColor(Color.rgb(5, 9, 18))
        }

        val title = TextView(this).apply {
            text = "JARVIS"
            textSize = 30f
            setTextColor(Color.rgb(0, 229, 255))
            gravity = Gravity.CENTER
        }
        root.addView(title, lp(0, 8))

        val subtitle = TextView(this).apply {
            text = "LOCAL AI • PRIVATE • OFFLINE BRAIN"
            textSize = 11f
            setTextColor(Color.rgb(140, 170, 185))
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, lp(0, 12))

        status = TextView(this).apply {
            text = "Starting local AI engine…"
            textSize = 14f
            setTextColor(Color.rgb(90, 255, 190))
            gravity = Gravity.CENTER
        }
        root.addView(status, lp(0, 10))

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        history = Button(this).apply {
            text = "HISTORY"
            setOnClickListener { renderHistory() }
        }
        clear = Button(this).apply {
            text = "NEW CHAT"
            setOnClickListener {
                ChatStore.clear(this@MainActivity)
                renderHistory()
            }
        }
        voice = Button(this).apply {
            text = "BACKGROUND VOICE"
            setOnClickListener { toggleBackgroundService() }
        }
        controls.addView(history, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(clear, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(voice, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(controls, lp(0, 10))

        val scroll = ScrollView(this)
        chat = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.rgb(235, 245, 250))
            setPadding(8, 18, 8, 18)
        }
        scroll.addView(chat, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            hint = "Ask Jarvis…"
            hint = "Ask Jarvis…"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(110, 130, 145))
            maxLines = 5
            isEnabled = false
        }
        root.addView(input, lp(0, 10))

        send = Button(this).apply {
            text = "SEND"
            isEnabled = false
            setOnClickListener { sendPrompt() }
        }
        root.addView(send, lp(0, 0))

        setContentView(root)
    }

    private fun lp(top: Int, bottom: Int) = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        topMargin = top
        this.bottomMargin = bottom
    }

    private fun initializeJarvis() {
        lifecycleScope.launch(Dispatchers.Default) {
            try {
                withContext(Dispatchers.Main) {
                    status.text = "Starting native AI…"
                }
                val localEngine = AiChat.getInferenceEngine(applicationContext)
                engine = localEngine
                localEngine.state.first {
                    it is InferenceEngine.State.Initialized || it is InferenceEngine.State.Error
                }
                if (localEngine.state.value is InferenceEngine.State.Error) {
                    localEngine.cleanUp()
                    error("AI engine initialization failed")
                }

                withContext(Dispatchers.Main) { status.text = "Loading local brain…" }
                val modelFile = copyBundledModel()
                localEngine.loadModel(modelFile.absolutePath)

                withContext(Dispatchers.Main) {
                    modelReady = true
                    status.text = "● JARVIS ACTIVE"
                    input.isEnabled = true
                    send.isEnabled = true
                    renderHistory()
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    modelReady = false
                    input.isEnabled = false
                    send.isEnabled = false
                    status.text = "LOCAL AI ERROR"
                    chat.text = "Jarvis could not load the local brain.\n\n${t.javaClass.simpleName}: ${t.message ?: "Unknown error"}"
                }
            }
        }
    }

    private suspend fun copyBundledModel(): File = withContext(Dispatchers.IO) {
        val dir = File(filesDir, "models").apply { mkdirs() }
        val model = File(dir, MODEL_FILE_NAME)
        if (model.exists() && model.length() > MIN_MODEL_BYTES) return@withContext model
        val temp = File(dir, ".${MODEL_FILE_NAME}.part")
        if (temp.exists()) temp.delete()
        assets.open(MODEL_FILE_NAME).use { input ->
            FileOutputStream(temp).use { output ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count <= 0) break
                    output.write(buffer, 0, count)
                }
                output.fd.sync()
            }
        }
        if (temp.length() <= MIN_MODEL_BYTES) error("Bundled GGUF model is missing or incomplete")
        if (model.exists()) model.delete()
        if (!temp.renameTo(model)) temp.copyTo(model, overwrite = true).also { temp.delete() }
        model
    }

    private fun sendPrompt() {
        if (!modelReady) return
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        val localEngine = engine ?: return
        generationJob?.cancel()
        input.setText("")
        input.isEnabled = false
        send.isEnabled = false
        ChatStore.add(this, "YOU", prompt)
        renderHistory()
        ChatStore.add(this, "JARVIS", "")
        generationJob = lifecycleScope.launch(Dispatchers.Default) {
            val builder = StringBuilder()
            localEngine.sendUserPrompt(prompt)
                .onCompletion {
                    ChatStore.replaceLastAssistant(this@MainActivity, builder.toString())
                    withContext(Dispatchers.Main) {
                        input.isEnabled = true
                        send.isEnabled = true
                        renderHistory()
                    }
                }
                .collect { token ->
                    builder.append(token)
                    withContext(Dispatchers.Main) { renderHistory(builder.toString()) }
                }
        }
    }

    private fun renderHistory(liveAssistant: String? = null) {
        val items = ChatStore.read(this)
        if (items.isEmpty()) {
            chat.text = "JARVIS CORE\n\nReady. Your conversations will stay on this device.\n\nSay: Hey Jarvis"
            return
        }
        val text = buildString {
            append("CHAT HISTORY\n\n")
            items.forEach { item ->
                append(item.role).append(": ").append(item.text).append("\n\n")
            }
            if (liveAssistant != null) {
                append("JARVIS: ").append(liveAssistant)
            }
        }
        chat.text = text
    }

    private fun toggleBackgroundService() {
        val intent = Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_ON)
        ContextCompat.startForegroundService(this, intent)
        status.text = "● BACKGROUND VOICE READY"
    }

    private fun requestMicPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    override fun onDestroy() {
        generationJob?.cancel()
        try { engine?.cleanUp() } catch (_: Throwable) {}
        super.onDestroy()
    }

    companion object {
        private const val MODEL_FILE_NAME = "Llama-3.2-1B-Instruct-Q4_0.gguf"
        private const val MIN_MODEL_BYTES = 700L * 1024L * 1024L
    }
}
