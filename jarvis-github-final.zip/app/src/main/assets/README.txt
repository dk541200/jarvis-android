The GitHub Actions workflow downloads the bundled Llama 3.2 1B Q4_0 GGUF model here before building the APK.
