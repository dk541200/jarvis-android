package com.jarvis.android

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import com.arm.aichat.gguf.GgufMetadataReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var pick: Button

    private var engine: InferenceEngine? = null
    private var generationJob: Job? = null
    private var modelReady = false

    private val modelPicker = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { importAndLoadModel(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        lifecycleScope.launch(Dispatchers.Default) {
            val localEngine = AiChat.getInferenceEngine(applicationContext)
            engine = localEngine
            try {
                localEngine.state.first { it is InferenceEngine.State.Initialized || it is InferenceEngine.State.Error }
                if (localEngine.state.value is InferenceEngine.State.Error) {
                    localEngine.cleanUp()
                }
                withContext(Dispatchers.Main) {
                    status.text = "Local AI engine ready — choose a GGUF model"
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    status.text = "AI engine error: ${t.javaClass.simpleName}: ${t.message ?: "unknown"}"
                }
            }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 20)
        }

        val title = TextView(this).apply {
            text = "JARVIS • LOCAL AI"
            textSize = 24f
            setPadding(0, 0, 0, 8)
        }
        root.addView(title, lp())

        status = TextView(this).apply {
            text = "Starting local AI engine…"
            textSize = 14f
        }
        root.addView(status, lp())

        pick = Button(this).apply {
            text = "SELECT GGUF MODEL"
            setOnClickListener { modelPicker.launch(arrayOf("*/*")) }
        }
        root.addView(pick, lp())

        val scroll = ScrollView(this)
        chat = TextView(this).apply {
            text = "No model loaded.\n\nYour model stays on this phone after import."
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }
        scroll.addView(chat, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            hint = "Ask Jarvis…"
            isEnabled = false
            maxLines = 4
        }
        root.addView(input, lp())

        send = Button(this).apply {
            text = "SEND"
            isEnabled = false
            setOnClickListener { sendPrompt() }
        }
        root.addView(send, lp())

        setContentView(root)
    }

    private fun lp() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = 10
    }

    private fun importAndLoadModel(uri: Uri) {
        pick.isEnabled = false
        status.text = "Reading GGUF metadata…"
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // Use llama.cpp's official GGUF parser first. This avoids guessing the
                // model architecture from the filename and gives a useful error before
                // native inference is started.
                val metadata = contentResolver.openInputStream(uri)?.use {
                    GgufMetadataReader.create().readStructuredMetadata(it)
                } ?: error("Could not open selected file")

                val architecture = metadata.architecture?.architecture ?: "unknown"
                val modelName = metadata.basic.name ?: queryDisplayName(uri)

                withContext(Dispatchers.Main) {
                    status.text = "GGUF OK • architecture: $architecture"
                }

                val dir = File(filesDir, "models").apply { mkdirs() }
                val safeName = modelName
                    .replace(Regex("[^A-Za-z0-9._-]"), "_")
                    .let { if (it.endsWith(".gguf", true)) it else "$it.gguf" }
                val file = File(dir, safeName)
                val temp = File(dir, ".importing_${System.currentTimeMillis()}.gguf")

                withContext(Dispatchers.Main) { status.text = "Importing $safeName…" }
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(temp).use { output ->
                        input.copyTo(output, 1024 * 1024)
                    }
                } ?: error("Could not open selected file")

                if (!temp.exists() || temp.length() < 1024 * 1024) {
                    temp.delete()
                    error("Model file is incomplete or too small")
                }

                if (file.exists()) file.delete()
                if (!temp.renameTo(file)) {
                    temp.copyTo(file, overwrite = true)
                    temp.delete()
                }

                // Reuse the initialized official llama.cpp engine. Do not call cleanUp()
                // here: after cleanup the same engine instance is not guaranteed reusable.
                val localEngine = engine ?: error("AI engine is not ready")
                withContext(Dispatchers.Main) { status.text = "Loading $architecture model…" }
                localEngine.loadModel(file.absolutePath)

                withContext(Dispatchers.Main) {
                    modelReady = true
                    status.text = "LOCAL AI ONLINE • $architecture"
                    chat.text = "Model loaded successfully.\n\nModel: $safeName\nArchitecture: $architecture\n\nAsk Jarvis anything."
                    input.isEnabled = true
                    send.isEnabled = true
                    pick.isEnabled = true
                }
            } catch (t: Throwable) {
                try { engine?.cleanUp() } catch (_: Throwable) {}
                withContext(Dispatchers.Main) {
                    pick.isEnabled = true
                    status.text = "Model load failed"
                    val detail = "${t.javaClass.simpleName}: ${t.message ?: "Unknown error"}"
                    chat.text = "Model could not be loaded.\n\n$detail\n\nIf this says UnsupportedArchitectureException, the GGUF architecture is the key detail to check; the app now shows it before native loading."
                    Toast.makeText(this@MainActivity, detail, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (i >= 0) return c.getString(i)
            }
        }
        return safeModelName(uri)
    }

    private fun safeModelName(uri: Uri): String {
        val raw = uri.lastPathSegment?.substringAfterLast('/') ?: "jarvis-model.gguf"
        val clean = raw.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return if (clean.endsWith(".gguf", true)) clean else "$clean.gguf"
    }

    private fun sendPrompt() {
        if (!modelReady) return
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        val localEngine = engine ?: return

        generationJob?.cancel()
        input.setText("")
        input.isEnabled = false
        send.isEnabled = false

        chat.append("\n\nYOU: $prompt\nJARVIS: ")
        generationJob = lifecycleScope.launch(Dispatchers.Default) {
            localEngine.sendUserPrompt(prompt)
                .onCompletion {
                    withContext(Dispatchers.Main) {
                        input.isEnabled = true
                        send.isEnabled = true
                    }
                }
                .collect { token ->
                    withContext(Dispatchers.Main) {
                        chat.append(token)
                    }
                }
        }
    }

    override fun onDestroy() {
        generationJob?.cancel()
        try { engine?.cleanUp() } catch (_: Throwable) {}
        super.onDestroy()
    }
}
