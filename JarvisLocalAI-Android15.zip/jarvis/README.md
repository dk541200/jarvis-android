# JARVIS • LOCAL AI

Native Android JARVIS project: foreground voice service, ACTIVE/SLEEP/OFF notification controls, installed-app launcher resolution, and local GGUF inference through the official llama.cpp Android binding.

## Build

GitHub Actions is the supported no-IDE build path. Push this repository to GitHub and run **Build JARVIS APK** from Actions. The workflow installs Android SDK 35, JDK 17, NDK 29, CMake 3.31.6, fetches a pinned official llama.cpp Android binding, and uploads the release APK.

The project uses the official `examples/llama.android/lib` binding from llama.cpp and its `AiChat` / `InferenceEngine` APIs. The GGUF file is copied into app-private storage before loading.

## Device setup

1. Install the APK.
2. Grant microphone and notification permissions when requested.
3. Tap **ACTIVE**.
4. Say **Hey Jarvis**, then say an app command such as **Open WhatsApp**.
5. Use **SLEEP** for microphone-idle standby and **OFF** to stop the foreground service.
6. Select a `.gguf` file to load local AI. No cloud API key is required.

## Notes

- Android 15 / API 35 target.
- No root, exploit, accessibility bypass, or hidden permission APIs.
- App launching is resolved with Android's installed launcher activities rather than hardcoded package IDs.
- Wake-word detection uses Android `SpeechRecognizer`; it is not a privileged hotword API and therefore depends on the device's speech-recognition service.
