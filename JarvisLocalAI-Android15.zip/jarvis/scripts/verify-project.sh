#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
[ -f "$ROOT/settings.gradle.kts" ]
[ -f "$ROOT/app/src/main/AndroidManifest.xml" ]
[ -f "$ROOT/app/src/main/java/com/jarvis/localai/MainActivity.kt" ]
[ -f "$ROOT/app/src/main/java/com/jarvis/localai/JarvisService.kt" ]
[ -f "$ROOT/.github/workflows/build-apk.yml" ]
! grep -R "uses-permission" "$ROOT" --include='AndroidManifest.xml' | grep -v '^Binary' | grep -q 'AndroidManifest.xml.*AndroidManifest.xml' || true
printf 'JARVIS project structure OK\n'
