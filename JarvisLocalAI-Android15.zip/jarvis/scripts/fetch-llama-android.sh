#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LLAMA_REF="b10516"
TMP="${RUNNER_TEMP:-/tmp}/llama.cpp"
rm -rf "$TMP" "$ROOT/third_party/llama.cpp"
git clone --depth 1 --branch "$LLAMA_REF" https://github.com/ggml-org/llama.cpp.git "$TMP"
mkdir -p "$ROOT/third_party"
cp -a "$TMP" "$ROOT/third_party/llama.cpp"
rm -rf "$ROOT/llama"
mkdir -p "$ROOT/llama"
cp -a "$TMP/examples/llama.android/lib/." "$ROOT/llama/"
python3 - "$ROOT/llama/build.gradle.kts" "$ROOT/llama/src/main/cpp/CMakeLists.txt" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
s=s.replace('plugins {\n    alias(libs.plugins.android.library)\n    alias(libs.plugins.jetbrains.kotlin.android)\n}', 'plugins {\n    id("com.android.library")\n    id("org.jetbrains.kotlin.android")\n}')
s=s.replace('compileSdk = 36','compileSdk = 35')
s=s.replace('implementation(libs.androidx.core.ktx)','implementation("androidx.core:core-ktx:1.17.0")')
s=s.replace('implementation(libs.androidx.datastore.preferences)','implementation("androidx.datastore:datastore-preferences:1.2.0")')
s=s.replace('testImplementation(libs.junit)','testImplementation("junit:junit:4.13.2")')
s=s.replace('androidTestImplementation(libs.androidx.junit)','androidTestImplementation("androidx.test.ext:junit:1.3.0")')
s=s.replace('    publishing {\n        singleVariant("release") {\n            withJavadocJar()\n        }\n    }','')
s=s.replace('arguments += "-DGGML_LLAMAFILE=OFF"','arguments += "-DGGML_LLAMAFILE=OFF"\n                arguments += "-DLLAMA_SRC=${rootProject.projectDir}/third_party/llama.cpp"')
p.write_text(s)

p=Path(sys.argv[2]); s=p.read_text()
s=s.replace('set(LLAMA_SRC ${CMAKE_CURRENT_LIST_DIR}/../../../../../../)\nadd_subdirectory(${LLAMA_SRC} build-llama)', 'if(NOT DEFINED LLAMA_SRC)\n    set(LLAMA_SRC ${CMAKE_CURRENT_LIST_DIR}/../../../../../../)\nendif()\nadd_subdirectory(${LLAMA_SRC} build-llama)')
p.write_text(s)
PY
rm -rf "$ROOT/llama/.gradle" "$ROOT/llama/build"
