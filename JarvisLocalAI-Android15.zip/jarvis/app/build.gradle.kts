plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.jarvis.localai"; compileSdk=35
 defaultConfig { applicationId="com.jarvis.localai"; minSdk=33; targetSdk=35; versionCode=1; versionName="1.0.0" }
 buildTypes { release { isMinifyEnabled=false }; debug { isMinifyEnabled=false } }
 compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget="17" }
}
dependencies { implementation(project(":llama")); implementation("androidx.core:core-ktx:1.17.0"); implementation("androidx.activity:activity-ktx:1.12.2"); implementation("androidx.appcompat:appcompat:1.7.1"); implementation("com.google.android.material:material:1.13.0") }
