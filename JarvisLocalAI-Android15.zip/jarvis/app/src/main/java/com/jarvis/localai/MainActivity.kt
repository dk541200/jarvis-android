package com.jarvis.localai

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import com.arm.aichat.gguf.GgufMetadataReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var modelName: TextView
    private lateinit var modelStatus: TextView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var send: Button
    private var engine: InferenceEngine? = null
    private var generationJob: Job? = null
    private val requestPermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        if (granted[Manifest.permission.RECORD_AUDIO] == true) startJarvis(JarvisService.ACTION_ACTIVE) else Toast.makeText(this, "Microphone permission is required for Hey Jarvis.", Toast.LENGTH_LONG).show()
    }
    private val modelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) importAndLoad(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status); modelName = findViewById(R.id.modelName); modelStatus = findViewById(R.id.modelStatus); chat = findViewById(R.id.chat); input = findViewById(R.id.input); send = findViewById(R.id.send)
        findViewById<Button>(R.id.active).setOnClickListener { ensurePermissionsAndStart() }
        findViewById<Button>(R.id.sleep).setOnClickListener { startJarvis(JarvisService.ACTION_SLEEP) }
        findViewById<Button>(R.id.off).setOnClickListener { startJarvis(JarvisService.ACTION_OFF) }
        findViewById<Button>(R.id.pickModel).setOnClickListener { modelPicker.launch(arrayOf("application/octet-stream", "*/*")) }
        send.setOnClickListener { sendPrompt() }
        lifecycleScope.launch(Dispatchers.Default) { engine = AiChat.getInferenceEngine(applicationContext) }
        updateStatusFromPrefs()
    }

    private fun ensurePermissionsAndStart() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) needed += Manifest.permission.RECORD_AUDIO
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) needed += Manifest.permission.POST_NOTIFICATIONS
        if (needed.isEmpty()) startJarvis(JarvisService.ACTION_ACTIVE) else requestPermissions.launch(needed.toTypedArray())
    }

    private fun startJarvis(action: String) {
        if (action == JarvisService.ACTION_ACTIVE && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) { ensurePermissionsAndStart(); return }
        val intent = Intent(this, JarvisService::class.java).setAction(action)
        if (android.os.Build.VERSION.SDK_INT >= 26 && action != JarvisService.ACTION_OFF) startForegroundService(intent) else startService(intent)
        updateStatusFromPrefs(action)
    }

    private fun updateStatusFromPrefs(action: String? = null) {
        val s = action ?: getSharedPreferences("jarvis_state", MODE_PRIVATE).getString("state", "OFF")
        status.text = "STATUS: " + when (s) { JarvisService.ACTION_ACTIVE, "ACTIVE" -> "ACTIVE"; JarvisService.ACTION_SLEEP, "SLEEP" -> "SLEEPING"; else -> "OFF" }
    }

    private fun importAndLoad(uri: Uri) {
        modelStatus.text = "Model status: validating GGUF..."
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                contentResolver.openInputStream(uri)?.use { GgufMetadataReader.create().readStructuredMetadata(it) } ?: error("Unable to read selected file")
                val models = File(filesDir, "models").apply { mkdirs() }
                val target = File(models, "jarvis-model.gguf")
                contentResolver.openInputStream(uri)?.use { inputStream -> FileOutputStream(target).use { output -> inputStream.copyTo(output) } } ?: error("Unable to copy model")
                withContext(Dispatchers.Main) { modelName.text = target.name; modelStatus.text = "Model status: loading..." }
                val e = engine ?: withContext(Dispatchers.Default) { AiChat.getInferenceEngine(applicationContext).also { engine = it } }
                e.loadModel(target.absolutePath)
                withContext(Dispatchers.Main) { modelStatus.text = "Model status: READY"; appendChat("SYSTEM", "GGUF model loaded and ready.") }
            } catch (t: Throwable) { withContext(Dispatchers.Main) { modelStatus.text = "Model error: ${t.message ?: t.javaClass.simpleName}" } }
        }
    }

    private fun sendPrompt() {
        val prompt = input.text.toString().trim(); if (prompt.isEmpty()) return
        input.text = ""; send.isEnabled = false; appendChat("YOU", prompt)
        generationJob?.cancel()
        generationJob = lifecycleScope.launch(Dispatchers.Default) {
            try {
                val e = engine ?: error("Load a GGUF model first")
                val out = StringBuilder()
                e.sendUserPrompt(prompt).collect { token -> out.append(token); withContext(Dispatchers.Main) { chat.text = chat.text.toString() + token } }
            } catch (t: Throwable) { withContext(Dispatchers.Main) { appendChat("JARVIS", "Error: ${t.message ?: t.javaClass.simpleName}") } }
            finally { withContext(Dispatchers.Main) { send.isEnabled = true } }
        }
    }

    private fun appendChat(who: String, text: String) { chat.append("\n$who: $text\n") }
    override fun onDestroy() { generationJob?.cancel(); engine?.destroy(); super.onDestroy() }
}
