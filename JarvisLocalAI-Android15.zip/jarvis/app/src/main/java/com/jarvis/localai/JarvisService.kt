package com.jarvis.localai

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.Locale

class JarvisService : Service() {
    enum class State { ACTIVE, SLEEP, OFF }
    private val handler = Handler(Looper.getMainLooper())
    private var state = State.ACTIVE
    private var recognition: SpeechRecognizer? = null
    private var listening = false
    private var commandMode = false
    private var retryCount = 0
    private var tts: TextToSpeech? = null
    private var lastCommandAt = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
        state = loadState()
        startForeground(NOTIFICATION_ID, buildNotification())
        setupRecognizer()
        applyState()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ACTIVE -> setState(State.ACTIVE)
            ACTION_SLEEP -> setState(State.SLEEP)
            ACTION_OFF -> { saveState(State.OFF); stopListening(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
            else -> if (state == State.OFF) setState(State.ACTIVE)
        }
        return START_STICKY
    }

    private fun setState(newState: State) {
        state = newState
        saveState(newState)
        commandMode = false
        retryCount = 0
        applyState()
    }

    private fun applyState() {
        updateNotification()
        if (state == State.ACTIVE) scheduleListen(200) else stopListening()
    }

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognition?.destroy()
        recognition = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening = true }
                override fun onBeginningOfSpeech() { retryCount = 0 }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false }
                override fun onError(error: Int) {
                    listening = false
                    if (state == State.ACTIVE && retryCount < 4) {
                        retryCount++
                        scheduleListen((500L * retryCount).coerceAtMost(2500L))
                    } else if (state == State.ACTIVE) {
                        retryCount = 0
                        scheduleListen(2500)
                    }
                }
                override fun onResults(results: Bundle?) {
                    listening = false
                    retryCount = 0
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                    if (text.isBlank() || state != State.ACTIVE) return
                    if (commandMode) {
                        commandMode = false
                        executeCommand(text)
                        scheduleListen(900)
                    } else if (containsWakePhrase(text)) {
                        commandMode = true
                        speak("Yes?")
                        scheduleListen(650)
                    } else {
                        scheduleListen(250)
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun scheduleListen(delay: Long) {
        handler.removeCallbacksAndMessages(LISTEN_TOKEN)
        if (state != State.ACTIVE || listening) return
        handler.postAtTime({ startListening() }, LISTEN_TOKEN, SystemClock.uptimeMillis() + delay)
    }

    private fun startListening() {
        if (state != State.ACTIVE || listening) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (recognition == null) setupRecognizer()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try { recognition?.startListening(intent) } catch (_: Exception) { listening = false; scheduleListen(1500) }
    }

    private fun stopListening() {
        handler.removeCallbacksAndMessages(LISTEN_TOKEN)
        try { recognition?.cancel() } catch (_: Exception) {}
        listening = false
    }

    private fun containsWakePhrase(text: String): Boolean {
        val n = text.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
        return n.contains("hey jarvis") || n.contains("hey jarvis") || n == "jarvis" || n.startsWith("jarvis ")
    }

    private fun executeCommand(raw: String) {
        val text = raw.lowercase(Locale.ROOT).trim()
        if (text.startsWith("open ")) {
            val requested = raw.trim().substringAfter(" ").trim()
            val opened = launchInstalledApp(requested)
            speak(if (opened) "Opening $requested" else "I could not find $requested")
        } else {
            speak("Command received")
        }
    }

    private fun launchInstalledApp(requested: String): Boolean {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        val target = requested.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]"), "")
        val match = apps.firstOrNull { info ->
            val label = info.loadLabel(pm).toString().lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]"), "")
            label == target || label.contains(target) || target.contains(label)
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try { startActivity(launch); true } catch (_: Exception) { false }
    }

    private fun speak(text: String) { if (tts?.isSpeaking == true) tts?.stop(); tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.nanoTime()}") }

    private fun buildNotification(): Notification {
        val title = when (state) { State.ACTIVE -> "🟢 JARVIS ACTIVE"; State.SLEEP -> "💤 JARVIS SLEEPING"; State.OFF -> "🔴 JARVIS OFF" }
        val body = if (state == State.ACTIVE) "Listening for Hey Jarvis" else "Light standby — microphone idle"
        return NotificationCompat.Builder(this, CHANNEL_ID).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle(title).setContentText(body).setOngoing(true).setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(NotificationCompat.Action.Builder(0, "🟢 JARVIS ACTIVE", action(ACTION_ACTIVE)).build())
            .addAction(NotificationCompat.Action.Builder(0, "💤 JARVIS SLEEPING", action(ACTION_SLEEP)).build())
            .addAction(NotificationCompat.Action.Builder(0, "🔴 JARVIS OFF", action(ACTION_OFF)).build()).build()
    }

    private fun action(action: String): PendingIntent = PendingIntent.getService(this, action.hashCode(), Intent(this, JarvisService::class.java).setAction(action), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    private fun updateNotification() { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification()) }
    private fun createChannel() { getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL_ID, "JARVIS", NotificationManager.IMPORTANCE_LOW)) }
    private fun saveState(s: State) { getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_STATE, s.name).apply() }
    private fun loadState(): State = runCatching { State.valueOf(getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_STATE, State.ACTIVE.name)!!) }.getOrDefault(State.ACTIVE)

    override fun onDestroy() { stopListening(); recognition?.destroy(); recognition = null; tts?.stop(); tts?.shutdown(); handler.removeCallbacksAndMessages(null); super.onDestroy() }
    override fun onBind(intent: Intent?) = null

    companion object {
        const val ACTION_ACTIVE = "com.jarvis.localai.ACTIVE"
        const val ACTION_SLEEP = "com.jarvis.localai.SLEEP"
        const val ACTION_OFF = "com.jarvis.localai.OFF"
        private const val CHANNEL_ID = "jarvis_service"
        private const val NOTIFICATION_ID = 7001
        private const val PREFS = "jarvis_state"
        private const val KEY_STATE = "state"
        private val LISTEN_TOKEN = Any()
    }
}
