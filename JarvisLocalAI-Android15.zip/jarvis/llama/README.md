# llama.cpp Android binding staging directory

The build workflow replaces this directory with the official `examples/llama.android/lib` module from the pinned llama.cpp `b10516` tag and also fetches the corresponding llama.cpp source under `third_party/llama.cpp`.
