package com.jarvis.android

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var statusDot: View
    private lateinit var chatContainer: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var send: TextView
    private lateinit var voice: TextView
    private lateinit var agentBadge: TextView

    private var engine: InferenceEngine? = null
    private var generationJob: Job? = null
    private var modelReady = false
    private var voiceEnabled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(2, 6, 12)
        window.navigationBarColor = Color.rgb(2, 6, 12)
        requestMicPermissionIfNeeded()
        buildUi()
        renderHistory()
        initializeJarvis()
        handleIncomingVoiceIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingVoiceIntent(intent)
    }

    private fun handleIncomingVoiceIntent(intent: Intent?) {
        val voiceText = intent?.getStringExtra("jarvis_voice_text")?.trim().orEmpty()
        if (voiceText.isNotEmpty()) {
            input.post {
                input.setText(voiceText)
                if (modelReady) sendPrompt()
            }
            intent?.removeExtra("jarvis_voice_text")
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(2, 6, 12), Color.rgb(4, 15, 25), Color.rgb(2, 7, 14)))
        }

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "JARVIS"
            textSize = 24f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.WHITE)
            letterSpacing = .18f
        }
        top.addView(brand, LinearLayout.LayoutParams(0, dp(48), 1f))
        agentBadge = badge("CORE • LOCAL")
        top.addView(agentBadge, LinearLayout.LayoutParams(-2, dp(32)))
        root.addView(top)

        val statusRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), dp(8))
        }
        statusDot = View(this).apply { background = circle(Color.rgb(255, 185, 70)) }
        statusRow.addView(statusDot, LinearLayout.LayoutParams(dp(8), dp(8)))
        status = TextView(this).apply {
            text = "LOADING LOCAL BRAIN"
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(125, 158, 178))
            letterSpacing = .1f
            setPadding(dp(8), 0, 0, 0)
        }
        statusRow.addView(status)
        root.addView(statusRow)

        val tools = LinearLayout(this).apply { setPadding(0, dp(2), 0, dp(10)) }
        tools.addView(chip("HISTORY") { showHistoryPanel() }, chipParams())
        tools.addView(chip("NEW CHAT") {
            generationJob?.cancel()
            ChatStore.newSession(this@MainActivity)
            renderHistory()
            input.requestFocus()
        }, chipParams())
        voice = chip("VOICE OFF") { toggleVoice() }
        tools.addView(voice, chipParams())
        root.addView(tools)

        val section = TextView(this).apply {
            text = "CONVERSATION  •  LOCAL SESSION"
            textSize = 9.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(82, 137, 160))
            letterSpacing = .13f
            setPadding(dp(4), 0, 0, dp(7))
        }
        root.addView(section)

        chatScroll = ScrollView(this).apply {
            isFillViewport = true
            background = rounded(Color.argb(24, 80, 190, 210), Color.argb(60, 55, 150, 165), dp(18).toFloat())
            setPadding(dp(8), dp(7), dp(8), dp(7))
        }
        chatContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        chatScroll.addView(chatContainer, ViewGroup.LayoutParams(-1, -2))
        root.addView(chatScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val composer = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0) }
        input = EditText(this).apply {
            hint = "Message JARVIS…"
            textSize = 15f
            maxLines = 5
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(78, 108, 125))
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = rounded(Color.rgb(6, 17, 29), Color.rgb(25, 87, 103), dp(17).toFloat())
            isEnabled = false
        }
        composer.addView(input, LinearLayout.LayoutParams(0, dp(56), 1f))
        send = TextView(this).apply {
            text = "➤"
            textSize = 21f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(1, 12, 16))
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(74, 239, 214)) }
            isEnabled = false
            setOnClickListener { sendPrompt() }
        }
        composer.addView(send, LinearLayout.LayoutParams(dp(56), dp(56)).apply { leftMargin = dp(9) })
        root.addView(composer)
        setContentView(root)
    }

    private fun renderHistory(liveAssistant: String? = null) {
        val items = ChatStore.current(this)
        chatContainer.removeAllViews()
        if (items.isEmpty() && liveAssistant == null) {
            val empty = TextView(this).apply {
                text = "JARVIS CORE READY\n\nTalk naturally. I can route commands, remember local facts, and use the offline model for normal conversation."
                textSize = 14f
                setTextColor(Color.rgb(132, 165, 184))
                setPadding(dp(10), dp(28), dp(10), dp(28))
            }
            chatContainer.addView(empty)
        } else {
            items.forEach { addMessage(it.role, it.text) }
            if (liveAssistant != null) addMessage("JARVIS", liveAssistant)
        }
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addMessage(role: String, text: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (role == "YOU") Gravity.END else Gravity.START
            setPadding(dp(3), dp(5), dp(3), dp(5))
        }
        val label = TextView(this).apply {
            this.text = if (role == "YOU") "YOU" else "JARVIS"
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (role == "YOU") Color.rgb(76, 203, 245) else Color.rgb(70, 232, 190))
            letterSpacing = .14f
        }
        row.addView(label)

        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(10), dp(13), dp(8))
            background = if (role == "YOU") rounded(Color.rgb(7, 36, 49), Color.rgb(20, 104, 128), dp(16).toFloat())
            else rounded(Color.rgb(8, 25, 29), Color.rgb(28, 103, 91), dp(16).toFloat())
        }
        addFormattedContent(bubble, text.ifBlank { "…" })
        val copy = TextView(this).apply {
            this.text = "COPY"
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(90, 180, 190))
            setPadding(0, dp(7), 0, 0)
            setOnClickListener { copyText(text); Toast.makeText(this@MainActivity, "Copied", Toast.LENGTH_SHORT).show() }
        }
        bubble.addView(copy)
        row.addView(bubble, LinearLayout.LayoutParams(dp(320), -2).apply { topMargin = dp(4) })
        chatContainer.addView(row)
    }

    private fun addFormattedContent(container: LinearLayout, text: String) {
        val parts = text.split("```")
        parts.forEachIndexed { index, part ->
            if (part.isEmpty()) return@forEachIndexed
            if (index % 2 == 1) {
                var code = part
                if (code.startsWith("kotlin\n")) code = code.removePrefix("kotlin\n")
                if (code.startsWith("java\n")) code = code.removePrefix("java\n")
                if (code.startsWith("python\n")) code = code.removePrefix("python\n")
                val codeBox = TextView(this).apply {
                    this.text = code.trimEnd()
                    textSize = 12.5f
                    typeface = Typeface.MONOSPACE
                    setTextColor(Color.rgb(205, 244, 238))
                    setTextIsSelectable(true)
                    setPadding(dp(10), dp(9), dp(10), dp(9))
                    background = rounded(Color.rgb(3, 12, 18), Color.rgb(31, 88, 91), dp(10).toFloat())
                }
                container.addView(codeBox)
                val copyCode = TextView(this).apply {
                    text = "COPY CODE"
                    textSize = 9f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.rgb(83, 203, 183))
                    setPadding(0, dp(4), 0, dp(5))
                    setOnClickListener { copyText(code); Toast.makeText(this@MainActivity, "Code copied", Toast.LENGTH_SHORT).show() }
                }
                container.addView(copyCode)
            } else {
                val body = TextView(this).apply {
                    this.text = formatSimpleMarkdown(part.trim())
                    textSize = 14.5f
                    setTextColor(Color.rgb(232, 244, 248))
                    setTextIsSelectable(true)
                    setPadding(0, dp(1), 0, dp(1))
                }
                container.addView(body)
            }
        }
    }

    private fun formatSimpleMarkdown(raw: String): String {
        return raw.lines().joinToString("\n") { line ->
            when {
                line.startsWith("### ") -> "▸ " + line.removePrefix("### ").uppercase()
                line.startsWith("## ") -> "▸ " + line.removePrefix("## ").uppercase()
                line.startsWith("# ") -> "▸ " + line.removePrefix("# ").uppercase()
                line.startsWith("- ") -> "• " + line.removePrefix("- ")
                line.startsWith("* ") -> "• " + line.removePrefix("* ")
                else -> line
            }
        }
    }

    private fun showHistoryPanel() {
        val sessions = ChatStore.sessions(this)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = rounded(Color.rgb(5, 14, 23), Color.rgb(30, 92, 103), dp(20).toFloat())
        }
        val title = TextView(this).apply {
            text = "JARVIS HISTORY"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            letterSpacing = .08f
            setPadding(0, 0, 0, dp(10))
        }
        panel.addView(title)
        if (sessions.isEmpty()) {
            panel.addView(TextView(this).apply { text = "No conversations yet."; setTextColor(Color.LTGRAY) })
        } else {
            sessions.forEach { session ->
                val item = TextView(this).apply {
                    val date = SimpleDateFormat("dd MMM • HH:mm", Locale.getDefault()).format(Date(session.updated))
                    text = "${session.title}\n$date"
                    textSize = 13.5f
                    setTextColor(Color.rgb(220, 239, 242))
                    setPadding(dp(12), dp(11), dp(12), dp(11))
                    background = rounded(Color.rgb(8, 24, 34), Color.rgb(24, 67, 78), dp(13).toFloat())
                    setOnClickListener {
                        ChatStore.selectSession(this@MainActivity, session.id)
                        (tag as? android.app.Dialog)?.dismiss()
                        renderHistory()
                    }
                    tag = null
                }
                panel.addView(item, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            }
        }
        val dialog = android.app.Dialog(this)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setContentView(panel)
        dialog.setTitle(null)
        panel.children().forEach { it.tag = dialog }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * .9f).toInt(), -2)
    }

    private fun toggleVoice() {
        if (!hasMicPermission()) { requestMicPermissionIfNeeded(); return }
        if (!voiceEnabled) {
            ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_ON))
            voiceEnabled = true
            voice.text = "VOICE ON"
            status.text = "VOICE CORE • STANDBY"
        } else {
            startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_SLEEP))
            voiceEnabled = false
            voice.text = "VOICE OFF"
            status.text = if (modelReady) "JARVIS ONLINE • OFFLINE" else "LOADING LOCAL BRAIN"
        }
    }

    private fun sendPrompt() {
        if (!modelReady) return
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        generationJob?.cancel()
        input.setText("")

        val command = JarvisCommandRouter.handle(this, prompt)
        if (command.handled) {
            ChatStore.add(this, "YOU", prompt)
            ChatStore.add(this, "JARVIS", command.reply)
            agentBadge.text = "COMMAND AGENT"
            renderHistory()
            return
        }

        val localEngine = engine ?: return
        input.isEnabled = false
        send.isEnabled = false
        ChatStore.add(this, "YOU", prompt)
        ChatStore.add(this, "JARVIS", "")
        renderHistory()

        val recent = ChatStore.current(this).dropLast(1).takeLast(8)
            .joinToString("\n") { "${it.role}: ${it.text}" }
        val agent = AgentRouter.choose(this, prompt)
        agentBadge.text = when (agent) {
            AgentRouter.Agent.CODE -> "CODE AGENT"
            AgentRouter.Agent.STUDY -> "STUDY AGENT"
            AgentRouter.Agent.WEB -> "WEB AGENT"
            AgentRouter.Agent.MEMORY -> "MEMORY AGENT"
            AgentRouter.Agent.COMMAND -> "COMMAND AGENT"
            AgentRouter.Agent.LOCAL -> "LOCAL AI"
        }
        val modelPrompt = JarvisCommandRouter.agentPrompt(this, prompt, recent)

        generationJob = lifecycleScope.launch(Dispatchers.Default) {
            val builder = StringBuilder()
            try {
                localEngine.sendUserPrompt(modelPrompt).collect { token ->
                    builder.append(token)
                    withContext(Dispatchers.Main) { renderHistory(builder.toString()) }
                }
            } finally {
                ChatStore.replaceLastAssistant(this@MainActivity, builder.toString().trim())
                withContext(Dispatchers.Main) {
                    input.isEnabled = true
                    send.isEnabled = true
                    renderHistory()
                }
            }
        }
    }

    private fun initializeJarvis() {
        lifecycleScope.launch(Dispatchers.Default) {
            try {
                withContext(Dispatchers.Main) { status.text = "INITIALIZING LOCAL BRAIN" }
                val localEngine = AiChat.getInferenceEngine(applicationContext)
                engine = localEngine
                localEngine.state.first { it is InferenceEngine.State.Initialized || it is InferenceEngine.State.Error }
                if (localEngine.state.value is InferenceEngine.State.Error) error("AI engine initialization failed")
                withContext(Dispatchers.Main) { status.text = "LOADING OFFLINE MODEL" }
                val modelFile = copyBundledModel()
                localEngine.loadModel(modelFile.absolutePath)
                withContext(Dispatchers.Main) {
                    modelReady = true
                    status.text = "JARVIS ONLINE • OFFLINE"
                    statusDot.background = circle(Color.rgb(72, 245, 218))
                    input.isEnabled = true
                    send.isEnabled = true
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    modelReady = false
                    input.isEnabled = false
                    send.isEnabled = false
                    status.text = "LOCAL BRAIN ERROR"
                    statusDot.background = circle(Color.rgb(255, 80, 100))
                    chatContainer.removeAllViews()
                    addMessage("JARVIS", "Could not load the local model.\n\n${t.javaClass.simpleName}: ${t.message ?: "Unknown error"}")
                }
            }
        }
    }

    private suspend fun copyBundledModel(): File = withContext(Dispatchers.IO) {
        val dir = File(filesDir, "models").apply { mkdirs() }
        val model = File(dir, MODEL_FILE_NAME)
        if (model.exists() && model.length() > MIN_MODEL_BYTES) return@withContext model
        val temp = File(dir, ".${MODEL_FILE_NAME}.part")
        if (temp.exists()) temp.delete()
        assets.open(MODEL_FILE_NAME).use { input ->
            FileOutputStream(temp).use { output ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count <= 0) break
                    output.write(buffer, 0, count)
                }
                output.fd.sync()
            }
        }
        if (temp.length() <= MIN_MODEL_BYTES) error("Bundled GGUF model is missing or incomplete")
        if (model.exists()) model.delete()
        if (!temp.renameTo(model)) temp.copyTo(model, overwrite = true).also { temp.delete() }
        model
    }

    private fun copyText(value: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("JARVIS", value))
    }

    private fun requestMicPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun hasMicPermission() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun chipParams() = LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(7) }

    private fun chip(text: String, action: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 10f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        letterSpacing = .06f
        setTextColor(Color.rgb(185, 226, 232))
        background = rounded(Color.rgb(6, 18, 29), Color.rgb(27, 73, 88), dp(13).toFloat())
        setOnClickListener { if (isEnabled) action() }
    }

    private fun badge(text: String) = TextView(this).apply {
        this.text = text
        textSize = 8.5f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        letterSpacing = .06f
        setTextColor(Color.rgb(83, 230, 202))
        background = rounded(Color.rgb(6, 28, 31), Color.rgb(35, 115, 103), dp(20).toFloat())
        setPadding(dp(10), 0, dp(10), 0)
    }

    private fun rounded(fill: Int, stroke: Int, radius: Float) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radius
        setColor(fill)
        setStroke(dp(1), stroke)
    }

    private fun circle(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        generationJob?.cancel()
        try { engine?.cleanUp() } catch (_: Throwable) {}
        super.onDestroy()
    }

    companion object {
        private const val MODEL_FILE_NAME = "Llama-3.2-1B-Instruct-Q4_0.gguf"
        private const val MIN_MODEL_BYTES = 700L * 1024L * 1024L
    }
}

private fun ViewGroup.children(): List<View> = (0 until childCount).map { getChildAt(it) }
