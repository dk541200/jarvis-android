package com.jarvis.android

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object ChatStore {
    data class Item(val role: String, val text: String)
    data class Session(val id: String, val title: String, val updated: Long, val items: List<Item>)

    private const val PREFS = "jarvis_chat"
    private const val KEY = "sessions"
    private const val CURRENT = "current_session"
    private const val MAX_MESSAGES = 200

    @JvmStatic
    fun add(context: Context, role: String, text: String) {
        val sessions = readSessions(context).toMutableList()
        val currentId = ensureCurrentId(context, sessions)
        val index = sessions.indexOfFirst { it.id == currentId }
        if (index < 0) return
        val old = sessions[index]
        val items = (old.items + Item(role, text)).takeLast(MAX_MESSAGES)
        val title = if (old.title == "New conversation" && role == "YOU") {
            text.trim().replace("\\s+".toRegex(), " ").take(42).ifBlank { old.title }
        } else old.title
        sessions[index] = old.copy(title = title, updated = System.currentTimeMillis(), items = items)
        writeSessions(context, sessions)
    }

    @JvmStatic
    fun replaceLastAssistant(context: Context, text: String) {
        val sessions = readSessions(context).toMutableList()
        val currentId = ensureCurrentId(context, sessions)
        val index = sessions.indexOfFirst { it.id == currentId }
        if (index < 0) return
        val items = sessions[index].items.toMutableList()
        val itemIndex = items.indexOfLast { it.role == "JARVIS" }
        if (itemIndex >= 0) items[itemIndex] = Item("JARVIS", text)
        sessions[index] = sessions[index].copy(updated = System.currentTimeMillis(), items = items.takeLast(MAX_MESSAGES))
        writeSessions(context, sessions)
    }

    @JvmStatic
    fun newSession(context: Context): String {
        val sessions = readSessions(context).toMutableList()
        val id = UUID.randomUUID().toString()
        sessions.add(Session(id, "New conversation", System.currentTimeMillis(), emptyList()))
        writeSessions(context, sessions)
        setCurrentId(context, id)
        return id
    }

    @JvmStatic
    fun current(context: Context): List<Item> {
        val sessions = readSessions(context)
        val id = ensureCurrentId(context, sessions)
        return sessions.firstOrNull { it.id == id }?.items ?: emptyList()
    }

    @JvmStatic
    fun sessions(context: Context): List<Session> = readSessions(context).sortedByDescending { it.updated }

    @JvmStatic
    fun selectSession(context: Context, id: String) {
        if (readSessions(context).any { it.id == id }) setCurrentId(context, id)
    }

    @JvmStatic
    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        newSession(context)
    }

    fun read(context: Context): List<Item> = current(context)

    private fun ensureCurrentId(context: Context, sessions: List<Session>): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = prefs.getString(CURRENT, null)
        if (saved != null && sessions.any { it.id == saved }) return saved
        if (sessions.isNotEmpty()) {
            val id = sessions.maxByOrNull { it.updated }!!.id
            setCurrentId(context, id)
            return id
        }
        return newSession(context)
    }

    private fun setCurrentId(context: Context, id: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(CURRENT, id).apply()
    }

    private fun readSessions(context: Context): List<Session> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val array = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        return buildList {
            for (i in 0 until array.length()) {
                val s = array.optJSONObject(i) ?: continue
                val messages = s.optJSONArray("messages") ?: JSONArray()
                val items = buildList {
                    for (j in 0 until messages.length()) {
                        val m = messages.optJSONObject(j) ?: continue
                        add(Item(m.optString("role"), m.optString("text")))
                    }
                }
                add(Session(
                    s.optString("id"),
                    s.optString("title", "New conversation"),
                    s.optLong("updated", 0L),
                    items
                ))
            }
        }
    }

    private fun writeSessions(context: Context, sessions: List<Session>) {
        val array = JSONArray()
        sessions.takeLast(30).forEach { session ->
            val messages = JSONArray()
            session.items.takeLast(MAX_MESSAGES).forEach { item ->
                messages.put(JSONObject().put("role", item.role).put("text", item.text))
            }
            array.put(JSONObject()
                .put("id", session.id)
                .put("title", session.title)
                .put("updated", session.updated)
                .put("messages", messages))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }
}
