package com.jarvis.android

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.regex.Pattern

object JarvisCommandRouter {
    data class Result(val handled: Boolean, val reply: String = "")

    fun handle(context: Context, raw: String): Result {
        val text = raw.trim()
        val n = normalize(text)
        if (n.isEmpty()) return Result(false)

        val rememberName = Regex("^(my name is|mera naam hai)\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)
        if (rememberName != null) {
            val name = rememberName.groupValues[2].trim().trimEnd('.', '!')
            JarvisMemory.setName(context, name)
            return Result(true, "Got it. I'll remember that your name is $name.")
        }
        if (n == "what is my name" || n == "whats my name" || n == "mera naam kya hai") {
            val name = JarvisMemory.getName(context)
            return Result(true, if (name == null) "You haven't told me your name yet." else "Your name is $name.")
        }
        val remember = Regex("^(remember|yaad rakhna|yaad rakho)\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)
        if (remember != null) {
            val fact = remember.groupValues[2].trim()
            JarvisMemory.remember(context, fact)
            return Result(true, "Saved to local JARVIS memory.")
        }

        if (n == "what time is it" || n == "time kya hai" || n == "time") {
            return Result(true, "It is ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())}.")
        }
        if (n == "what is the date" || n == "todays date" || n == "aaj ki date") {
            return Result(true, SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()))
        }
        if (n.contains("battery") && (n.contains("status") || n.contains("percent") || n.contains("kitni"))) {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            return Result(true, "Battery is at $level percent.")
        }

        if (n == "open settings" || n == "settings kholo" || n == "phone settings") {
            context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return Result(true, "Opening Settings.")
        }
        if (n.contains("volume up") || n.contains("volume badhao") || n.contains("increase volume")) {
            val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audio.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            return Result(true, "Volume increased.")
        }
        if (n.contains("volume down") || n.contains("volume kam") || n.contains("decrease volume")) {
            val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audio.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            return Result(true, "Volume decreased.")
        }

        val timer = Regex("(?:set|start)\\s+(?:a\\s+)?timer\\s+(?:for\\s+)?(\\d+)\\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)", RegexOption.IGNORE_CASE).find(text)
        if (timer != null) {
            val value = timer.groupValues[1].toIntOrNull() ?: 0
            val unit = timer.groupValues[2].lowercase(Locale.ROOT)
            val seconds = when {
                unit.startsWith("hour") || unit.startsWith("hr") -> value * 3600
                unit.startsWith("minute") || unit.startsWith("min") -> value * 60
                else -> value
            }
            if (seconds > 0) {
                val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                    putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return Result(true, "Setting a $value ${timer.groupValues[2]} timer.")
            }
        }

        val openMatch = Regex("^(open|launch|start|khol|kholo)\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)
        if (openMatch != null) {
            val target = normalize(openMatch.groupValues[2])
            val app = APP_ALIASES.firstOrNull { target == it.alias || target.contains(it.alias) }
            if (app != null) return Result(true, openApp(context, app))
        }

        val search = Regex("^(search|google|find|youtube search|youtube par search)\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)
        if (search != null) {
            val query = search.groupValues[2].trim()
            val url = "https://www.google.com/search?q=" + java.net.URLEncoder.encode(query, "UTF-8")
            context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return Result(true, "Searching for $query.")
        }

        return Result(false)
    }

    fun agentPrompt(context: Context, user: String, recent: String): String {
        val memory = JarvisMemory.summary(context)
        val lower = normalize(user)
        val agent = when {
            lower.contains("code") || lower.contains("program") || lower.contains("kotlin") || lower.contains("java") || lower.contains("python") -> "CODE AGENT"
            lower.contains("study") || lower.contains("homework") || lower.contains("math") || lower.contains("physics") || lower.contains("chemistry") -> "STUDY AGENT"
            lower.contains("internet") || lower.contains("web") || lower.contains("latest") || lower.contains("search") -> "WEB AGENT"
            else -> "LOCAL AI AGENT"
        }
        return """
You are JARVIS, a helpful personal local AI assistant. You are currently acting as the $agent.
Be natural, concise but useful. Understand the user's intent and context instead of replying with generic filler.
If the user gives their name or a personal fact, acknowledge it naturally. Do not claim internet access unless a web tool actually supplied information.
Use Markdown when useful. For code, ALWAYS put code inside triple-backtick code blocks and explain it briefly outside the block.
Local memory:
${memory.ifBlank { "No saved memory yet." }}
Recent conversation:
${recent.ifBlank { "No previous messages." }}

User:
$user
""".trimIndent()
    }

    private fun openApp(context: Context, app: AppAlias): String {
        for (pkg in app.packages) {
            val launch = context.packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                context.startActivity(launch)
                return "Opening ${app.label}."
            }
        }
        return "${app.label} is not installed on this phone."
    }

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9 ]"), " ")
        .replace(Regex("\\s+"), " ").trim()

    private data class AppAlias(val alias: String, val label: String, val packages: List<String>)
    private val APP_ALIASES = listOf(
        AppAlias("youtube", "YouTube", listOf("com.google.android.youtube")),
        AppAlias("whatsapp", "WhatsApp", listOf("com.whatsapp", "com.whatsapp.w4b")),
        AppAlias("instagram", "Instagram", listOf("com.instagram.android")),
        AppAlias("chrome", "Chrome", listOf("com.android.chrome")),
        AppAlias("facebook", "Facebook", listOf("com.facebook.katana")),
        AppAlias("telegram", "Telegram", listOf("org.telegram.messenger")),
        AppAlias("maps", "Maps", listOf("com.google.android.apps.maps")),
        AppAlias("spotify", "Spotify", listOf("com.spotify.music")),
        AppAlias("gmail", "Gmail", listOf("com.google.android.gm"))
    )
}
