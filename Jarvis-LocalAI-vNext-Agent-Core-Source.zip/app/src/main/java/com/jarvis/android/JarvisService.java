package com.jarvis.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.widget.RemoteViews;

import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.Locale;

public class JarvisService extends Service {
    public static final String ACTION_ON = "com.jarvis.android.action.ON";
    public static final String ACTION_SLEEP = "com.jarvis.android.action.SLEEP";
    public static final String ACTION_OFF = "com.jarvis.android.action.OFF";

    private static final int NOTIFICATION_ID = 1;
    private static final String CHANNEL_ID = "jarvis_core_v2";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean active = false;
    private boolean listening = false;
    private boolean commandWindow = false;
    private boolean restarting = false;
    private boolean ttsReady = false;
    private boolean wakeTriggered = false;
    private String lastStatus = "READY";

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) {
                tts.setLanguage(Locale.getDefault());
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { }
                    @Override public void onDone(String utteranceId) { startRecognitionSoon(250); }
                    @Override public void onError(String utteranceId) { startRecognitionSoon(250); }
                });
            }
        });
        startForeground(NOTIFICATION_ID, buildNotification("STANDBY • TAP TO OPEN"));
        createRecognizer();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_ON : intent.getAction();
        if (ACTION_OFF.equals(action)) {
            active = false;
            wakeTriggered = false;
            commandWindow = false;
            stopRecognizer();
            if (tts != null) { try { tts.stop(); } catch (Exception ignored) {} }
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_SLEEP.equals(action)) {
            active = false;
            wakeTriggered = false;
            commandWindow = false;
            stopRecognizer();
            updateNotification("PAUSED • MIC OFF");
            return START_NOT_STICKY;
        }
        active = true;
        commandWindow = false;
        updateNotification("LISTENING FOR HEY JARVIS");
        startRecognitionSoon(350);
        return START_STICKY;
    }

    private boolean canRecognize() {
        return Build.VERSION.SDK_INT < 23 ||
                (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                        && SpeechRecognizer.isRecognitionAvailable(this));
    }

    private void createRecognizer() {
        if (!canRecognize()) return;
        try { recognizer = SpeechRecognizer.createSpeechRecognizer(this); } catch (Exception e) { recognizer = null; return; }
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { listening = true; updateNotification(commandWindow ? "LISTENING • COMMAND" : "STANDBY • HEY JARVIS"); }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { listening = false; }
            @Override public void onPartialResults(Bundle partialResults) {
                if (active && !commandWindow && !wakeTriggered && containsWakeWord(partialResults)) {
                    String text = bestResult(partialResults);
                    String command = stripWakeWord(text);
                    wakeTriggered = true;
                    stopRecognition();
                    if (!command.isEmpty()) handleRecognizedCommand(command);
                    else { commandWindow = true; speak("Yes?"); }
                }
            }
            @Override public void onResults(Bundle results) {
                listening = false;
                if (!active) return;
                String text = bestResult(results);
                if (commandWindow) {
                    commandWindow = false;
                    handleRecognizedCommand(stripWakeWord(text).isEmpty() ? text : stripWakeWord(text));
                } else if (containsWakeWord(results)) {
                    if (wakeTriggered) { wakeTriggered = false; startRecognitionSoon(250); return; }
                    String command = stripWakeWord(text);
                    wakeTriggered = true;
                    stopRecognition();
                    if (!command.isEmpty()) handleRecognizedCommand(command);
                    else {
                        commandWindow = true;
                        speak("Yes?");
                    }
                } else {
                    startRecognitionSoon(180);
                }
            }
            @Override public void onError(int error) {
                listening = false;
                if (!active) return;
                startRecognitionSoon(error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 900 : 350);
            }
            @Override public void onEvent(int eventType, Bundle params) { }
        });
    }

    private void startRecognitionSoon(long delay) {
        if (!active || restarting || listening) return;
        handler.postDelayed(() -> {
            if (!active || listening) return;
            restarting = false;
            startRecognition();
        }, delay);
        restarting = true;
    }

    private void startRecognition() {
        if (!canRecognize()) {
            updateNotification("MIC PERMISSION / SPEECH SERVICE NEEDED");
            return;
        }
        if (recognizer == null) createRecognizer();
        if (recognizer == null) return;
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
            recognizer.startListening(intent);
            restarting = false;
        } catch (Exception e) {
            listening = false;
            startRecognitionSoon(1000);
        }
    }

    private void handleRecognizedCommand(String command) {
        if (command == null || command.trim().isEmpty()) {
            commandWindow = false;
            startRecognitionSoon(250);
            return;
        }
        command = command.trim();
        wakeTriggered = false;
        ChatStore.add(this, "YOU", command);
        JarvisCommandRouter.Result result = JarvisCommandRouter.INSTANCE.handle(this, command);
        if (result.getHandled()) {
            ChatStore.add(this, "JARVIS", result.getReply());
            speak(result.getReply());
            return;
        }

        // The local model stays owned by the visible app to avoid loading a second ~700 MB+ model in RAM.
        // Normal voice questions are handed to the full JARVIS UI; deterministic phone commands remain background-capable.
        String reply = "I heard you. Open JARVIS for the full local AI conversation.";
        ChatStore.add(this, "JARVIS", reply);
        speak(reply);
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        open.putExtra("jarvis_voice_text", command);
        try { startActivity(open); } catch (Exception ignored) { }
    }

    private String bestResult(Bundle results) {
        if (results == null) return "";
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return matches == null || matches.isEmpty() ? "" : matches.get(0).trim();
    }

    private boolean containsWakeWord(Bundle results) {
        String value = normalize(bestResult(results));
        return value.equals("jarvis") || value.startsWith("jarvis ") || value.contains("hey jarvis");
    }

    private String stripWakeWord(String text) {
        String value = normalize(text);
        value = value.replaceFirst("^.*?hey jarvis\\s*", "");
        value = value.replaceFirst("^jarvis\\s*", "");
        return value.trim();
    }

    private String normalize(String text) {
        return text == null ? "" : text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
    }

    private void speak(String text) {
        if (!ttsReady || tts == null || text == null || text.isEmpty()) {
            startRecognitionSoon(300);
            return;
        }
        updateNotification("SPEAKING");
        try {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply");
        } catch (Exception ignored) { startRecognitionSoon(300); }
    }

    private void stopRecognizer() {
        handler.removeCallbacksAndMessages(null);
        restarting = false;
        listening = false;
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) {}
        }
    }

    private void updateNotification(String status) {
        lastStatus = status;
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, buildNotification(status));
    }

    private Notification buildNotification(String status) {
        RemoteViews compact = new RemoteViews(getPackageName(), R.layout.notification_jarvis);
        compact.setTextViewText(R.id.notification_title, "JARVIS");
        compact.setTextViewText(R.id.notification_status, status);
        compact.setOnClickPendingIntent(R.id.notification_open, activityPendingIntent());
        compact.setOnClickPendingIntent(R.id.notification_pause, actionPendingIntent(active ? ACTION_SLEEP : ACTION_ON, 21));
        compact.setOnClickPendingIntent(R.id.notification_stop, actionPendingIntent(ACTION_OFF, 22));

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_jarvis)
                .setCustomContentView(compact)
                .setStyle(new NotificationCompat.DecoratedCustomViewStyle())
                .setContentTitle("JARVIS")
                .setContentText(status)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOnlyAlertOnce(true)
                .build();
    }

    private PendingIntent activityPendingIntent() {
        Intent intent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(this, 20, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private PendingIntent actionPendingIntent(String action, int requestCode) {
        Intent intent = new Intent(this, JarvisService.class).setAction(action);
        return PendingIntent.getService(this, requestCode, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "JARVIS Voice", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("JARVIS voice assistant status and controls");
            channel.setShowBadge(false);
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        stopRecognizer();
        if (tts != null) { try { tts.stop(); tts.shutdown(); } catch (Exception ignored) {} }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
