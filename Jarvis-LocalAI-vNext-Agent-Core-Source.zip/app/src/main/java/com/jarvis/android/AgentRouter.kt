package com.jarvis.android

import android.content.Context

object AgentRouter {
    enum class Agent { COMMAND, MEMORY, CODE, STUDY, WEB, LOCAL }

    fun choose(context: Context, input: String): Agent {
        val n = input.lowercase()
        if (n.contains("my name") || n.contains("mera naam") || n.contains("remember") || n.contains("yaad")) return Agent.MEMORY
        if (n.startsWith("open ") || n.startsWith("launch ") || n.contains("set timer") || n.contains("volume")) return Agent.COMMAND
        if (n.contains("code") || n.contains("program") || n.contains("python") || n.contains("java") || n.contains("kotlin")) return Agent.CODE
        if (n.contains("homework") || n.contains("study") || n.contains("math") || n.contains("physics") || n.contains("chemistry")) return Agent.STUDY
        if (n.contains("latest") || n.contains("internet") || n.contains("web") || n.contains("search")) return Agent.WEB
        return Agent.LOCAL
    }
}
