# Jarvis Local AI — Native Loader Fix

This build keeps the bundled Llama 3.2 1B Instruct Q4_0 model and fixes the Android native-loading path.

## What changed

- Android app is arm64-v8a only (the target phone architecture).
- Uses NDK 29.0.13113456, matching the current official llama.android library configuration.
- Forces CPU-only static backend registration for the Android library (`GGML_BACKEND_DL=OFF`) and disables extra CPU backend variants (`GGML_CPU_ALL_VARIANTS=OFF`) to avoid runtime backend-DLL selection problems.
- Enables legacy native-library packaging / `extractNativeLibs=true`.
- Uses a larger native heap allowance for the ~773 MB bundled GGUF.
- Keeps the model bundled and auto-copied into app-private storage. No model picker.
- Keeps the existing Jarvis chat UI and foreground service.
- APK verification fails the workflow if the arm64 native libraries or bundled GGUF are missing.

## Build

Push this project to the `main` branch or run the `Build Jarvis APK` GitHub Actions workflow manually. The workflow downloads the GGUF during CI, builds the official llama.android base, injects the Jarvis source, applies the native-loader hardening, and publishes `Jarvis-Local-AI.apk`.

## Important

The phone should be arm64-v8a and have enough free storage/RAM for the bundled model. The Q4_0 GGUF was intentionally not changed because it already loads successfully in llama.cpp on the target phone.
