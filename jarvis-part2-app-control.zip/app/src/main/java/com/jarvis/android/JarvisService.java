package com.jarvis.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.Locale;

public class JarvisService extends Service {
    public static final String ACTION_ON = "com.jarvis.android.action.ON";
    public static final String ACTION_SLEEP = "com.jarvis.android.action.SLEEP";
    public static final String ACTION_OFF = "com.jarvis.android.action.OFF";

    private static final int NOTIFICATION_ID = 1;
    private static final String CHANNEL_ID = "jarvis_core";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private boolean sleeping = false;
    private boolean listening = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification("JARVIS ACTIVE"));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_ON : intent.getAction();

        if (ACTION_SLEEP.equals(action)) {
            sleeping = true;
            updateNotification("JARVIS SLEEPING");
            startWakeListener();
        } else if (ACTION_OFF.equals(action)) {
            sleeping = false;
            stopWakeListener();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        } else {
            sleeping = false;
            updateNotification("JARVIS ACTIVE");
            startWakeListener();
        }
        return START_STICKY;
    }

    private void startWakeListener() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            updateNotification("MICROPHONE PERMISSION NEEDED");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotification("VOICE RECOGNITION UNAVAILABLE");
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { listening = true; }
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float rmsdB) {}
                @Override public void onBufferReceived(byte[] buffer) {}
                @Override public void onEndOfSpeech() { listening = false; }
                @Override public void onError(int error) {
                    listening = false;
                    scheduleWakeRestart();
                }
                @Override public void onResults(Bundle results) {
                    listening = false;
                    if (containsWakeWord(results)) {
                        wakeJarvis();
                    } else {
                        scheduleWakeRestart();
                    }
                }
                @Override public void onPartialResults(Bundle partialResults) {
                    if (containsWakeWord(partialResults)) wakeJarvis();
                }
                @Override public void onEvent(int eventType, Bundle params) {}
            });
        }
        startRecognition();
    }

    private void startRecognition() {
        if (!sleeping || recognizer == null || listening) return;
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
            recognizer.startListening(intent);
        } catch (Exception ignored) {
            scheduleWakeRestart();
        }
    }

    private boolean containsWakeWord(Bundle results) {
        if (results == null) return false;
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches == null) return false;
        for (String text : matches) {
            if (text == null) continue;
            String normalized = text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
            if (normalized.contains("hey jarvis") || normalized.equals("jarvis") || normalized.startsWith("jarvis ")) return true;
        }
        return false;
    }

    private void wakeJarvis() {
        if (!sleeping) return;
        sleeping = false;
        stopWakeListener();
        updateNotification("JARVIS LISTENING");
        startCommandListener();
    }

    private void startCommandListener() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            updateNotification("MICROPHONE PERMISSION NEEDED");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotification("VOICE RECOGNITION UNAVAILABLE");
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        }
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { listening = true; }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() { listening = false; }
            @Override public void onError(int error) { listening = false; updateNotification("JARVIS ACTIVE"); }
            @Override public void onResults(Bundle results) {
                listening = false;
                handleCommand(results);
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
            recognizer.startListening(intent);
        } catch (Exception ignored) {
            updateNotification("JARVIS ACTIVE");
        }
    }

    private void handleCommand(Bundle results) {
        ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches == null || matches.isEmpty()) {
            updateNotification("JARVIS ACTIVE");
            return;
        }
        String command = matches.get(0).toLowerCase(Locale.ROOT).trim();
        String appName = null;
        String packageName = null;

        if (command.contains("whatsapp")) { appName = "WhatsApp"; packageName = "com.whatsapp"; }
        else if (command.contains("youtube")) { appName = "YouTube"; packageName = "com.google.android.youtube"; }
        else if (command.contains("instagram")) { appName = "Instagram"; packageName = "com.instagram.android"; }
        else if (command.contains("chrome")) { appName = "Chrome"; packageName = "com.android.chrome"; }
        else if (command.contains("facebook")) { appName = "Facebook"; packageName = "com.facebook.katana"; }
        else if (command.contains("telegram")) { appName = "Telegram"; packageName = "org.telegram.messenger"; }

        if (packageName != null) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launch);
                updateNotification("OPENED " + appName.toUpperCase(Locale.ROOT));
                return;
            }
            updateNotification(appName.toUpperCase(Locale.ROOT) + " NOT INSTALLED");
            return;
        }

        updateNotification("COMMAND NOT RECOGNIZED");
    }

    private void scheduleWakeRestart() {
        if (!sleeping) return;
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(this::startRecognition, 600);
    }

    private void stopWakeListener() {
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) {}
            recognizer.destroy();
            recognizer = null;
        }
        listening = false;
    }

    private void updateNotification(String status) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, buildNotification(status));
    }

    private Notification buildNotification(String status) {
        PendingIntent on = actionPendingIntent(ACTION_ON, 10);
        PendingIntent sleep = actionPendingIntent(ACTION_SLEEP, 11);
        PendingIntent off = actionPendingIntent(ACTION_OFF, 12);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis")
            .setContentText(status)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(new NotificationCompat.Action(0, "ON", on))
            .addAction(new NotificationCompat.Action(0, "SLEEP", sleep))
            .addAction(new NotificationCompat.Action(0, "OFF", off))
            .build();
    }

    private PendingIntent actionPendingIntent(String action, int requestCode) {
        Intent intent = new Intent(this, JarvisService.class).setAction(action);
        return PendingIntent.getService(this, requestCode, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Jarvis Core", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Jarvis background service status");
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        stopWakeListener();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
