package com.jarvis.android

import android.content.Context

object JarvisMemory {
    private const val PREFS = "jarvis_memory"
    private const val NAME = "name"
    private const val FACTS = "facts"

    fun setName(context: Context, name: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(NAME, name.trim()).apply()
    }

    fun getName(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(NAME, null)?.takeIf { it.isNotBlank() }

    fun remember(context: Context, fact: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = prefs.getStringSet(FACTS, emptySet())?.toMutableSet() ?: mutableSetOf()
        old.add(fact.trim())
        prefs.edit().putStringSet(FACTS, old.toList().takeLast(30).toSet()).apply()
    }

    fun summary(context: Context): String {
        val name = getName(context)
        val facts = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(FACTS, emptySet())?.filter { it.isNotBlank() }?.takeLast(8).orEmpty()
        return buildString {
            if (name != null) append("User name: ").append(name).append("\n")
            facts.forEach { append("Remembered: ").append(it).append("\n") }
        }.trim()
    }
}
